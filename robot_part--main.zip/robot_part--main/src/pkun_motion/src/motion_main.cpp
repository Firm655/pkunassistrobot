#include <atomic>
#include <chrono>
#include <csignal>
#include <cstdio>
#include <exception>
#include <memory>

#include "pkun_motion/motion_node.hpp"
#include "rclcpp/rclcpp.hpp"

namespace
{
std::atomic_bool g_stop{false};

extern "C" void on_signal(int) {g_stop = true;}
}  // namespace

int main(int argc, char ** argv)
{
  // rclcpp's own handler would shut the context down the moment Ctrl-C lands,
  // and a robot whose legs are cut mid-stand falls over. We take the signal
  // ourselves, leave the stop to park(), and shut down after that.
  rclcpp::init(argc, argv, rclcpp::InitOptions(), rclcpp::SignalHandlerOptions::None);
  std::signal(SIGINT, on_signal);
  std::signal(SIGTERM, on_signal);

  int code = 0;
  try {
    // Single-threaded on purpose: the control tick, goal and cancel callbacks
    // and the driver state all touch the same trajectory, and running them one
    // at a time is what makes that safe without locks.
    rclcpp::executors::SingleThreadedExecutor executor;
    auto node = std::make_shared<pkun_motion::MotionNode>(rclcpp::NodeOptions());
    executor.add_node(node);
    while (rclcpp::ok() && !g_stop) {
      executor.spin_once(std::chrono::milliseconds(50));
    }
    if (rclcpp::ok()) {
      node->park();
    }
  } catch (const std::exception & e) {
    std::fprintf(stderr, "[motion] fatal: %s\n", e.what());
    code = 1;
  }
  rclcpp::shutdown();
  return code;
}
