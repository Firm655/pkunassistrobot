#include "pkun_motion/planner.hpp"

#include <algorithm>
#include <cmath>
#include <sstream>
#include <utility>

namespace pkun_motion
{

namespace
{

/// `d` expressed in the heading frame of `base` (x forward, y left), added on.
BodyPose offset(const BodyPose & base, const BodyPose & d)
{
  const double c = std::cos(base.yaw), s = std::sin(base.yaw);
  return BodyPose{base.x + c * d.x - s * d.y, base.y + s * d.x + c * d.y, base.z + d.z,
    base.roll + d.roll, base.pitch + d.pitch, base.yaw + d.yaw};
}

std::array<Vec3, kNumLegs> feet_world(const RobotModel & model, const Frame & f)
{
  const Pose T = to_isometry(f.body);
  std::array<Vec3, kNumLegs> out;
  for (Leg leg : kLegs) {
    out[index_of(leg)] = T * model.foot(leg, leg_q(f.q, leg));
  }
  return out;
}

Vec2 incenter(const Vec2 & A, const Vec2 & B, const Vec2 & C)
{
  const double a = (B - C).norm(), b = (C - A).norm(), c = (A - B).norm();
  return (a * A + b * B + c * C) / std::max(1e-9, a + b + c);
}

double cross2(const Vec2 & u, const Vec2 & v) {return u.x() * v.y() - u.y() * v.x();}

Vec2 closest_on_segment(const Vec2 & p, const Vec2 & a, const Vec2 & b)
{
  const Vec2 ab = b - a;
  const double t = std::clamp((p - a).dot(ab) / std::max(1e-12, ab.squaredNorm()), 0.0, 1.0);
  return a + t * ab;
}

/// Closest point to `p` that lies at least `margin` inside triangle abc -- the
/// smallest lean that makes three-foot support safe. The inward-offset triangle
/// is the original scaled about its incenter by (r - margin) / r.
Vec2 closest_safe_point(const Vec2 & a, const Vec2 & b, const Vec2 & c,
  const Vec2 & p, double margin)
{
  const double per = (b - c).norm() + (c - a).norm() + (a - b).norm();
  const Vec2 I = incenter(a, b, c);
  const double r = std::abs(cross2(b - a, c - a)) / std::max(1e-9, per);
  if (r <= margin) {return I;}
  const double k = (r - margin) / r;
  const Vec2 A = I + (a - I) * k, B = I + (b - I) * k, C = I + (c - I) * k;
  const double s0 = cross2(B - A, p - A), s1 = cross2(C - B, p - B), s2 = cross2(A - C, p - C);
  if ((s0 >= 0 && s1 >= 0 && s2 >= 0) || (s0 <= 0 && s1 <= 0 && s2 <= 0)) {return p;}
  Vec2 best = closest_on_segment(p, A, B);
  for (const Vec2 & q : {closest_on_segment(p, B, C), closest_on_segment(p, C, A)}) {
    if ((q - p).squaredNorm() < (best - p).squaredNorm()) {best = q;}
  }
  return best;
}

/// Sideways lean as a function of gait phase: held at `left`/`right` while that
/// side's legs are in the air, min-jerk between the two in the four-feet gaps.
double lean_at(double phase, const std::array<double, 4> & off, double swing,
  double left, double right)
{
  struct Win {double a, b, v;};
  std::array<Win, 4> w;
  for (Leg leg : kLegs) {
    const int j = index_of(leg);
    w[j] = Win{off[j], off[j] + swing, is_left(leg) ? left : right};
  }
  std::sort(w.begin(), w.end(), [](const Win & x, const Win & y) {return x.a < y.a;});
  for (int i = 0; i < 4; ++i) {
    const Win & cur = w[i];
    const Win & nxt = w[(i + 1) % 4];
    const double next_a = nxt.a + (i == 3 ? 1.0 : 0.0);
    double q = phase - std::floor(phase - cur.a);   // into [cur.a, cur.a + 1)
    if (q < cur.b) {return cur.v;}
    if (q < next_a) {
      return cur.v + (nxt.v - cur.v) * min_jerk((q - cur.b) / std::max(1e-9, next_a - cur.b));
    }
  }
  return 0.0;
}

/// Footsteps and base path of one gait, before any frames are made. Shared by
/// the walk itself and the sway fit so both see exactly the same schedule.
struct GaitSchedule
{
  struct Swing {double t0, t1; Vec3 p0, p1;};

  double T{0}, beta{0}, t_pre{0}, t_steps{0}, t_end{0}, t_last_land{0}, dt{0};
  std::array<double, 4> offset{};
  int n{0};
  std::vector<BodyPose> base;                      // one per dt tick, z = stand height
  std::array<std::vector<Swing>, kNumLegs> swings;
  std::array<Vec3, kNumLegs> start_feet;

  BodyPose base_at(double t) const
  {
    const double tc = std::clamp(t, 0.0, dt * (base.size() - 1));
    const std::size_t k = std::min<std::size_t>(static_cast<std::size_t>(tc / dt), base.size() - 2);
    return lerp(base[k], base[k + 1], (tc - dt * k) / dt);
  }

  /// Foot position and whether it bears load at time t.
  Vec3 foot(int leg, double t, double step_height, bool & contact) const
  {
    Vec3 pos = start_feet[leg];
    contact = true;
    for (const Swing & s : swings[leg]) {
      if (t >= s.t1) {pos = s.p1; continue;}
      if (t > s.t0) {
        const double u = (t - s.t0) / (s.t1 - s.t0);
        const double m = min_jerk(u);
        pos = s.p0 + (s.p1 - s.p0) * m;
        // 64 u^3 (1-u)^3 peaks at 1 and has zero speed and acceleration at both
        // ends, so the foot neither scuffs off nor slaps down.
        pos.z() = step_height * 64.0 * std::pow(u * (1.0 - u), 3.0);
        contact = false;
      }
      break;
    }
    return pos;
  }
};

GaitSchedule schedule_gait(
  const BodyPose & base0, const std::array<Vec3, kNumLegs> & feet0,
  const std::array<Vec3, kNumLegs> & rel, const GaitConfig & g,
  double stride, double turn, int cycles, double speed, double dt)
{
  GaitSchedule s;
  s.dt = dt;
  s.T = g.cycle_time / speed;
  s.beta = g.duty;
  s.t_pre = g.pre_time / speed;
  s.t_steps = s.t_pre + cycles * s.T;
  s.t_end = s.t_steps + g.post_time / speed;
  s.n = static_cast<int>(std::ceil(s.t_end / dt - 1e-9));
  s.start_feet = feet0;
  s.offset = lateral_sequence_offsets(g.duty);

  // Base velocity ramps up over the first cycle and down over the last. The
  // ramp length depends only on T while cycles >= 2, which is what keeps a
  // shortened re-plan identical up to the moment it starts slowing down.
  const double v_max = stride / s.T, w_max = turn / s.T;
  const double L = std::min(s.T, 0.5 * cycles * s.T);
  auto ramp = [&](double t) {
      if (t <= s.t_pre || t >= s.t_steps) {return 0.0;}
      const double tt = t - s.t_pre;
      return std::min(min_jerk(tt / L), min_jerk((cycles * s.T - tt) / L));
    };

  s.base.resize(s.n + 2);
  s.base[0] = base0;
  for (std::size_t k = 1; k < s.base.size(); ++k) {
    const double r = ramp((static_cast<double>(k) - 0.5) * dt);
    const BodyPose & prev = s.base[k - 1];
    const double yaw_mid = prev.yaw + 0.5 * w_max * r * dt;
    BodyPose b = prev;
    b.x += v_max * r * std::cos(yaw_mid) * dt;
    b.y += v_max * r * std::sin(yaw_mid) * dt;
    b.yaw += w_max * r * dt;
    s.base[k] = b;
  }

  // Each foot lands where it will sit centred under its hip halfway through
  // its next stance -- except its last step, whose "next stance" is standing
  // still for good, so it aims for where the body finally stops. Planted feet
  // never move in the world, by construction.
  const Pose final_base = to_isometry(s.base.back());
  for (int j = 0; j < kNumLegs; ++j) {
    Vec3 pos = feet0[j];
    for (int k = 0; k < cycles; ++k) {
      GaitSchedule::Swing sw;
      sw.t0 = s.t_pre + (k + s.offset[j]) * s.T;
      sw.t1 = sw.t0 + (1.0 - s.beta) * s.T;
      sw.p0 = pos;
      sw.p1 = (k == cycles - 1 ? final_base : to_isometry(s.base_at(sw.t1 + 0.5 * s.beta * s.T))) *
        rel[j];
      sw.p1.z() = 0.0;
      s.swings[j].push_back(sw);
      s.t_last_land = std::max(s.t_last_land, sw.t1);
      pos = sw.p1;
    }
  }
  return s;
}

}  // namespace

// ---------------------------------------------------------------------------
// Builder: appends segments, each starting exactly where the last one ended.
// ---------------------------------------------------------------------------

class Builder
{
public:
  Builder(const Planner & p, std::string name, double speed)
  : p_(p), cfg_(p.cfg_), model_(p.model_), speed_(speed), dt_(p.dt())
  {
    traj_.name = std::move(name);
    traj_.dt = dt_;
  }

  bool ok() const {return error_.empty();}
  const std::string & error() const {return error_;}
  Posture posture() const {return posture_;}

  void start(Posture from, const Joints & q_now, double neck_now)
  {
    neck_start_ = std::isfinite(neck_now) ? neck_now / kDeg :
      p_.neck_deg(from == Posture::Unknown ? Posture::Rest : from);
    if (!q_now.allFinite()) {
      fail("current joint state is not finite");
      return;
    }
    const Frame & canon = p_.posture_frame(from == Posture::Unknown ? Posture::Rest : from);
    const double diff = (q_now - canon.q).cwiseAbs().maxCoeff();

    Frame f = canon;
    f.q = q_now;
    if (from == Posture::Unknown || diff > 25.0 * kDeg) {
      // We do not know where the body is. Fold into the canonical posture in
      // joint space, slowly; stability is not checked because it cannot be.
      f.body_known = false;
      f.static_check = false;
      push(f);
      const double secs = std::max(1.0,
          kMinJerkPeakRate * diff / (cfg_.timing.recover_rate_dps * kDeg));
      neck_real(p_.neck_deg(from == Posture::Unknown ? Posture::Rest : from), secs);
      joint_blend(canon.q, secs, canon.body, false, false);
      traj_.frames.back() = canon;
      posture_ = from == Posture::Unknown ? Posture::Rest : from;
    } else {
      push(f);
      neck_real(p_.neck_deg(from), cfg_.neck.settle_s);
      if (diff > 1e-6) {
        const double secs = std::max(0.15,
            kMinJerkPeakRate * diff / (cfg_.timing.settle_rate_dps * kDeg));
        joint_blend(canon.q, secs, canon.body, true, canon.static_check);
      }
      posture_ = from;
    }
    base_ = p_.stand_body_;
  }

  void go_to(Posture target, double scale = 1.0)
  {
    for (int guard = 0; guard < 4 && ok() && posture_ != target; ++guard) {
      switch (posture_) {
        case Posture::Rest: rest_to_stand(scale); break;
        case Posture::Sit: sit_to_stand(scale); break;
        case Posture::Stand:
          if (target == Posture::Rest) {stand_to_rest(scale);} else {stand_to_sit(scale);}
          break;
        case Posture::Unknown: fail("cannot plan from an unknown posture"); return;
      }
    }
  }

  // --- behaviours -----------------------------------------------------------

  void walk(double stride, double turn, int cycles)
  {
    if (!require(Posture::Stand)) {return;}
    const double h = cfg_.gait.body_height;
    const BodyPose idle = stand_at_base();
    BodyPose tall = idle;
    tall.z = h;
    neck(cfg_.neck.walk_deg, cfg_.gait.rise_time);
    body_move(tall, cfg_.gait.rise_time);
    if (!ok()) {return;}
    base_.z = h;

    const Frame f0 = traj_.frames.back();
    const auto rel = p_.footprint_rel(h);
    const GaitSchedule s = schedule_gait(base_, feet_world(model_, f0), rel, cfg_.gait,
        stride, turn, cycles, speed_, dt_);
    const auto sway = p_.fit_sway(stride, turn, cfg_.gait.cycle_time, speed_, h);

    traj_.gait = GaitInfo{true, traj_.frames.size() - 1, s.t_pre, s.T, cycles, stride, turn};

    // Lean: ease onto the first stepping side before the first lift, follow the
    // side-to-side pattern while stepping, ease back to centre after the last
    // foot lands. Every piece depends only on time before the last landing,
    // which keeps a shortened re-plan identical up to that point.
    const double swing = 1.0 - s.beta;
    auto lean_phase = [&](double t) {
        return lean_at((t - s.t_pre) / s.T, s.offset, swing, sway.left_steps, sway.right_steps);
      };
    const double first = lean_phase(s.t_pre);
    const double last = lean_phase(s.t_last_land);
    auto lean = [&](double t) {
        if (t < s.t_pre) {return first * min_jerk(t / s.t_pre);}
        if (t <= s.t_last_land) {return lean_phase(t);}
        return last * min_jerk((s.t_end - t) / (s.t_end - s.t_last_land));
      };

    for (int k = 1; k <= s.n && ok(); ++k) {
      const double t = k * dt_;
      BodyPose body = offset(s.base[k],
          BodyPose{0.0, cfg_.gait.sway_gain * lean(t), 0, 0, 0, 0});

      std::array<Vec3, kNumLegs> feet;
      std::array<bool, kNumLegs> contact;
      for (int j = 0; j < kNumLegs; ++j) {
        bool c = true;
        feet[j] = s.foot(j, t, cfg_.gait.step_height, c);
        contact[j] = c;
      }
      Frame f;
      if (solve(body, feet, contact, true, f)) {push(f);}
    }
    base_ = s.base[s.n];
    base_.roll = base_.pitch = 0.0;
    neck(cfg_.neck.stand_deg, cfg_.gait.rise_time);
    body_move(stand_at_base(), cfg_.gait.rise_time);
    base_.z = p_.stand_body_.z;
    posture_ = Posture::Stand;
  }

  void beckon(Leg paw, int count)
  {
    if (!require(Posture::Stand)) {return;}
    const auto & gc = cfg_.gesture;
    const Frame f0 = traj_.frames.back();
    const auto F = feet_world(model_, f0);
    BodyPose tall = f0.body;
    tall.z = gc.beckon_height;
    const Pose T0 = to_isometry(tall);

    // Rise a little and lean onto the other three feet, just far enough.
    std::vector<Vec2> tri;
    for (Leg leg : kLegs) {
      if (leg != paw) {tri.push_back((T0.inverse() * F[index_of(leg)]).head<2>());}
    }
    const Vec2 com = model_.com(f0.q).head<2>();
    const Vec2 shift = closest_safe_point(tri[0], tri[1], tri[2], com, gc.beckon_margin_mm) - com;
    const BodyPose B1 = offset(tall, BodyPose{shift.x(), shift.y(), 0, 0, 0, 0});
    neck(cfg_.neck.beckon_deg, gc.beckon_shift_s);
    body_move(B1, gc.beckon_shift_s);

    const Pose T1 = to_isometry(B1);
    const int j = index_of(paw);
    const Vec3 home = F[j];
    const Vec3 rel = T1.inverse() * home;
    const Vec3 out = T1 * (rel + Vec3(gc.beckon_out_x, 0.0, gc.beckon_lift));
    const Vec3 in = T1 * (rel + Vec3(gc.beckon_in_x, 0.0, gc.beckon_lift + gc.beckon_in_z));

    auto paw_task = [&](double secs, const std::function<Vec3(double)> & path, bool land) {
        task(secs, [&](double u) {
            Frame fr;
            fr.body = B1;
            auto feet = F;
            feet[j] = path(u);
            std::array<bool, kNumLegs> contact{{true, true, true, true}};
            contact[j] = land && u >= 1.0;
            fr.contact = contact;
            return std::make_pair(fr, feet);
          });
      };

    // Up: the paw leaves the ground mostly vertically, then settles in front.
    paw_task(gc.beckon_lift_s, [&](double u) {
        Vec3 p = home + (out - home) * min_jerk(u);
        p.z() = home.z() + (out.z() - home.z()) * min_jerk(std::min(1.0, 1.6 * u));
        return p;
      }, false);
    for (int i = 0; i < count && ok(); ++i) {
      // "Come on": the head dips toward the person with each wave.
      neck(cfg_.neck.beckon_deg + cfg_.neck.beckon_beat_deg, 0.5 * gc.beckon_beat_s);
      neck(cfg_.neck.beckon_deg, 0.5 * gc.beckon_beat_s, 0.5 * gc.beckon_beat_s);
      paw_task(gc.beckon_beat_s, [&](double u) {
          return Vec3(out + (in - out) * (0.5 - 0.5 * std::cos(2.0 * M_PI * u)));
        }, false);
    }
    // Down: come back over the spot first, touch down last.
    paw_task(gc.beckon_lift_s, [&](double u) {
        Vec3 p = out + (home - out) * min_jerk(u);
        p.z() = out.z() + (home.z() - out.z()) * min_jerk(std::max(0.0, (u - 0.375) / 0.625));
        return p;
      }, true);

    neck(cfg_.neck.stand_deg, gc.beckon_shift_s);
    body_move(f0.body, gc.beckon_shift_s);
  }

  void alert()
  {
    if (!require(Posture::Stand)) {return;}
    const auto & gc = cfg_.gesture;
    const BodyPose B0 = traj_.frames.back().body;
    const BodyPose up = offset(B0, BodyPose{0, 0, gc.alert_rise, 0, gc.alert_pitch_deg * kDeg, 0});
    neck(cfg_.neck.alert_deg, gc.alert_perk_s);   // head up with the perk, and it stays up
    body_move(up, gc.alert_perk_s);
    for (int i = 0; i < 2; ++i) {
      body_move(offset(up, BodyPose{0, 0, -gc.alert_bounce, 0, 0, 0}), gc.alert_bounce_s);
      body_move(up, gc.alert_bounce_s);
    }
    body_move(B0, gc.alert_perk_s);
    stand_to_sit(0.8);
  }

  void play_bow()
  {
    if (!require(Posture::Stand)) {return;}
    const auto & gc = cfg_.gesture;
    const BodyPose B0 = traj_.frames.back().body;
    neck(cfg_.neck.bow_deg, gc.bow_move_s);
    body_move(offset(B0, BodyPose{-gc.bow_back, 0, -gc.bow_drop, 0, gc.bow_pitch_deg * kDeg, 0}),
      gc.bow_move_s);
    hold(gc.bow_hold_s);
    neck(cfg_.neck.stand_deg, gc.bow_move_s);
    body_move(B0, gc.bow_move_s);
  }

  void happy(int count)
  {
    if (!require(Posture::Stand)) {return;}
    const auto & gc = cfg_.gesture;
    const BodyPose B0 = traj_.frames.back().body;
    const auto F = feet_world(model_, traj_.frames.back());
    const double hz = gc.happy_hz * speed_;
    const double dur = count / hz;
    const double half = 0.5 / hz;
    const double px = gc.happy_pivot_x;
    // The head bobs once per wag: up, a little down, ... then settles.
    const int bobs = 2 * count;
    for (int i = 0; i < bobs; ++i) {
      const double a = (i % 2 == 0) ? cfg_.neck.happy_bob_deg : -0.5 * cfg_.neck.happy_bob_deg;
      neck_real(cfg_.neck.stand_deg + (i == bobs - 1 ? 0.0 : a), dur / bobs, i * dur / bobs);
    }
    task(dur * speed_, [&](double u) {   // task() divides by speed again
        const double t = u * dur;
        const double env = std::min(min_jerk(t / half), min_jerk((dur - t) / half));
        const double w = std::sin(2.0 * M_PI * hz * t) * env;
        const double yaw = gc.happy_yaw_deg * kDeg * w;
        Frame fr;
        // Rotate about a pivot at the shoulders so the rear end does the wagging.
        fr.body = offset(B0, BodyPose{px * (1.0 - std::cos(yaw)), -px * std::sin(yaw), 0,
            gc.happy_roll_deg * kDeg * w, 0, yaw});
        return std::make_pair(fr, F);
      });
  }

  /// Wake the resident: get up slowly, stretch, then bounce and nod.
  void wake_up(int bounces)
  {
    if (!require(Posture::Stand)) {return;}
    const auto & gc = cfg_.gesture;
    const BodyPose B0 = traj_.frames.back().body;
    neck(cfg_.neck.wake_stretch_deg, gc.wake_stretch_s);
    body_move(offset(B0, BodyPose{0, 0, 0, 0, gc.wake_pitch_deg * kDeg, 0}), gc.wake_stretch_s);
    hold(gc.wake_hold_s);
    neck(cfg_.neck.stand_deg, gc.wake_stretch_s);
    body_move(B0, gc.wake_stretch_s);
    // Each bounce a little deeper than the last: easy to sleep through the
    // first, hard to sleep through the third.
    for (int i = 0; i < bounces && ok(); ++i) {
      const double amp = gc.wake_bounce * (1.0 + 0.5 * i);
      body_move(offset(B0, BodyPose{0, 0, -amp, 0, 0, 0}), gc.wake_bounce_s);
      body_move(B0, gc.wake_bounce_s);
    }
    nod(1);
  }

  /// Medicine: deliberate, no wiggle, and it ends sitting with the screen up.
  void medicine(int nods)
  {
    if (!require(Posture::Stand)) {return;}
    const auto & gc = cfg_.gesture;
    const BodyPose B0 = traj_.frames.back().body;
    const BodyPose tall =
      offset(B0, BodyPose{0, 0, gc.med_rise, 0, gc.med_pitch_deg * kDeg, 0});
    const auto & nc = cfg_.neck;
    neck(nc.med_look_deg, gc.med_beat_s);
    body_move(tall, gc.med_beat_s);
    hold(0.5 * gc.med_hold_s);
    for (int i = 0; i < nods && ok(); ++i) {
      neck(nc.med_look_deg - nc.med_nod_deg, gc.med_beat_s);
      body_move(offset(tall, BodyPose{0, 0, 0, 0, -gc.med_nod_deg * kDeg, 0}), gc.med_beat_s);
      neck(nc.med_look_deg, gc.med_beat_s);
      body_move(tall, gc.med_beat_s);
    }
    neck(nc.stand_deg, gc.med_beat_s);
    body_move(B0, gc.med_beat_s);
    stand_to_sit(1.0);
    hold(gc.med_hold_s);
  }

  /// Come with me: play bow, a wiggle, then a beckoning paw.
  void lets_go(int waves)
  {
    if (!require(Posture::Stand)) {return;}
    const auto & gc = cfg_.gesture;
    const BodyPose B0 = traj_.frames.back().body;
    neck(cfg_.neck.bow_deg, gc.go_bow_s);
    body_move(offset(B0, BodyPose{0, 0, 0, 0, gc.go_bow_pitch_deg * kDeg, 0}), gc.go_bow_s);
    hold(gc.go_hold_s);
    neck(cfg_.neck.stand_deg, gc.go_bow_s);
    body_move(B0, gc.go_bow_s);
    happy(1);
    beckon(Leg::FL, waves);
  }

  /// Meal time: nose down and nibble, then a pleased wiggle.
  void eat(int bites)
  {
    if (!require(Posture::Stand)) {return;}
    const auto & gc = cfg_.gesture;
    const BodyPose B0 = traj_.frames.back().body;
    const BodyPose down = offset(B0, BodyPose{0, 0, 0, 0, gc.eat_pitch_deg * kDeg, 0});
    const auto & nc = cfg_.neck;
    neck(nc.eat_down_deg, gc.eat_down_s);
    body_move(down, gc.eat_down_s);
    for (int i = 0; i < bites && ok(); ++i) {
      neck(nc.eat_down_deg - nc.eat_dip_deg, gc.eat_beat_s);
      body_move(offset(down, BodyPose{0, 0, 0, 0, -gc.eat_dip_deg * kDeg, 0}), gc.eat_beat_s);
      neck(nc.eat_down_deg, gc.eat_beat_s);
      body_move(down, gc.eat_beat_s);
    }
    neck(nc.stand_deg, gc.eat_down_s);
    body_move(B0, gc.eat_down_s);
    happy(1);
  }

  void nod(int count)
  {
    if (!require(Posture::Stand)) {return;}
    const auto & gc = cfg_.gesture;
    const BodyPose B0 = traj_.frames.back().body;
    const auto & nc = cfg_.neck;
    for (int i = 0; i < count && ok(); ++i) {
      neck(nc.stand_deg - nc.nod_down_deg, 0.5 * gc.nod_beat_s);
      body_move(offset(B0, BodyPose{0, 0, 0, 0, -gc.nod_down_deg * kDeg, 0}), 0.5 * gc.nod_beat_s);
      neck(nc.stand_deg + nc.nod_up_deg, 0.5 * gc.nod_beat_s);
      body_move(offset(B0, BodyPose{0, 0, 0, 0, gc.nod_up_deg * kDeg, 0}), 0.5 * gc.nod_beat_s);
    }
    neck(nc.stand_deg, 0.5 * gc.nod_beat_s);
    body_move(B0, 0.5 * gc.nod_beat_s);
  }

  Trajectory finish()
  {
    // The neck may still be on its way (e.g. "stand" when already standing):
    // hold the body until it arrives rather than cut it off.
    if (!traj_.frames.empty() && !neck_moves_.empty()) {
      const int more = static_cast<int>(std::ceil((neck_moves_.back().t1 - now_s()) / dt_ - 1e-9));
      for (int i = 0; i < more; ++i) {push(traj_.frames.back());}
    }
    for (std::size_t k = 0; k < traj_.frames.size(); ++k) {
      traj_.frames[k].neck = neck_at(static_cast<double>(k) * dt_) * kDeg;
    }
    traj_.end_posture = posture_;
    return std::move(traj_);
  }

  // --- posture transitions ---------------------------------------------------

  void rest_to_stand(double scale)
  {
    neck(cfg_.neck.stand_deg, cfg_.timing.rest_to_stand * scale);
    body_move(stand_at_base(), cfg_.timing.rest_to_stand * scale);
    posture_ = Posture::Stand;
  }

  void stand_to_rest(double scale)
  {
    // Lying down, a dog settles back over its haunches: same footprint, body
    // lower and further back.
    BodyPose rest = offset(stand_at_base(),
        BodyPose{p_.rest_body_.x - p_.stand_body_.x, 0, p_.rest_body_.z - p_.stand_body_.z,
          0, 0, 0});
    neck(cfg_.neck.rest_deg, cfg_.timing.stand_to_rest * scale);
    body_move(rest, cfg_.timing.stand_to_rest * scale);
    posture_ = Posture::Rest;
  }

  void stand_to_sit(double scale)
  {
    neck(cfg_.neck.sit_deg, cfg_.timing.stand_to_sit * scale);
    sit_move(true, cfg_.timing.stand_to_sit * scale);
    posture_ = Posture::Sit;
  }

  void sit_to_stand(double scale)
  {
    neck(cfg_.neck.stand_deg, cfg_.timing.sit_to_stand * scale);
    sit_move(false, cfg_.timing.sit_to_stand * scale);
    posture_ = Posture::Stand;
  }

private:
  // --- the neck's own timeline ---------------------------------------------------
  // Moves are keyed to trajectory time, so they run alongside whatever body
  // segment follows. A new move takes over from wherever the neck is at its
  // start and cancels any later-starting one.
  struct NeckMove {double t0, t1, from, to;};

  double now_s() const
  {
    return traj_.frames.empty() ? 0.0 : dt_ * static_cast<double>(traj_.frames.size() - 1);
  }

  double neck_at(double t) const
  {
    const NeckMove * cur = nullptr;
    for (const NeckMove & m : neck_moves_) {
      if (m.t0 <= t) {cur = &m;} else {break;}
    }
    if (cur == nullptr) {return neck_start_;}
    const double u = cur->t1 > cur->t0 ? (t - cur->t0) / (cur->t1 - cur->t0) : 1.0;
    return cur->from + (cur->to - cur->from) * min_jerk(u);
  }

  /// Neck to `deg` over `seconds` (nominal speed), starting `delay` from now.
  void neck(double deg, double seconds, double delay = 0.0)
  {
    neck_real(deg, seconds / speed_, delay / speed_);
  }

  /// Same, in real seconds.
  void neck_real(double deg, double seconds, double delay = 0.0)
  {
    const double t0 = now_s() + std::max(0.0, delay);
    const double to = std::clamp(deg, cfg_.neck.min_deg, cfg_.neck.max_deg);
    const double from = neck_at(t0);
    // Min-jerk peaks at 1.875x the average speed; stretch rather than exceed the cap.
    const double need = kMinJerkPeakRate * std::abs(to - from) / cfg_.neck.max_rate_dps;
    while (!neck_moves_.empty() && neck_moves_.back().t0 >= t0) {neck_moves_.pop_back();}
    neck_moves_.push_back({t0, t0 + std::max({dt_, seconds, need}), from, to});
  }

  bool require(Posture p)
  {
    if (ok() && posture_ != p) {
      fail(std::string("internal: expected posture ") + to_string(p) + ", have " +
        to_string(posture_));
    }
    return ok();
  }

  void fail(const std::string & why)
  {
    if (error_.empty()) {
      std::ostringstream os;
      os << traj_.name << " t=" << dt_ * traj_.frames.size() << "s: " << why;
      error_ = os.str();
    }
  }

  void push(const Frame & f) {traj_.frames.push_back(f);}

  int steps(double seconds) const
  {
    return std::max(1, static_cast<int>(std::lround(seconds / speed_ / dt_)));
  }

  BodyPose stand_at_base() const
  {
    BodyPose b = base_;
    b.z = p_.stand_body_.z;
    b.roll = b.pitch = 0.0;
    return b;
  }

  bool solve(const BodyPose & body, const std::array<Vec3, kNumLegs> & feet,
    const std::array<bool, kNumLegs> & contact, bool static_check, Frame & out)
  {
    const Pose Tinv = to_isometry(body).inverse();
    out.body = body;
    out.contact = contact;
    out.body_known = true;
    out.static_check = static_check;
    for (Leg leg : kLegs) {
      Vec3 q;
      if (!model_.ik(leg, Tinv * feet[index_of(leg)], cfg_.posture.knee, q)) {
        fail(std::string("foot out of reach: ") + joint_names()[3 * index_of(leg)].substr(0, 2));
        return false;
      }
      set_leg_q(out.q, leg, q);
    }
    return true;
  }

  /// Generic task-space segment: fn(u) gives the body pose (+contacts) and the
  /// world foot targets for u in (0, 1].
  void task(double seconds,
    const std::function<std::pair<Frame, std::array<Vec3, kNumLegs>>(double)> & fn)
  {
    const int n = steps(seconds);
    for (int i = 1; i <= n && ok(); ++i) {
      const auto [spec, feet] = fn(static_cast<double>(i) / n);
      Frame f;
      if (solve(spec.body, feet, spec.contact, true, f)) {push(f);}
    }
  }

  void body_move(const BodyPose & to, double seconds)
  {
    const Frame f0 = traj_.frames.back();
    const auto F = feet_world(model_, f0);
    task(seconds, [&](double u) {
        Frame fr;
        fr.body = lerp(f0.body, to, min_jerk(u));
        fr.contact = f0.contact;
        return std::make_pair(fr, F);
      });
  }

  void hold(double seconds)
  {
    const int n = steps(seconds);
    for (int i = 0; i < n; ++i) {push(traj_.frames.back());}
  }

  void joint_blend(const Joints & to, double seconds, const BodyPose & body_to,
    bool known, bool static_check)
  {
    const Frame f0 = traj_.frames.back();
    const int n = std::max(1, static_cast<int>(std::lround(seconds / dt_)));
    for (int i = 1; i <= n; ++i) {
      const double s = min_jerk(static_cast<double>(i) / n);
      Frame f = f0;
      f.q = f0.q + (to - f0.q) * s;
      f.body = lerp(f0.body, body_to, s);
      f.body_known = known;
      f.static_check = static_check;
      push(f);
    }
  }

  void sit_move(bool down, double seconds)
  {
    const int n = steps(seconds);
    const Pose base = to_isometry(stand_at_base());
    for (int i = 1; i <= n && ok(); ++i) {
      const double m = min_jerk(static_cast<double>(i) / n);
      Frame f = p_.sit_state(down ? m : 1.0 - m, base);
      if (!f.q.allFinite()) {
        fail("sit transition out of reach");
        return;
      }
      push(f);
    }
  }

  const Planner & p_;
  const MotionConfig & cfg_;
  const RobotModel & model_;
  double speed_;
  double dt_;
  Trajectory traj_;
  Posture posture_{Posture::Unknown};
  BodyPose base_{};   // heading of the current stand spot; z = stand height
  double neck_start_{0.0};               // deg
  std::vector<NeckMove> neck_moves_;
  std::string error_;
};

// ---------------------------------------------------------------------------
// Planner
// ---------------------------------------------------------------------------

Planner::Planner(MotionConfig config)
: cfg_(std::move(config)), model_(cfg_.model())
{
  stand_body_ = BodyPose{0.0, 0.0, cfg_.posture.stand_height, 0.0, 0.0, 0.0};

  stand_ = make_stand();

  // Lying down: as low as asked, but never lower than what keeps the
  // underbody hardware clear of the table, and never lower than the legs can
  // actually fold (the knee stops at its limit before the belly would).
  double floor = 0.0;
  for (const Vec3 & p : model_.underbody()) {floor = std::max(floor, -p.z());}
  floor += cfg_.safety.min_clearance_mm;
  const double tol = cfg_.safety.limit_tol_deg * kDeg;
  double rest_z = std::min(cfg_.posture.stand_height, std::max(cfg_.posture.rest_height, floor));
  for (; rest_z < cfg_.posture.stand_height; rest_z += 0.5) {
    rest_body_ = BodyPose{-cfg_.posture.rest_body_back, 0.0, rest_z, 0.0, 0.0, 0.0};
    rest_ = make_rest();
    if (rest_.q.allFinite() && model_.within_limits(rest_.q, tol)) {break;}
  }
  rest_body_ = BodyPose{-cfg_.posture.rest_body_back, 0.0, rest_z, 0.0, 0.0, 0.0};
  rest_ = make_rest();
  sit_ = sit_state(1.0, to_isometry(stand_body_));
  unknown_ = rest_;
}

const std::vector<std::string> & Planner::behaviors()
{
  static const std::vector<std::string> names{
    "rest", "stand", "sit", "walk", "turn_left", "turn_right",
    "beckon", "alert", "play_bow", "happy", "nod",
    "wake_up", "medicine", "lets_go", "eat"};
  return names;
}

std::array<Vec3, kNumLegs> Planner::footprint_rel(double height) const
{
  const auto & pc = cfg_.posture;
  const Geometry & g = cfg_.geometry;
  const double spread = (pc.stand_height - g.c - g.h) * std::tan(pc.splay_deg * kDeg);
  const double z = height > 0.0 ? height : pc.stand_height;
  std::array<Vec3, kNumLegs> rel;
  for (Leg leg : kLegs) {
    const Vec3 hip = model_.hip(leg);
    const double sb = is_left(leg) ? 1.0 : -1.0;
    rel[index_of(leg)] = Vec3(hip.x() + pc.stand_x, hip.y() + sb * spread, -z);
  }
  return rel;
}

Frame Planner::make_stand() const
{
  Frame f;
  f.body = stand_body_;
  const auto rel = footprint_rel();
  for (Leg leg : kLegs) {
    Vec3 q = Vec3::Constant(std::nan(""));
    model_.ik(leg, rel[index_of(leg)], cfg_.posture.knee, q);
    set_leg_q(f.q, leg, q);
  }
  return f;
}

Frame Planner::make_rest() const
{
  Frame f;
  f.body = rest_body_;
  const Pose Ts = to_isometry(stand_body_);
  const Pose Tr_inv = to_isometry(rest_body_).inverse();
  const auto rel = footprint_rel();
  for (Leg leg : kLegs) {
    Vec3 q = Vec3::Constant(std::nan(""));
    model_.ik(leg, Tr_inv * (Ts * rel[index_of(leg)]), cfg_.posture.knee, q);
    set_leg_q(f.q, leg, q);
  }
  return f;
}

Frame Planner::sit_state(double s, const Pose & base) const
{
  // Rear legs fold forward in joint space; the body height is whatever puts
  // their lowest point on the ground at this pitch, and the body slides back
  // by whatever keeps the rear feet where they stood. All four feet stay
  // planted: a loaded foot dragged along the table sticks and slips, which is
  // what made sit <-> stand judder. The fore legs reach to push the chest up.
  const auto & pc = cfg_.posture;
  const auto rel = footprint_rel();
  Frame f;
  f.q = stand_.q;
  for (Leg leg : {Leg::RL, Leg::RR}) {
    const Vec3 qs = leg_q(stand_.q, leg);
    set_leg_q(f.q, leg, Vec3(qs(0),
      qs(1) + (pc.sit_rear_hip_deg * kDeg - qs(1)) * s,
      qs(2) + (pc.sit_rear_knee_deg * kDeg - qs(2)) * s));
  }
  const double pitch = s * pc.sit_pitch_deg * kDeg;
  const Eigen::Matrix3d R = to_isometry(BodyPose{0, 0, 0, 0, pitch, 0}).linear();
  double lowest = 0.0;
  for (Leg leg : {Leg::RL, Leg::RR}) {
    for (const Vec3 & p : model_.leg_points(leg, leg_q(f.q, leg))) {
      lowest = std::min(lowest, (R * p).z());
    }
  }
  double back = 0.0;   // along the heading; 0 at s = 0, where the rear legs are the stand's
  for (Leg leg : {Leg::RL, Leg::RR}) {
    back += 0.5 * (rel[index_of(leg)].x() - (R * model_.foot(leg, leg_q(f.q, leg))).x());
  }
  const Vec3 base_xy = base.translation();
  const double yaw = std::atan2(base.linear()(1, 0), base.linear()(0, 0));
  f.body = BodyPose{base_xy.x() + back * std::cos(yaw), base_xy.y() + back * std::sin(yaw),
    -lowest, 0.0, pitch, yaw};

  const Pose Tinv = to_isometry(f.body).inverse();
  for (Leg leg : {Leg::FL, Leg::FR}) {
    Vec3 q = Vec3::Constant(std::nan(""));
    model_.ik(leg, Tinv * (base * rel[index_of(leg)]), cfg_.posture.knee, q);
    set_leg_q(f.q, leg, q);
  }
  return f;
}

const Frame & Planner::posture_frame(Posture p) const
{
  switch (p) {
    case Posture::Rest: return rest_;
    case Posture::Stand: return stand_;
    case Posture::Sit: return sit_;
    case Posture::Unknown: break;
  }
  return unknown_;
}

bool Planner::self_check(std::string & error) const
{
  for (Posture p : {Posture::Stand, Posture::Rest, Posture::Sit}) {
    Trajectory t;
    t.name = std::string("posture ") + to_string(p);
    t.dt = dt();
    t.frames.push_back(posture_frame(p));
    const Verdict v = check(t, model_, cfg_.safety);
    if (!v.ok) {
      error = v.error;
      return false;
    }
  }
  return true;
}

Planner::Sway Planner::fit_sway(
  double stride, double turn, double cycle, double speed, double height) const
{
  // Run a canonical 5-cycle gait with no sway and, for every tick of the middle
  // cycle where exactly one foot is up, find the smallest purely sideways lean
  // that puts the CoG sway_margin_mm inside the other three feet. Each side
  // gets the worst case of its own two steps. Depends only on the gait, never
  // on how many cycles were asked for.
  constexpr int kCycles = 5;
  GaitConfig g = cfg_.gait;
  g.cycle_time = cycle;
  BodyPose body0 = stand_body_;
  body0.z = height;
  const auto rel = footprint_rel(height);
  std::array<Vec3, kNumLegs> feet0;
  for (Leg leg : kLegs) {feet0[index_of(leg)] = to_isometry(body0) * rel[index_of(leg)];}
  const GaitSchedule s = schedule_gait(body0, feet0, rel, g, stride, turn, kCycles,
      speed, dt());
  const Vec2 com = model_.com(stand_.q).head<2>();

  Sway sway;
  for (double t = s.t_pre + 2.0 * s.T; t < s.t_pre + 3.0 * s.T; t += dt()) {
    std::vector<Vec2> planted;
    int lifted = -1;
    const Pose Tb_inv = to_isometry(s.base_at(t)).inverse();
    for (int j = 0; j < kNumLegs; ++j) {
      bool contact = true;
      const Vec3 p = s.foot(j, t, 0.0, contact);
      if (contact) {planted.push_back((Tb_inv * p).head<2>());} else {lifted = j;}
    }
    if (planted.size() != 3) {continue;}

    // Lean away from the lifted foot: right when a left leg is up.
    const double dir = is_left(kLegs[lifted]) ? -1.0 : 1.0;
    double need = 0.0, best_d = 0.0, best_m = -1e9;
    for (double d = 0.0; d <= 60.0; d += 0.25) {
      const double m = support_margin(com + Vec2(0.0, dir * d), planted);
      if (m > best_m) {best_m = m; best_d = d;}
      if (m >= g.sway_margin_mm) {need = d; best_m = m; break;}
      need = best_d;
    }
    if (dir < 0.0) {
      sway.left_steps = std::min(sway.left_steps, -need);
    } else {
      sway.right_steps = std::max(sway.right_steps, need);
    }
  }
  return sway;
}

double Planner::neck_deg(Posture p) const
{
  const auto & n = cfg_.neck;
  switch (p) {
    case Posture::Rest: return std::clamp(n.rest_deg, n.min_deg, n.max_deg);
    case Posture::Sit: return std::clamp(n.sit_deg, n.min_deg, n.max_deg);
    default: return std::clamp(n.stand_deg, n.min_deg, n.max_deg);
  }
}

PlanResult Planner::plan(const Request & req, Posture from, const Joints & q_now,
  double neck_now) const
{
  PlanResult out;
  const auto & names = behaviors();
  if (std::find(names.begin(), names.end(), req.name) == names.end()) {
    out.error = "unknown behaviour '" + req.name + "'";
    return out;
  }

  double speed = req.speed > 0.0 ? std::clamp(req.speed, 0.5, 1.5) : 1.0;
  const auto & g = cfg_.gait;
  const auto & gc = cfg_.gesture;
  int count = req.count;
  if (req.name == "walk" || req.name == "turn_left" || req.name == "turn_right") {
    count = count > 0 ? std::min(count, g.max_cycles) : g.default_cycles;
  } else if (req.name == "beckon") {
    count = count > 0 ? std::min(count, 10) : gc.beckon_default;
  } else if (req.name == "happy") {
    count = count > 0 ? std::min(count, 10) : gc.happy_default;
  } else if (req.name == "nod") {
    count = count > 0 ? std::min(count, 10) : gc.nod_default;
  } else if (req.name == "wake_up") {
    count = count > 0 ? std::min(count, 6) : gc.wake_default;
  } else if (req.name == "medicine") {
    count = count > 0 ? std::min(count, 6) : gc.med_default;
  } else if (req.name == "lets_go") {
    count = count > 0 ? std::min(count, 6) : gc.go_default;
  } else if (req.name == "eat") {
    count = count > 0 ? std::min(count, 8) : gc.eat_default;
  }

  // Too fast for the servos is fixable by going slower; anything else is not.
  for (int attempt = 0; attempt < 4; ++attempt) {
    Builder b(*this, req.name, speed);
    b.start(from, q_now, neck_now);

    if (req.name == "rest") {
      b.go_to(Posture::Rest);
    } else if (req.name == "stand") {
      b.go_to(Posture::Stand);
    } else if (req.name == "sit") {
      b.go_to(Posture::Sit);
    } else if (req.name == "walk") {
      b.go_to(Posture::Stand);
      b.walk(req.option == "backward" ? -g.stride : g.stride, 0.0, count);
    } else if (req.name == "turn_left" || req.name == "turn_right") {
      b.go_to(Posture::Stand);
      const double turn = g.turn_deg_per_cycle * kDeg * (req.name == "turn_left" ? 1.0 : -1.0);
      b.walk(0.0, turn, count);
    } else if (req.name == "beckon") {
      b.go_to(Posture::Stand);
      b.beckon(req.option == "right" ? Leg::FR : Leg::FL, count);
    } else if (req.name == "alert") {
      // From lying down it gets up briskly -- the point is to be noticed.
      b.go_to(Posture::Stand, b.posture() == Posture::Rest ? 0.7 : 1.0);
      b.alert();
    } else if (req.name == "play_bow") {
      b.go_to(Posture::Stand);
      b.play_bow();
    } else if (req.name == "happy") {
      b.go_to(Posture::Stand);
      b.happy(count);
    } else if (req.name == "nod") {
      b.go_to(Posture::Stand);
      b.nod(count);
    } else if (req.name == "wake_up") {
      // Getting up is part of the behaviour, and it takes its time.
      b.go_to(Posture::Stand, cfg_.gesture.wake_rise_scale);
      b.wake_up(count);
    } else if (req.name == "medicine") {
      b.go_to(Posture::Stand);
      b.medicine(count);
    } else if (req.name == "lets_go") {
      b.go_to(Posture::Stand);
      b.lets_go(count);
    } else if (req.name == "eat") {
      b.go_to(Posture::Stand);
      b.eat(count);
    }

    if (!b.ok()) {
      out.error = b.error();
      return out;
    }
    Trajectory traj = b.finish();
    const Verdict v = check(traj, model_, cfg_.safety);
    if (v.ok) {
      out.ok = true;
      out.traj = std::move(traj);
      out.stats = v.stats;
      out.effective_speed = speed;
      out.effective_count = count;
      return out;
    }
    if (v.unsafe || speed <= 0.3) {
      out.error = v.error;
      return out;
    }
    speed *= 0.8;
  }
  out.error = req.name + ": could not get under the joint speed cap";
  return out;
}

int Planner::shortened_cycles(const Trajectory & active, std::size_t now_index) const
{
  const GaitInfo & g = active.gait;
  if (!g.valid || g.cycles <= 2) {return 0;}
  const double t_now =
    (static_cast<double>(now_index) - static_cast<double>(g.first_frame)) * active.dt;
  // Slow-down must start at least one full cycle after "now": every foot that
  // is in the air or about to lift then still lands exactly where it would have.
  const int n = std::max(2, static_cast<int>(std::ceil((t_now - g.pre_time) / g.cycle_time)) + 2);
  return n < g.cycles ? n : 0;
}

Joints Planner::idle(Posture p, double t) const
{
  if (p != Posture::Stand && p != Posture::Rest) {
    return posture_q(p);
  }
  // Breathing only ever lifts the body, so resting never dips toward the floor.
  const auto & gc = cfg_.gesture;
  const Frame & canon = posture_frame(p);
  Frame f = canon;
  f.body.z += gc.breathe_amp * 0.5 * (1.0 - std::cos(2.0 * M_PI * t / gc.breathe_period));
  const auto feet = feet_world(model_, canon);
  const Pose Tinv = to_isometry(f.body).inverse();
  for (Leg leg : kLegs) {
    Vec3 q;
    if (!model_.ik(leg, Tinv * feet[index_of(leg)], cfg_.posture.knee, q)) {
      return canon.q;
    }
    set_leg_q(f.q, leg, q);
  }
  return f.q;
}

}  // namespace pkun_motion
