#include "pkun_motion/trajectory.hpp"

#include <algorithm>
#include <cmath>
#include <sstream>

namespace pkun_motion
{

namespace
{

constexpr double kGravity = 9.80665e-3;      // N per gram
constexpr double kNmmPerKgcm = 98.0665;

double cross(const Vec2 & o, const Vec2 & a, const Vec2 & b)
{
  return (a.x() - o.x()) * (b.y() - o.y()) - (a.y() - o.y()) * (b.x() - o.x());
}

std::string at(const Trajectory & traj, std::size_t k)
{
  std::ostringstream os;
  os << traj.name << " t=" << traj.dt * static_cast<double>(k) << "s";
  return os.str();
}

}  // namespace

std::vector<Vec2> convex_hull(std::vector<Vec2> pts)
{
  // Monotone chain. A real hull, not an angular sort around the centroid:
  // a leg lying flat puts several contacts on one straight line.
  std::sort(pts.begin(), pts.end(), [](const Vec2 & a, const Vec2 & b) {
      return a.x() < b.x() || (a.x() == b.x() && a.y() < b.y());
    });
  pts.erase(std::unique(pts.begin(), pts.end(), [](const Vec2 & a, const Vec2 & b) {
      return (a - b).norm() < 1e-9;
    }), pts.end());
  if (pts.size() < 3) {
    return pts;
  }
  std::vector<Vec2> hull(2 * pts.size());
  std::size_t k = 0;
  for (std::size_t i = 0; i < pts.size(); ++i) {
    while (k >= 2 && cross(hull[k - 2], hull[k - 1], pts[i]) <= 1e-9) {--k;}
    hull[k++] = pts[i];
  }
  for (std::size_t i = pts.size() - 1, t = k + 1; i > 0; --i) {
    while (k >= t && cross(hull[k - 2], hull[k - 1], pts[i - 1]) <= 1e-9) {--k;}
    hull[k++] = pts[i - 1];
  }
  hull.resize(k - 1);
  return hull;
}

double support_margin(const Vec2 & com, const std::vector<Vec2> & pts)
{
  const auto hull = convex_hull(pts);
  if (hull.size() < 3) {
    return -std::numeric_limits<double>::infinity();
  }
  double margin = std::numeric_limits<double>::infinity();
  for (std::size_t i = 0; i < hull.size(); ++i) {
    const Vec2 & a = hull[i];
    const Vec2 & b = hull[(i + 1) % hull.size()];
    const Vec2 e = b - a;
    const double len = e.norm();
    if (len < 1e-9) {continue;}
    // Counter-clockwise hull: inside is to the left of every edge.
    margin = std::min(margin, (e.x() * (com.y() - a.y()) - e.y() * (com.x() - a.x())) / len);
  }
  return margin;
}

std::vector<Vec3> contact_points(const Frame & f, const RobotModel & model, double tol)
{
  const Pose T = to_isometry(f.body);
  std::vector<Vec3> out;
  for (Leg leg : kLegs) {
    if (!f.contact[index_of(leg)]) {continue;}
    for (const Vec3 & p : model.leg_points(leg, leg_q(f.q, leg))) {
      const Vec3 w = T * p;
      if (w.z() <= tol) {out.push_back(w);}
    }
  }
  return out;
}

Verdict check(const Trajectory & traj, const RobotModel & model,
  const SafetyConfig & safety, bool with_torque)
{
  Verdict v;
  Stats & s = v.stats;
  s.duration_s = traj.duration();
  s.mass_g = model.total_mass_g();

  bool error_is_speed = false;
  auto fail = [&v, &error_is_speed](const std::string & msg, bool speed_only = false) {
      v.ok = false;
      if (speed_only) {v.too_fast = true;} else {v.unsafe = true;}
      // Being too fast is fixable by replanning slower, so it is the least
      // interesting reason: anything else that turns up replaces it, or the
      // caller would be told to slow down over a problem slowing cannot fix.
      if (v.error.empty() || (error_is_speed && !speed_only)) {
        v.error = msg;
        error_is_speed = speed_only;
      }
    };

  if (traj.frames.empty()) {
    fail(traj.name + ": empty trajectory");
    return v;
  }

  const double tol = safety.limit_tol_deg * kDeg;
  const double cap = safety.rate_cap_dps;

  for (std::size_t k = 0; k < traj.frames.size(); ++k) {
    const Frame & f = traj.frames[k];

    if (!f.q.allFinite()) {
      fail(at(traj, k) + ": joint target is not finite");
      break;
    }
    std::string why;
    if (!model.within_limits(f.q, tol, &why)) {
      fail(at(traj, k) + ": " + why);
    }
    if (k > 0) {
      const double rate = (f.q - traj.frames[k - 1].q).cwiseAbs().maxCoeff() / traj.dt / kDeg;
      s.peak_rate_dps = std::max(s.peak_rate_dps, rate);
      if (rate > cap * (1.0 + 1e-6)) {
        std::ostringstream os;
        os << at(traj, k) << ": joint speed " << rate << " deg/s over the " << cap << " cap";
        fail(os.str(), true);
      }
    }
    if (!f.body_known) {continue;}

    const Pose T = to_isometry(f.body);
    for (const Vec3 & p : model.underbody()) {
      const double z = (T * p).z();
      s.min_clearance_mm = std::min(s.min_clearance_mm, z);
      if (z < safety.min_clearance_mm) {
        std::ostringstream os;
        os << at(traj, k) << ": underbody only " << z << " mm above the ground (need "
           << safety.min_clearance_mm << ")";
        fail(os.str());
      }
    }
    for (Leg leg : kLegs) {
      for (const Vec3 & p : model.leg_points(leg, leg_q(f.q, leg))) {
        const double z = (T * p).z();
        s.lowest_leg_mm = std::min(s.lowest_leg_mm, z);
        if (z < -safety.ground_tol_mm) {
          fail(at(traj, k) + ": a leg goes through the ground");
        }
      }
    }

    const auto pts = contact_points(f, model, safety.ground_tol_mm);
    const Vec3 com_w = T * model.com(f.q);
    if (f.static_check) {
      std::vector<Vec2> xy;
      for (const Vec3 & p : pts) {xy.emplace_back(p.x(), p.y());}
      const double margin = support_margin(com_w.head<2>(), xy);
      s.min_margin_mm = std::min(s.min_margin_mm, margin);
      if (margin < safety.min_margin_mm) {
        std::ostringstream os;
        os << at(traj, k) << ": stability margin " << margin << " mm (need "
           << safety.min_margin_mm << ")";
        fail(os.str());
      }
    }

    if (!with_torque && safety.max_torque_kgcm <= 0.0) {continue;}

    // Static torque: share the weight over one contact per loaded leg (its
    // lowest point), least-norm, then tau = J^T F for that point.
    struct Contact {Leg leg; int point; Vec3 world;};
    std::vector<Contact> cs;
    for (Leg leg : kLegs) {
      if (!f.contact[index_of(leg)]) {continue;}
      const auto lp = model.leg_points(leg, leg_q(f.q, leg));
      int best = kFoot;
      for (int i = 0; i < kNumLegPoints; ++i) {
        if ((T * lp[i]).z() < (T * lp[best]).z()) {best = i;}
      }
      cs.push_back({leg, best, T * lp[best]});
    }
    if (cs.size() < 3) {continue;}
    const double W = s.mass_g * kGravity;
    Eigen::MatrixXd A(3, cs.size());
    for (std::size_t i = 0; i < cs.size(); ++i) {
      A(0, i) = 1.0;
      A(1, i) = cs[i].world.x();
      A(2, i) = cs[i].world.y();
    }
    const Vec3 b(W, W * com_w.x(), W * com_w.y());
    const Eigen::Matrix3d AAt = A * A.transpose();
    if (std::abs(AAt.determinant()) < 1e-9) {continue;}
    const Eigen::VectorXd force = A.transpose() * AAt.ldlt().solve(b);
    for (std::size_t i = 0; i < cs.size(); ++i) {
      const Vec3 F_body = T.linear().transpose() * Vec3(0.0, 0.0, std::max(0.0, force(i)));
      const Vec3 tau = model.point_jacobian(cs[i].leg, leg_q(f.q, cs[i].leg), cs[i].point)
        .transpose() * F_body;
      const Vec3 kgcm = tau.cwiseAbs() / kNmmPerKgcm;
      s.peak_torque_kgcm = s.peak_torque_kgcm.cwiseMax(kgcm);
      if (safety.max_torque_kgcm > 0.0 && kgcm.maxCoeff() > safety.max_torque_kgcm) {
        static const char * kJoint[3] = {"abduction", "hip_pitch", "knee"};
        int j = 0;
        kgcm.maxCoeff(&j);
        std::ostringstream os;
        os << at(traj, k) << ": " << joint_names()[3 * index_of(cs[i].leg) + j] << " torque "
           << kgcm(j) << " kg.cm over the " << safety.max_torque_kgcm << " budget ("
           << kJoint[j] << ")";
        fail(os.str());
      }
    }
  }
  return v;
}

}  // namespace pkun_motion
