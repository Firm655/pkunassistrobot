#include "pkun_motion/motion_node.hpp"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <functional>
#include <initializer_list>
#include <sstream>
#include <stdexcept>
#include <thread>
#include <utility>
#include <vector>

#include "pkun_motion/config_params.hpp"
#include "pkun_motion/servo_window.hpp"

namespace pkun_motion
{
namespace
{

Posture posture_from_string(const std::string & s)
{
  if (s == "rest") {return Posture::Rest;}
  if (s == "stand") {return Posture::Stand;}
  if (s == "sit") {return Posture::Sit;}
  return Posture::Unknown;
}

bool is_gait(const std::string & name)
{
  return name == "walk" || name == "turn_left" || name == "turn_right";
}

std::string check_option(const std::string & name, const std::string & option)
{
  if (option.empty()) {return "";}
  if (name == "walk" && (option == "forward" || option == "backward")) {return "";}
  if (name == "beckon" && (option == "left" || option == "right")) {return "";}
  return "option '" + option + "' is not valid for '" + name + "'";
}

}  // namespace

MotionNode::MotionNode(const rclcpp::NodeOptions & options)
: rclcpp::Node("motion", options)
{
  MotionConfig cfg = load_config();
  apply_servo_limits(cfg);
  planner_ = std::make_unique<Planner>(cfg);
  dt_ = planner_->dt();

  // A configuration the robot cannot stand in stops here, at launch -- not
  // halfway through the first behaviour.
  std::string error;
  if (!planner_->self_check(error)) {
    if (error.find("_knee") != std::string::npos) {
      error += ". The knee's range comes from its servo pulse window: with the horn "
        "fitted so a straight leg sits near mid-travel, only ~90 deg of bend fits in "
        "pulse_min_us..pulse_max_us. Check the knee neutral_us/direction in servo_calib.json (README: 'Calibration') "
        "or raise posture.stand_height";
    }
    throw std::runtime_error("motion config rejected: " + error);
  }

  require_driver_ = declare_parameter<bool>("require_driver", true);
  park_posture_ = posture_from_string(declare_parameter<std::string>("park_posture", "rest"));
  const std::string startup = declare_parameter<std::string>("startup_posture", "rest");
  posture_ = posture_from_string(startup);
  q_ = planner_->posture_q(posture_ == Posture::Unknown ? Posture::Rest : posture_);
  neck_ = planner_->neck_deg(posture_ == Posture::Unknown ? Posture::Rest : posture_) * kDeg;
  breathe_ = declare_parameter<bool>("idle_breathing", false);
  const double feedback_hz = declare_parameter<double>("feedback_rate_hz", 5.0);
  feedback_every_ = std::max(1, static_cast<int>(std::lround(cfg.rate_hz / feedback_hz)));

  // Dry-run every behaviour from every posture once, so a config that plans
  // one pose fine but fails a gesture is reported now, by name.
  int failures = 0;
  for (Posture from : {Posture::Rest, Posture::Stand, Posture::Sit}) {
    for (const auto & name : Planner::behaviors()) {
      Request r;
      r.name = name;
      const auto res = planner_->plan(r, from, planner_->posture_q(from));
      if (!res.ok) {
        ++failures;
        RCLCPP_WARN(get_logger(), "self-test: %s from %s fails: %s",
          name.c_str(), to_string(from), res.error.c_str());
      }
    }
  }
  RCLCPP_INFO(get_logger(),
    "planner ready: stand %.0f mm, rest %.1f mm, %.0f g, %s", cfg.posture.stand_height,
    planner_->rest_height(), planner_->model().total_mass_g(),
    failures == 0 ? "every behaviour plans from every posture" : "SOME BEHAVIOURS FAIL (see above)");

  command_pub_ = create_publisher<pkun_msgs::msg::JointCommand>("joint_command", rclcpp::QoS(10));
  status_pub_ = create_publisher<pkun_msgs::msg::MotionStatus>("~/status", rclcpp::QoS(10));
  servo_sub_ = create_subscription<pkun_msgs::msg::ServoState>(
    declare_parameter<std::string>("servo_state_topic", "servo_driver/servo_state"),
    rclcpp::QoS(10), std::bind(&MotionNode::on_servo_state, this, std::placeholders::_1));

  action_server_ = rclcpp_action::create_server<Behavior>(
    this, "~/behavior",
    std::bind(&MotionNode::on_goal, this, std::placeholders::_1, std::placeholders::_2),
    std::bind(&MotionNode::on_cancel, this, std::placeholders::_1),
    std::bind(&MotionNode::on_accepted, this, std::placeholders::_1));

  tick_timer_ = create_wall_timer(
    std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::duration<double>(dt_)),
    std::bind(&MotionNode::on_tick, this));
  status_timer_ = create_wall_timer(
    std::chrono::milliseconds(200), std::bind(&MotionNode::publish_status, this));

  RCLCPP_INFO(get_logger(), "holding the %s pose; send goals to %s",
    to_string(posture_), (std::string(get_fully_qualified_name()) + "/behavior").c_str());
}

// ---------------------------------------------------------------------------
// configuration
// ---------------------------------------------------------------------------

MotionConfig MotionNode::load_config()
{
  MotionConfig c;
  bind_config(c,
    [this](const std::string & name, double & v) {v = declare_parameter<double>(name, v);},
    [this](const std::string & name, int & v) {
      v = static_cast<int>(declare_parameter<int64_t>(name, v));
    },
    [this](const std::string & name, std::vector<double> & v) {
      v = declare_parameter<std::vector<double>>(name, v);
    });
  return c;
}

void MotionNode::apply_servo_limits(MotionConfig & cfg)
{
  // Mechanical limits, per joint type.
  Vec3 lo(-55.0, -90.0, 0.0);
  Vec3 hi(55.0, 90.0, 150.0);
  const char * type[3] = {"abduction", "hip_pitch", "knee"};
  for (int j = 0; j < 3; ++j) {
    lo(j) = declare_parameter<double>(std::string("limits.") + type[j] + "_min_deg", lo(j));
    hi(j) = declare_parameter<double>(std::string("limits.") + type[j] + "_max_deg", hi(j));
  }
  cfg.limits = JointLimits::uniform(lo * kDeg, hi * kDeg);

  // Then what each servo's pulse window allows, from the very same servos.yaml
  // the driver loads. Planning inside this means the driver never has to clip
  // a command -- a clipped leg is a leg that is not where the plan thinks.
  const bool use_cal = declare_parameter<bool>("limits_from_servo_calibration", true);
  const double min_us = declare_parameter<double>("pulse_min_us", 500.0);
  const double max_us = declare_parameter<double>("pulse_max_us", 2500.0);
  const double margin = declare_parameter<double>("servo_window_margin_deg", 1.0) * kDeg;
  if (!use_cal) {
    RCLCPP_WARN(get_logger(), "servo calibration ignored -- mechanical joint limits only");
    return;
  }

  std::ostringstream table;
  for (int k = 0; k < kNumJoints; ++k) {
    const std::string pre = "servos." + joint_names()[k] + ".";
    ServoCalibration cal;
    cal.center_us = declare_parameter<double>(pre + "center_us", NAN);
    cal.us_per_deg = declare_parameter<double>(pre + "us_per_deg", 11.111);
    cal.invert = declare_parameter<bool>(pre + "invert", false);
    cal.trim_deg = declare_parameter<double>(pre + "trim_deg", 0.0);
    if (!std::isfinite(cal.center_us) || cal.us_per_deg <= 0.0) {
      throw std::runtime_error(
              "no servo calibration for '" + joint_names()[k] +
              "' -- load pkun_servo_driver/config/servos.yaml into this node too, or set "
              "limits_from_servo_calibration: false");
    }
    const AngleRange w = servo_window(cal, min_us, max_us);
    cfg.limits.lo(k) = std::max(cfg.limits.lo(k), w.lo + margin);
    cfg.limits.hi(k) = std::min(cfg.limits.hi(k), w.hi - margin);
    if (cfg.limits.lo(k) >= cfg.limits.hi(k)) {
      throw std::runtime_error("servo window leaves no range for '" + joint_names()[k] + "'");
    }
    table << "\n  " << joint_names()[k] << ": " << std::lround(cfg.limits.lo(k) / kDeg) << " .. "
          << std::lround(cfg.limits.hi(k) / kDeg) << " deg";
  }
  RCLCPP_INFO(get_logger(), "joint limits (mechanism x servo pulse window):%s",
    table.str().c_str());

  // The neck is optional: only if servos.yaml has head_pitch (calibrated with
  // servo_calib.py --head). Its range is the motion's own, narrowed to the
  // calibrated stops and the pulse window.
  ServoCalibration nc;
  nc.center_us = declare_parameter<double>("servos.head_pitch.center_us", NAN);
  nc.us_per_deg = declare_parameter<double>("servos.head_pitch.us_per_deg", 11.111);
  nc.invert = declare_parameter<bool>("servos.head_pitch.invert", false);
  nc.trim_deg = declare_parameter<double>("servos.head_pitch.trim_deg", 0.0);
  const double mech_lo = declare_parameter<double>("servos.head_pitch.min_deg", -90.0);
  const double mech_hi = declare_parameter<double>("servos.head_pitch.max_deg", 90.0);
  if (!std::isfinite(nc.center_us) || nc.us_per_deg <= 0.0) {
    RCLCPP_INFO(get_logger(), "no head_pitch servo in servos.yaml -- neck not driven");
    return;
  }
  const AngleRange w = servo_window(nc, min_us, max_us);
  const double m = margin / kDeg;
  cfg.neck.min_deg = std::max({cfg.neck.min_deg, mech_lo + m, w.lo / kDeg + m});
  cfg.neck.max_deg = std::min({cfg.neck.max_deg, mech_hi - m, w.hi / kDeg - m});
  if (cfg.neck.min_deg >= 0.0 || cfg.neck.max_deg <= 0.0) {
    RCLCPP_WARN(get_logger(), "head_pitch range %.0f .. %.0f deg does not include straight "
      "ahead -- recalibrate the neck; not driving it", cfg.neck.min_deg, cfg.neck.max_deg);
    return;
  }
  has_neck_ = true;
  RCLCPP_INFO(get_logger(), "neck (head_pitch): %.0f .. %.0f deg", cfg.neck.min_deg,
    cfg.neck.max_deg);
}

// ---------------------------------------------------------------------------
// control loop
// ---------------------------------------------------------------------------

void MotionNode::on_tick()
{
  if (pending_) {
    start_pending();
  }

  if (active_) {
    if (require_driver_ && !driver_alive()) {
      posture_ = Posture::Unknown;
      finish_active(false, "servo driver stopped responding");
    }
  }

  if (active_) {
    if (active_->is_canceling() && !shortened_) {
      shorten_active();
    }
    const auto & frames = plan_.traj.frames;
    q_ = frames[index_].q;
    neck_ = frames[index_].neck;
    ++index_;
    if (index_ % static_cast<std::size_t>(feedback_every_) == 0) {
      auto fb = std::make_shared<Behavior::Feedback>();
      fb->progress = static_cast<float>(index_) / static_cast<float>(frames.size());
      fb->posture = to_string(posture_);
      active_->publish_feedback(fb);
    }
    if (index_ >= frames.size()) {
      posture_ = plan_.traj.end_posture;
      idle_t_ = 0.0;
      finish_active(true, "done");
    }
  } else if (breathe_ && (posture_ == Posture::Stand || posture_ == Posture::Rest)) {
    const Joints q = planner_->idle(posture_, idle_t_);
    const double step = (q - q_).cwiseAbs().maxCoeff();
    // Breathing is continuous from the canonical pose; anything else (a
    // posture that did not land exactly) is held rather than snapped to.
    if (planner_->model().within_limits(q, 0.0) && step < 2.0 * kDeg) {
      q_ = q;
      idle_t_ += dt_;
    }
  }

  publish_command(q_);
}

void MotionNode::publish_command(const Joints & q)
{
  pkun_msgs::msg::JointCommand msg;
  msg.header.stamp = now();
  msg.name.assign(joint_names().begin(), joint_names().end());
  msg.position.resize(kNumJoints);
  for (int k = 0; k < kNumJoints; ++k) {msg.position[k] = q(k);}
  if (has_neck_) {
    msg.name.push_back("head_pitch");
    msg.position.push_back(neck_);
  }
  msg.duration = dt_;
  command_pub_->publish(msg);
}

void MotionNode::publish_status()
{
  pkun_msgs::msg::MotionStatus msg;
  msg.header.stamp = now();
  // Mid-behaviour the pose is none of the canonical ones, and saying "unknown"
  // tells a caller nothing useful. While busy, report where it will be when
  // this finishes; "unknown" then means what it should: nobody knows, because
  // the servos were released or the robot has not been commanded yet.
  msg.posture = to_string(posture_);
  msg.busy = static_cast<bool>(active_) || static_cast<bool>(pending_);
  if (active_) {
    msg.behavior = request_.name;
    msg.progress = static_cast<float>(index_) / static_cast<float>(plan_.traj.frames.size());
    if (plan_.traj.end_posture != Posture::Unknown) {
      msg.posture = to_string(plan_.traj.end_posture);
    }
  }
  status_pub_->publish(msg);
}

bool MotionNode::driver_alive() const
{
  return driver_seen_ && (now() - last_driver_msg_).seconds() < 1.0;
}

void MotionNode::on_servo_state(const pkun_msgs::msg::ServoState::SharedPtr msg)
{
  driver_seen_ = true;
  last_driver_msg_ = now();
  const bool was = torque_;
  torque_ = msg->torque_enabled;
  if (was && !torque_) {
    // Limp legs go wherever gravity takes them: nothing about the pose is
    // known any more. The next behaviour recovers slowly in joint space.
    posture_ = Posture::Unknown;
    RCLCPP_WARN(get_logger(), "servo torque released -- posture now unknown");
    if (active_) {
      finish_active(false, "servo torque was released");
    }
  }
}

void MotionNode::park()
{
  if (active_) {
    finish_active(false, "shutting down");
  }
  if (park_posture_ == Posture::Unknown) {
    RCLCPP_INFO(get_logger(), "park_posture is none -- leaving the legs where they are");
    return;
  }
  Request req;
  req.name = to_string(park_posture_);
  const PlanResult res = planner_->plan(req, posture_, q_, neck_);
  if (!res.ok || res.traj.frames.empty()) {
    RCLCPP_ERROR(get_logger(), "cannot park: %s. The legs hold their last pose.",
      res.error.c_str());
    return;
  }
  RCLCPP_INFO(get_logger(), "parking into %s over %.1f s", to_string(park_posture_),
    res.stats.duration_s);
  const auto period = std::chrono::duration<double>(dt_);
  for (const Frame & f : res.traj.frames) {
    if (!rclcpp::ok()) {break;}
    q_ = f.q;
    neck_ = f.neck;
    publish_command(q_);
    std::this_thread::sleep_for(std::chrono::duration_cast<std::chrono::nanoseconds>(period));
  }
  posture_ = res.traj.end_posture;
  // A few more ticks so the driver's own rate limiter lands on the pose before
  // the process goes away and the channels are released.
  for (int i = 0; i < 10 && rclcpp::ok(); ++i) {
    publish_command(q_);
    std::this_thread::sleep_for(std::chrono::duration_cast<std::chrono::nanoseconds>(period));
  }
  RCLCPP_INFO(get_logger(), "parked in %s", to_string(posture_));
}

// ---------------------------------------------------------------------------
// action server
// ---------------------------------------------------------------------------

rclcpp_action::GoalResponse MotionNode::on_goal(
  const rclcpp_action::GoalUUID &, std::shared_ptr<const Behavior::Goal> goal)
{
  auto reject = [this, &goal](const std::string & why) {
      RCLCPP_WARN(get_logger(), "rejected '%s': %s", goal->name.c_str(), why.c_str());
      return rclcpp_action::GoalResponse::REJECT;
    };
  const auto & names = Planner::behaviors();
  if (std::find(names.begin(), names.end(), goal->name) == names.end()) {
    return reject("unknown behaviour");
  }
  if (const std::string bad = check_option(goal->name, goal->option); !bad.empty()) {
    return reject(bad);
  }
  if (goal->count < 0 || !std::isfinite(goal->speed) || goal->speed < 0.0f) {
    return reject("count and speed must not be negative");
  }
  if (active_ || pending_) {
    return reject("busy with '" + request_.name + "' -- cancel it first");
  }
  if (require_driver_ && !driver_alive()) {
    return reject("servo driver is not running");
  }
  if (require_driver_ && !torque_) {
    return reject("servo torque is off");
  }
  return rclcpp_action::GoalResponse::ACCEPT_AND_EXECUTE;
}

rclcpp_action::CancelResponse MotionNode::on_cancel(std::shared_ptr<GoalHandle> goal)
{
  if (goal == active_ || goal == pending_) {
    RCLCPP_INFO(get_logger(), "cancel requested");
    return rclcpp_action::CancelResponse::ACCEPT;
  }
  return rclcpp_action::CancelResponse::REJECT;
}

void MotionNode::on_accepted(std::shared_ptr<GoalHandle> goal)
{
  // Planned on the next tick, in the same thread as everything else.
  pending_ = std::move(goal);
}

void MotionNode::start_pending()
{
  auto goal = std::move(pending_);
  pending_.reset();
  auto result = std::make_shared<Behavior::Result>();
  result->final_posture = to_string(posture_);

  if (goal->is_canceling()) {
    result->message = "cancelled before it started";
    goal->canceled(result);
    return;
  }
  // Accepted with ACCEPT_AND_EXECUTE: the goal is already executing.

  const auto & g = *goal->get_goal();
  Request req;
  req.name = g.name;
  req.option = g.option;
  req.count = g.count;
  req.speed = g.speed;

  const auto t0 = std::chrono::steady_clock::now();
  PlanResult res = planner_->plan(req, posture_, q_, neck_);
  const double ms = std::chrono::duration<double, std::milli>(
    std::chrono::steady_clock::now() - t0).count();

  std::string error;
  if (!res.ok) {
    error = res.error;
  } else if (res.traj.frames.empty()) {
    error = "empty plan";
  } else if ((res.traj.frames.front().q - q_).cwiseAbs().maxCoeff() > 1e-6) {
    error = "plan does not start at the current pose";   // never jump
  }
  if (!error.empty()) {
    RCLCPP_ERROR(get_logger(), "'%s' not started: %s", req.name.c_str(), error.c_str());
    result->success = false;
    result->message = error;
    goal->abort(result);
    return;
  }

  RCLCPP_INFO(get_logger(),
    "%s%s%s from %s: %.1f s, peak %.0f deg/s, margin %.1f mm, clearance %.1f mm%s "
    "(planned in %.0f ms)", req.name.c_str(), req.option.empty() ? "" : " ",
    req.option.c_str(), to_string(posture_), res.stats.duration_s, res.stats.peak_rate_dps,
    res.stats.min_margin_mm, res.stats.min_clearance_mm,
    res.effective_speed < req.speed - 1e-6 ? ", slowed to fit the rate cap" : "", ms);

  request_ = req;
  from_ = posture_;
  q_start_ = q_;
  neck_start_ = neck_;
  plan_ = std::move(res);
  index_ = 0;
  shortened_ = false;
  active_ = std::move(goal);
  // Mid-behaviour the pose is none of the canonical ones.
  posture_ = Posture::Unknown;
}

void MotionNode::shorten_active()
{
  shortened_ = true;
  if (!is_gait(request_.name)) {
    // A gesture cannot stop mid-pose -- that would leave the body tilted --
    // but it does not have to play out either: settle straight back to the
    // posture it was going to end in. That turns a 12 s wait into about 1 s,
    // which matters when the thing interrupting is the resident asking for help.
    const Posture back = plan_.traj.end_posture;
    Request req;
    req.name = to_string(back);            // "rest" | "stand" | "sit"
    PlanResult res = planner_->plan(req, back, q_, neck_);
    if (!res.ok || res.traj.frames.empty() ||
      (res.traj.frames.front().q - q_).cwiseAbs().maxCoeff() > 1e-6)
    {
      RCLCPP_WARN(get_logger(), "could not cut '%s' short (%s) -- letting it finish",
        request_.name.c_str(), res.error.c_str());
      return;
    }
    RCLCPP_INFO(get_logger(), "cutting '%s' short: settling back to %s (%.1f s)",
      request_.name.c_str(), to_string(back), res.stats.duration_s);
    plan_ = std::move(res);
    index_ = 0;
    return;
  }
  const int cycles = planner_->shortened_cycles(plan_.traj, index_);
  if (cycles <= 0) {
    return;
  }
  Request req = request_;
  req.count = cycles;
  req.speed = plan_.effective_speed;
  PlanResult res = planner_->plan(req, from_, q_start_, neck_start_);
  if (!res.ok || res.traj.frames.size() <= index_) {
    RCLCPP_WARN(get_logger(), "could not shorten the walk (%s) -- finishing it",
      res.error.c_str());
    return;
  }
  // The new plan must be the old one, frame for frame, up to now.
  for (std::size_t k = 0; k <= index_ && k < plan_.traj.frames.size(); ++k) {
    if ((res.traj.frames[k].q - plan_.traj.frames[k].q).cwiseAbs().maxCoeff() > 1e-9) {
      RCLCPP_WARN(get_logger(), "shortened walk diverges at frame %zu -- finishing it", k);
      return;
    }
  }
  RCLCPP_INFO(get_logger(), "stopping after %d cycle(s) instead of %d",
    cycles, plan_.effective_count);
  plan_ = std::move(res);
}

void MotionNode::finish_active(bool success, const std::string & message)
{
  auto result = std::make_shared<Behavior::Result>();
  result->success = success;
  result->message = message;
  result->final_posture = to_string(posture_);
  if (active_->is_canceling()) {
    result->message = success ? "cancelled; stopped safely" : message;
    active_->canceled(result);
  } else if (success) {
    active_->succeed(result);
  } else {
    active_->abort(result);
  }
  RCLCPP_INFO(get_logger(), "%s: %s, now %s", request_.name.c_str(), result->message.c_str(),
    result->final_posture.c_str());
  active_.reset();
  plan_ = PlanResult{};
  index_ = 0;
}

}  // namespace pkun_motion

#include "rclcpp_components/register_node_macro.hpp"
RCLCPP_COMPONENTS_REGISTER_NODE(pkun_motion::MotionNode)
