// motion_report — plan every behaviour offline and print what the robot would
// have to do: duration, peak joint speed, stability margin, underbody
// clearance and static joint torque. Touches no hardware and needs no ROS.
//
//   ros2 run pkun_motion motion_report                  all behaviours, from stand
//   ros2 run pkun_motion motion_report rest             starting from lying down
//   ros2 run pkun_motion motion_report stand servos.yaml
//        ...with each joint limited to its servo pulse window, as the node does
//   ros2 run pkun_motion motion_report stand servos.yaml motion.yaml
//        ...and with motion.yaml's tuning and payload instead of the built-in
//        defaults (config.hpp) -- what the robot really runs. "-" skips servos.yaml.

#include <cmath>
#include <cstdio>
#include <fstream>
#include <regex>
#include <map>
#include <stdexcept>
#include <string>
#include <vector>

#include "rcl_yaml_param_parser/parser.h"

#include "pkun_motion/config_params.hpp"
#include "pkun_motion/planner.hpp"
#include "pkun_motion/servo_window.hpp"

using pkun_motion::Posture;

namespace
{

/// Just enough YAML for the generated servos.yaml: one flow map per joint.
bool apply_servos_yaml(const std::string & path, pkun_motion::MotionConfig & cfg)
{
  std::ifstream in(path);
  if (!in) {
    std::fprintf(stderr, "cannot read %s\n", path.c_str());
    return false;
  }
  double min_us = 500.0, max_us = 2500.0;
  const std::regex pmin(R"(^\s*pulse_min_us:\s*([-0-9.]+))"), pmax(R"(^\s*pulse_max_us:\s*([-0-9.]+))");
  const std::regex joint(R"(^\s*(\w+):\s*\{(.*)\})");
  auto field = [](const std::string & body, const std::string & key, std::string & out) {
      std::smatch m;
      if (std::regex_search(body, m, std::regex(key + R"(:\s*([-\w.]+))"))) {out = m[1]; return true;}
      return false;
    };
  std::vector<std::pair<std::string, std::string>> joints;
  std::string line;
  std::smatch m;
  while (std::getline(in, line)) {
    if (std::regex_search(line, m, pmin)) {min_us = std::stod(m[1]);}
    if (std::regex_search(line, m, pmax)) {max_us = std::stod(m[1]);}
    if (std::regex_search(line, m, joint)) {joints.emplace_back(m[1], m[2]);}
  }
  int found = 0;
  for (int k = 0; k < pkun_motion::kNumJoints; ++k) {
    for (const auto & [name, body] : joints) {
      if (name != pkun_motion::joint_names()[k]) {continue;}
      pkun_motion::ServoCalibration cal;
      std::string v;
      if (!field(body, "center_us", v)) {continue;}
      cal.center_us = std::stod(v);
      if (field(body, "us_per_deg", v)) {cal.us_per_deg = std::stod(v);}
      if (field(body, "invert", v)) {cal.invert = (v == "true");}
      if (field(body, "trim_deg", v)) {cal.trim_deg = std::stod(v);}
      const auto w = pkun_motion::servo_window(cal, min_us, max_us);
      const double margin = 1.0 * pkun_motion::kDeg;   // servo_window_margin_deg
      cfg.limits.lo(k) = std::max(cfg.limits.lo(k), w.lo + margin);
      cfg.limits.hi(k) = std::min(cfg.limits.hi(k), w.hi - margin);
      ++found;
    }
  }
  if (found != pkun_motion::kNumJoints) {
    std::fprintf(stderr, "%s: found calibration for %d of 12 joints\n", path.c_str(), found);
    return false;
  }
  std::printf("joint limits from %s (pulse %.0f..%.0f us):\n", path.c_str(), min_us, max_us);
  for (int k = 0; k < pkun_motion::kNumJoints; ++k) {
    std::printf("  %-14s %6.1f .. %6.1f deg\n", pkun_motion::joint_names()[k].c_str(),
      cfg.limits.lo(k) / pkun_motion::kDeg, cfg.limits.hi(k) / pkun_motion::kDeg);
  }
  std::printf("\n");
  return true;
}

/// motion.yaml through the same parameter list the node declares. Every node
/// section in the file counts ("/**" is the only one today).
bool apply_motion_yaml(const std::string & path, pkun_motion::MotionConfig & cfg)
{
  rcl_params_t * params = rcl_yaml_node_struct_init(rcutils_get_default_allocator());
  if (!params || !rcl_parse_yaml_file(path.c_str(), params)) {
    std::fprintf(stderr, "cannot parse %s\n", path.c_str());
    if (params) {rcl_yaml_node_struct_fini(params);}
    return false;
  }
  std::map<std::string, const rcl_variant_t *> values;
  for (std::size_t n = 0; n < params->num_nodes; ++n) {
    const auto & np = params->params[n];
    for (std::size_t k = 0; k < np.num_params; ++k) {
      values[np.parameter_names[k]] = &np.parameter_values[k];
    }
  }
  auto find = [&values](const std::string & name) -> const rcl_variant_t * {
      const auto it = values.find(name);
      return it == values.end() ? nullptr : it->second;
    };
  bool ok = true;
  try {
    pkun_motion::bind_config(cfg,
      [&](const std::string & name, double & v) {
        if (const auto * x = find(name)) {
          if (x->double_value) {v = *x->double_value;}
          if (x->integer_value) {v = static_cast<double>(*x->integer_value);}
        }
      },
      [&](const std::string & name, int & v) {
        if (const auto * x = find(name); x && x->integer_value) {
          v = static_cast<int>(*x->integer_value);
        }
      },
      [&](const std::string & name, std::vector<double> & v) {
        if (const auto * x = find(name); x && x->double_array_value) {
          v.assign(x->double_array_value->values,
            x->double_array_value->values + x->double_array_value->size);
        }
      });
  } catch (const std::exception & e) {
    std::fprintf(stderr, "%s: %s\n", path.c_str(), e.what());
    ok = false;
  }
  rcl_yaml_node_struct_fini(params);
  if (ok) {std::printf("tuning and payload from %s\n\n", path.c_str());}
  return ok;
}

}  // namespace

int main(int argc, char ** argv)
{
  Posture from = Posture::Stand;
  if (argc > 1) {
    const std::string a = argv[1];
    if (a == "rest") {from = Posture::Rest;}
    if (a == "sit") {from = Posture::Sit;}
  }

  pkun_motion::MotionConfig cfg;
  if (argc > 3 && !apply_motion_yaml(argv[3], cfg)) {
    return 2;
  }
  if (argc > 2 && std::string(argv[2]) != "-" && !apply_servos_yaml(argv[2], cfg)) {
    return 2;
  }
  const pkun_motion::Planner planner{cfg};
  const auto & model = planner.model();
  std::string err;
  const bool postures_ok = planner.self_check(err);

  std::printf("P-kun motion report  (mass %.0f g, stand %.0f mm, rest %.0f mm, from %s)\n",
    model.total_mass_g(), planner.config().posture.stand_height, planner.rest_height(),
    pkun_motion::to_string(from));
  std::printf("canonical postures: %s%s\n\n", postures_ok ? "ok" : "FAIL: ", err.c_str());

  for (Posture p : {Posture::Stand, Posture::Rest, Posture::Sit}) {
    const auto q = planner.posture_q(p);
    std::printf("  %-6s", pkun_motion::to_string(p));
    for (int i = 0; i < 12; ++i) {
      std::printf("%s%6.1f", i % 3 == 0 ? "  |" : "", q(i) / pkun_motion::kDeg);
    }
    std::printf("\n");
  }
  std::printf("\n%-12s %6s %7s %8s %8s %8s   %s\n", "behaviour", "sec", "deg/s",
    "margin", "clear", "speed", "peak torque kg.cm (abd / hip / knee)");
  std::printf("-------------------------------------------------------------------------------"
    "-----------\n");

  const auto q0 = planner.posture_q(from);
  for (const auto & name : pkun_motion::Planner::behaviors()) {
    pkun_motion::Request req;
    req.name = name;
    const auto res = planner.plan(req, from, q0);
    if (!res.ok) {
      std::printf("%-12s REJECTED: %s\n", name.c_str(), res.error.c_str());
      continue;
    }
    const auto v = pkun_motion::check(res.traj, model, planner.config().safety, true);
    const auto & s = v.stats;
    std::printf("%-12s %6.1f %7.0f %8.1f %8.1f %8.2f   %5.2f / %5.2f / %5.2f   -> %s\n",
      name.c_str(), s.duration_s, s.peak_rate_dps, s.min_margin_mm, s.min_clearance_mm,
      res.effective_speed, s.peak_torque_kgcm(0), s.peak_torque_kgcm(1), s.peak_torque_kgcm(2),
      pkun_motion::to_string(res.traj.end_posture));
  }
  return postures_ok ? 0 : 1;
}
