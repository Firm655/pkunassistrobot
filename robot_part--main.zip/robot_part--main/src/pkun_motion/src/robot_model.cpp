#include "pkun_motion/robot_model.hpp"

#include <algorithm>
#include <cmath>
#include <sstream>
#include <utility>

namespace pkun_motion
{

// ---------------------------------------------------------------------------
// types.hpp helpers
// ---------------------------------------------------------------------------

const std::array<std::string, kNumJoints> & joint_names()
{
  static const std::array<std::string, kNumJoints> names{
    "fl_abduction", "fl_hip_pitch", "fl_knee",
    "fr_abduction", "fr_hip_pitch", "fr_knee",
    "rl_abduction", "rl_hip_pitch", "rl_knee",
    "rr_abduction", "rr_hip_pitch", "rr_knee"};
  return names;
}

const char * to_string(Posture posture)
{
  switch (posture) {
    case Posture::Rest: return "rest";
    case Posture::Stand: return "stand";
    case Posture::Sit: return "sit";
    case Posture::Unknown: break;
  }
  return "unknown";
}

Pose to_isometry(const BodyPose & p)
{
  // +pitch lifts the nose, which is a rotation of -pitch about +y.
  Pose T = Pose::Identity();
  T.linear() = (Eigen::AngleAxisd(p.yaw, Vec3::UnitZ()) *
    Eigen::AngleAxisd(-p.pitch, Vec3::UnitY()) *
    Eigen::AngleAxisd(p.roll, Vec3::UnitX())).toRotationMatrix();
  T.translation() = Vec3(p.x, p.y, p.z);
  return T;
}

BodyPose lerp(const BodyPose & a, const BodyPose & b, double s)
{
  auto mix = [s](double u, double v) {return u + (v - u) * s;};
  return BodyPose{mix(a.x, b.x), mix(a.y, b.y), mix(a.z, b.z),
    mix(a.roll, b.roll), mix(a.pitch, b.pitch), mix(a.yaw, b.yaw)};
}

// ---------------------------------------------------------------------------
// kinematics
// ---------------------------------------------------------------------------

namespace
{

Eigen::Matrix4d dh(double theta, double d, double a, double alpha)
{
  const double ct = std::cos(theta), st = std::sin(theta);
  const double ca = std::cos(alpha), sa = std::sin(alpha);
  Eigen::Matrix4d T;
  T << ct, -st * ca, st * sa, a * ct,
    st, ct * ca, -ct * sa, a * st,
    0.0, sa, ca, d,
    0.0, 0.0, 0.0, 1.0;
  return T;
}

/// Rot_z(theta) * Trans_z(d): the corner a DH row turns before walking along a.
Eigen::Matrix4d kink(double theta, double d)
{
  Eigen::Matrix4d T = Eigen::Matrix4d::Identity();
  T(0, 0) = std::cos(theta);
  T(0, 1) = -std::sin(theta);
  T(1, 0) = std::sin(theta);
  T(1, 1) = std::cos(theta);
  T(2, 3) = d;
  return T;
}

}  // namespace

std::array<double, 4> leg_signs(Leg leg)
{
  switch (leg) {
    case Leg::FL: return {+1.0, +1.0, +1.0, +1.0};
    case Leg::FR: return {+1.0, -1.0, -1.0, -1.0};
    case Leg::RL: return {-1.0, +1.0, +1.0, +1.0};
    case Leg::RR: return {-1.0, -1.0, -1.0, -1.0};
  }
  return {+1.0, +1.0, +1.0, +1.0};
}

RobotModel::RobotModel(
  Geometry geometry, JointLimits limits, MassModel mass, std::vector<Vec3> underbody)
: geometry_(geometry), limits_(limits), mass_(std::move(mass)), underbody_(std::move(underbody))
{
}

Vec3 RobotModel::hip(Leg leg) const
{
  const auto s = leg_signs(leg);
  return Vec3(s[0] * geometry_.a, s[1] * geometry_.b, -geometry_.c);
}

std::array<Vec3, kNumLegPoints> RobotModel::leg_points(Leg leg, const Vec3 & q) const
{
  const auto s = leg_signs(leg);
  const Geometry & g = geometry_;

  Eigen::Matrix4d T = Eigen::Matrix4d::Identity();
  T(0, 0) = 0.0;
  T(0, 2) = 1.0;   // RotY(+90deg)
  T(2, 0) = -1.0;
  T(2, 2) = 0.0;
  T.block<3, 1>(0, 3) = hip(leg);

  std::array<Vec3, kNumLegPoints> pts;
  pts[kHipAbduction] = T.block<3, 1>(0, 3);

  T = T * dh(q(0), 0.0, g.h, -M_PI / 2.0);
  pts[kHipPitch] = T.block<3, 1>(0, 3);

  const double d_row2 = s[2] * g.d1;
  pts[kThighKink] = (T * kink(q(1), d_row2)).block<3, 1>(0, 3);
  T = T * dh(q(1), d_row2, g.l1, 0.0);
  pts[kKnee] = T.block<3, 1>(0, 3);

  const double d_row3 = -s[3] * g.d2;
  pts[kShankKink] = (T * kink(q(2), d_row3)).block<3, 1>(0, 3);
  T = T * dh(q(2), d_row3, g.l2, 0.0);
  pts[kFoot] = T.block<3, 1>(0, 3);
  return pts;
}

bool RobotModel::ik(Leg leg, const Vec3 & foot_body, int knee, Vec3 & q) const
{
  const auto s = leg_signs(leg);
  const Geometry & g = geometry_;
  const Vec3 r = foot_body - hip(leg);

  // The two lateral offsets both lie along the hip-pitch axis, so they only
  // shift the leg plane sideways by their difference.
  const double d_net = s[2] * g.d1 - s[3] * g.d2;
  const double radius = std::hypot(r.y(), r.z());
  if (!std::isfinite(radius) || radius * radius < d_net * d_net) {
    return false;
  }
  const double reach = std::sqrt(radius * radius - d_net * d_net);
  const double th1 = std::atan2(r.y(), -r.z()) - std::atan2(d_net, reach);

  // Planar 2-link in the leg plane: lambda runs down the leg, m along body x.
  const double lambda = reach - g.h;
  const double m = -r.x();
  const double cos3 = (lambda * lambda + m * m - g.l1 * g.l1 - g.l2 * g.l2) /
    (2.0 * g.l1 * g.l2);
  if (!std::isfinite(cos3) || std::abs(cos3) > 1.0) {
    return false;
  }
  const double th3 = static_cast<double>(knee) * std::acos(cos3);
  const double th2 = std::atan2(m, lambda) -
    std::atan2(g.l2 * std::sin(th3), g.l1 + g.l2 * std::cos(th3));

  q = Vec3(th1, th2, th3);
  return true;
}

Eigen::Matrix3d RobotModel::point_jacobian(Leg leg, const Vec3 & q, int point) const
{
  constexpr double kStep = 1e-6;
  Eigen::Matrix3d J;
  for (int j = 0; j < 3; ++j) {
    Vec3 qp = q, qm = q;
    qp(j) += kStep;
    qm(j) -= kStep;
    J.col(j) = (leg_points(leg, qp)[point] - leg_points(leg, qm)[point]) / (2.0 * kStep);
  }
  return J;
}

bool RobotModel::within_limits(const Joints & q, double tol, std::string * why) const
{
  static const char * kJoint[3] = {"abduction", "hip_pitch", "knee"};
  for (Leg leg : kLegs) {
    const Vec3 ql = leg_q(q, leg);
    for (int j = 0; j < 3; ++j) {
      const int k = 3 * index_of(leg) + j;
      if (!std::isfinite(ql(j)) || ql(j) < limits_.lo(k) - tol || ql(j) > limits_.hi(k) + tol) {
        if (why) {
          std::ostringstream os;
          os << joint_names()[k] << " = " << ql(j) / kDeg
             << " deg outside [" << limits_.lo(k) / kDeg << ", " << limits_.hi(k) / kDeg
             << "] (" << kJoint[j] << ")";
          *why = os.str();
        }
        return false;
      }
    }
  }
  return true;
}

Vec3 RobotModel::com(const Joints & q, double * total_g) const
{
  Vec3 moment = Vec3::Zero();
  double total = 0.0;
  for (const auto & pm : mass_.body) {
    moment += pm.mass_g * pm.pos;
    total += pm.mass_g;
  }
  for (Leg leg : kLegs) {
    const auto p = leg_points(leg, leg_q(q, leg));
    moment += mass_.hip_servo_g * p[kHipPitch];
    moment += mass_.knee_servo_g * p[kKnee];
    moment += mass_.shank_g * 0.5 * (p[kKnee] + p[kFoot]);
    total += mass_.hip_servo_g + mass_.knee_servo_g + mass_.shank_g;
  }
  if (total_g) {
    *total_g = total;
  }
  return total > 0.0 ? Vec3(moment / total) : Vec3::Zero();
}

double RobotModel::total_mass_g() const
{
  double total = 4.0 * (mass_.hip_servo_g + mass_.knee_servo_g + mass_.shank_g);
  for (const auto & pm : mass_.body) {
    total += pm.mass_g;
  }
  return total;
}

}  // namespace pkun_motion
