#ifndef PKUN_MOTION__MOTION_NODE_HPP_
#define PKUN_MOTION__MOTION_NODE_HPP_

#include <memory>
#include <string>

#include "pkun_motion/config.hpp"
#include "pkun_motion/planner.hpp"
#include "pkun_msgs/action/behavior.hpp"
#include "pkun_msgs/msg/joint_command.hpp"
#include "pkun_msgs/msg/motion_status.hpp"
#include "pkun_msgs/msg/servo_state.hpp"
#include "rclcpp/rclcpp.hpp"
#include "rclcpp_action/rclcpp_action.hpp"

namespace pkun_motion
{

/// The robot's motion executive. Owns the only stream of leg commands.
///
/// Every tick (50 Hz) it publishes exactly one full 12-joint JointCommand:
/// the next frame of the running behaviour, or idle breathing, or the held
/// pose. A behaviour is planned and safety-checked in full before its first
/// frame goes out, so the robot never starts something it cannot finish.
///
/// Everything -- ticks, goals, cancels, driver state -- runs on one
/// single-threaded executor, so there is no locking and no way for a goal
/// callback to change the trajectory underneath a tick.
class MotionNode : public rclcpp::Node
{
public:
  using Behavior = pkun_msgs::action::Behavior;
  using GoalHandle = rclcpp_action::ServerGoalHandle<Behavior>;

  explicit MotionNode(const rclcpp::NodeOptions & options);

  /// Lower the robot into its parking posture and stop, blocking until done.
  /// Called from main() on SIGINT/SIGTERM, with the executor no longer
  /// spinning: cutting the servos where they stand drops the robot on its face.
  void park();

private:
  MotionConfig load_config();
  void apply_servo_limits(MotionConfig & cfg);

  void on_tick();
  void publish_command(const Joints & q);
  void publish_status();
  void on_servo_state(const pkun_msgs::msg::ServoState::SharedPtr msg);

  rclcpp_action::GoalResponse on_goal(
    const rclcpp_action::GoalUUID & uuid, std::shared_ptr<const Behavior::Goal> goal);
  rclcpp_action::CancelResponse on_cancel(std::shared_ptr<GoalHandle> goal);
  void on_accepted(std::shared_ptr<GoalHandle> goal);

  /// Plan the pending goal from where the robot is now; start it or abort it.
  void start_pending();
  /// A walk/turn being cancelled: re-plan it shorter with identical frames so far.
  void shorten_active();
  void finish_active(bool success, const std::string & message);
  bool driver_alive() const;
  Posture park_posture_{Posture::Rest};

  std::unique_ptr<Planner> planner_;
  double dt_{0.02};

  // What the servos were last told, and which canonical posture that is.
  Joints q_{Joints::Zero()};
  double neck_{0.0};          // head_pitch, rad
  bool has_neck_{false};      // the driver has a head_pitch servo (servos.yaml)
  Posture posture_{Posture::Unknown};
  double idle_t_{0.0};
  bool breathe_{true};

  // The one active behaviour.
  std::shared_ptr<GoalHandle> pending_;
  std::shared_ptr<GoalHandle> active_;
  Request request_;
  Posture from_{Posture::Unknown};
  Joints q_start_{Joints::Zero()};
  double neck_start_{0.0};
  PlanResult plan_;
  std::size_t index_{0};
  bool shortened_{false};
  int feedback_every_{10};

  // Servo driver.
  bool require_driver_{true};
  bool torque_{false};
  bool driver_seen_{false};
  rclcpp::Time last_driver_msg_{0, 0, RCL_ROS_TIME};

  rclcpp::Publisher<pkun_msgs::msg::JointCommand>::SharedPtr command_pub_;
  rclcpp::Publisher<pkun_msgs::msg::MotionStatus>::SharedPtr status_pub_;
  rclcpp::Subscription<pkun_msgs::msg::ServoState>::SharedPtr servo_sub_;
  rclcpp_action::Server<Behavior>::SharedPtr action_server_;
  rclcpp::TimerBase::SharedPtr tick_timer_;
  rclcpp::TimerBase::SharedPtr status_timer_;
};

}  // namespace pkun_motion

#endif  // PKUN_MOTION__MOTION_NODE_HPP_
