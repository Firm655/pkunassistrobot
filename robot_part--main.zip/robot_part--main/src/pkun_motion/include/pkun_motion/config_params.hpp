#ifndef PKUN_MOTION__CONFIG_PARAMS_HPP_
#define PKUN_MOTION__CONFIG_PARAMS_HPP_

#include <initializer_list>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "pkun_motion/config.hpp"

namespace pkun_motion
{

/// The one list of motion.yaml parameter names. The node reads them with
/// declare_parameter, motion_report straight from the YAML file -- so the
/// offline report plans with exactly what the robot will.
///
/// `d(name, double &)`, `i(name, int &)` and `v(name, std::vector<double> &)`
/// each overwrite the value if the source has the parameter and leave the
/// default otherwise.
template<class D, class I, class V>
void bind_config(MotionConfig & c, D && d, I && i, V && v)
{
  d("rate_hz", c.rate_hz);

  auto & p = c.posture;
  d("posture.stand_height", p.stand_height);
  d("posture.splay_deg", p.splay_deg);
  d("posture.stand_x", p.stand_x);
  d("posture.rest_height", p.rest_height);
  d("posture.rest_body_back", p.rest_body_back);
  d("posture.sit_rear_hip_deg", p.sit_rear_hip_deg);
  d("posture.sit_rear_knee_deg", p.sit_rear_knee_deg);
  d("posture.sit_pitch_deg", p.sit_pitch_deg);

  auto & t = c.timing;
  d("timing.stand_to_rest", t.stand_to_rest);
  d("timing.rest_to_stand", t.rest_to_stand);
  d("timing.stand_to_sit", t.stand_to_sit);
  d("timing.sit_to_stand", t.sit_to_stand);
  d("timing.recover_rate_dps", t.recover_rate_dps);
  d("timing.settle_rate_dps", t.settle_rate_dps);

  auto & g = c.gait;
  d("gait.body_height", g.body_height);
  d("gait.rise_time", g.rise_time);
  d("gait.cycle_time", g.cycle_time);
  d("gait.duty", g.duty);
  d("gait.stride", g.stride);
  d("gait.step_height", g.step_height);
  d("gait.turn_deg_per_cycle", g.turn_deg_per_cycle);
  d("gait.sway_margin_mm", g.sway_margin_mm);
  d("gait.sway_gain", g.sway_gain);
  d("gait.pre_time", g.pre_time);
  d("gait.post_time", g.post_time);
  i("gait.default_cycles", g.default_cycles);
  i("gait.max_cycles", g.max_cycles);

  auto & e = c.gesture;
  d("beckon.height", e.beckon_height);
  d("beckon.margin_mm", e.beckon_margin_mm);
  d("beckon.lift", e.beckon_lift);
  d("beckon.out_x", e.beckon_out_x);
  d("beckon.in_x", e.beckon_in_x);
  d("beckon.in_z", e.beckon_in_z);
  d("beckon.shift_s", e.beckon_shift_s);
  d("beckon.lift_s", e.beckon_lift_s);
  d("beckon.beat_s", e.beckon_beat_s);
  i("beckon.default_count", e.beckon_default);
  d("alert.rise", e.alert_rise);
  d("alert.pitch_deg", e.alert_pitch_deg);
  d("alert.bounce", e.alert_bounce);
  d("alert.perk_s", e.alert_perk_s);
  d("alert.bounce_s", e.alert_bounce_s);
  d("play_bow.pitch_deg", e.bow_pitch_deg);
  d("play_bow.drop", e.bow_drop);
  d("play_bow.back", e.bow_back);
  d("play_bow.move_s", e.bow_move_s);
  d("play_bow.hold_s", e.bow_hold_s);
  d("happy.yaw_deg", e.happy_yaw_deg);
  d("happy.roll_deg", e.happy_roll_deg);
  d("happy.hz", e.happy_hz);
  d("happy.pivot_x", e.happy_pivot_x);
  i("happy.default_count", e.happy_default);
  d("nod.down_deg", e.nod_down_deg);
  d("nod.up_deg", e.nod_up_deg);
  d("nod.beat_s", e.nod_beat_s);
  i("nod.default_count", e.nod_default);
  d("wake_up.rise_scale", e.wake_rise_scale);
  d("wake_up.pitch_deg", e.wake_pitch_deg);
  d("wake_up.stretch_s", e.wake_stretch_s);
  d("wake_up.hold_s", e.wake_hold_s);
  d("wake_up.bounce", e.wake_bounce);
  d("wake_up.bounce_s", e.wake_bounce_s);
  i("wake_up.default_count", e.wake_default);
  d("medicine.rise", e.med_rise);
  d("medicine.pitch_deg", e.med_pitch_deg);
  d("medicine.nod_deg", e.med_nod_deg);
  d("medicine.beat_s", e.med_beat_s);
  d("medicine.hold_s", e.med_hold_s);
  i("medicine.default_count", e.med_default);
  d("lets_go.bow_pitch_deg", e.go_bow_pitch_deg);
  d("lets_go.bow_s", e.go_bow_s);
  d("lets_go.hold_s", e.go_hold_s);
  i("lets_go.default_count", e.go_default);
  d("eat.pitch_deg", e.eat_pitch_deg);
  d("eat.dip_deg", e.eat_dip_deg);
  d("eat.down_s", e.eat_down_s);
  d("eat.beat_s", e.eat_beat_s);
  i("eat.default_count", e.eat_default);
  d("idle.breathe_amp", e.breathe_amp);
  d("idle.breathe_period", e.breathe_period);

  auto & n = c.neck;
  for (auto [key, val] : std::initializer_list<std::pair<const char *, double *>>{
      {"min_deg", &n.min_deg}, {"max_deg", &n.max_deg}, {"settle_s", &n.settle_s},
      {"max_rate_dps", &n.max_rate_dps},
      {"rest_deg", &n.rest_deg}, {"stand_deg", &n.stand_deg}, {"sit_deg", &n.sit_deg},
      {"walk_deg", &n.walk_deg}, {"alert_deg", &n.alert_deg}, {"bow_deg", &n.bow_deg},
      {"beckon_deg", &n.beckon_deg}, {"beckon_beat_deg", &n.beckon_beat_deg},
      {"happy_bob_deg", &n.happy_bob_deg}, {"nod_down_deg", &n.nod_down_deg},
      {"nod_up_deg", &n.nod_up_deg}, {"wake_stretch_deg", &n.wake_stretch_deg},
      {"med_look_deg", &n.med_look_deg}, {"med_nod_deg", &n.med_nod_deg},
      {"eat_down_deg", &n.eat_down_deg}, {"eat_dip_deg", &n.eat_dip_deg}})
  {
    d(std::string("neck.") + key, *val);
  }

  auto & s = c.safety;
  d("safety.rate_cap_dps", s.rate_cap_dps);
  d("safety.min_margin_mm", s.min_margin_mm);
  d("safety.min_clearance_mm", s.min_clearance_mm);
  d("safety.limit_tol_deg", s.limit_tol_deg);
  d("safety.ground_tol_mm", s.ground_tol_mm);
  d("safety.max_torque_kgcm", s.max_torque_kgcm);

  // Underbody hardware, flat [x, y, z, x, y, z, ...] in the body frame.
  std::vector<double> flat;
  for (const Vec3 & u : c.underbody) {flat.insert(flat.end(), {u.x(), u.y(), u.z()});}
  v("underbody", flat);
  if (flat.size() % 3 != 0 || flat.empty()) {
    throw std::runtime_error("'underbody' must be a non-empty list of x, y, z triples");
  }
  c.underbody.clear();
  for (std::size_t k = 0; k < flat.size(); k += 3) {
    c.underbody.emplace_back(flat[k], flat[k + 1], flat[k + 2]);
  }

  // Payload carried by the body, flat [grams, x, y, z, ...].
  flat.clear();
  for (const auto & m : c.mass.body) {
    flat.insert(flat.end(), {m.mass_g, m.pos.x(), m.pos.y(), m.pos.z()});
  }
  v("payload", flat);
  if (flat.size() % 4 != 0 || flat.empty()) {
    throw std::runtime_error("'payload' must be a non-empty list of grams, x, y, z groups");
  }
  c.mass.body.clear();
  for (std::size_t k = 0; k < flat.size(); k += 4) {
    c.mass.body.push_back({flat[k], Vec3(flat[k + 1], flat[k + 2], flat[k + 3])});
  }
  d("leg_mass.hip_servo_g", c.mass.hip_servo_g);
  d("leg_mass.knee_servo_g", c.mass.knee_servo_g);
  d("leg_mass.shank_g", c.mass.shank_g);

  if (c.rate_hz < 10.0 || c.rate_hz > 200.0) {
    throw std::runtime_error("rate_hz must be within 10..200");
  }
}

}  // namespace pkun_motion

#endif  // PKUN_MOTION__CONFIG_PARAMS_HPP_
