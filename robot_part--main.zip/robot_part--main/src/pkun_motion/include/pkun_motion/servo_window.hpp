#ifndef PKUN_MOTION__SERVO_WINDOW_HPP_
#define PKUN_MOTION__SERVO_WINDOW_HPP_

#include <algorithm>

#include "pkun_motion/types.hpp"

namespace pkun_motion
{

/// Calibration of one hobby servo, exactly as pkun_servo_driver maps it:
///   pulse_us = center_us + s * (q_deg + trim_deg) * us_per_deg,  s = invert ? -1 : +1
struct ServoCalibration
{
  double center_us{1500.0};
  double us_per_deg{11.111};
  bool invert{false};
  double trim_deg{0.0};
};

struct AngleRange
{
  double lo{0.0};   // rad
  double hi{0.0};
};

/// Joint angles (rad) whose pulse stays inside [min_us, max_us]. A horn fitted
/// with the joint's zero near mid-travel gets roughly +-90 deg here -- which
/// for a knee that must fold 0..150 deg is the real limit, not the mechanism.
inline AngleRange servo_window(const ServoCalibration & c, double min_us, double max_us)
{
  const double s = c.invert ? -1.0 : 1.0;
  const double a = (min_us - c.center_us) / (s * c.us_per_deg) - c.trim_deg;
  const double b = (max_us - c.center_us) / (s * c.us_per_deg) - c.trim_deg;
  return {std::min(a, b) * kDeg, std::max(a, b) * kDeg};
}

}  // namespace pkun_motion

#endif  // PKUN_MOTION__SERVO_WINDOW_HPP_
