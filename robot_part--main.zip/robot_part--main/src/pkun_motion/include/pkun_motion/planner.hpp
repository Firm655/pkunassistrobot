#ifndef PKUN_MOTION__PLANNER_HPP_
#define PKUN_MOTION__PLANNER_HPP_

#include <array>
#include <functional>
#include <limits>
#include <string>
#include <vector>

#include "pkun_motion/config.hpp"
#include "pkun_motion/robot_model.hpp"
#include "pkun_motion/trajectory.hpp"
#include "pkun_motion/types.hpp"

namespace pkun_motion
{

/// What the outside world asks for (mirrors pkun_msgs/action/Behavior).
struct Request
{
  std::string name;
  std::string option;   // walk: forward|backward   beckon: left|right (robot's own paws)
  int count{0};         // gait cycles or repetitions; 0 = default
  double speed{1.0};    // 1.0 nominal, clamped to [0.5, 1.5]; 0 = nominal
};

struct PlanResult
{
  bool ok{false};
  std::string error;
  Trajectory traj;
  Stats stats;
  double effective_speed{1.0};   // may be lower than asked if the rate cap forced it
  int effective_count{0};
};

/// Turns a Request into a complete, checked Trajectory that starts exactly at
/// the joint angles the robot is holding now. Stateless and deterministic:
/// the same inputs always give the same frames, which is what lets a walk be
/// re-planned shorter mid-stride without a visible jump.
class Planner
{
public:
  explicit Planner(MotionConfig config);

  const MotionConfig & config() const {return cfg_;}
  const RobotModel & model() const {return model_;}
  double dt() const {return 1.0 / cfg_.rate_hz;}

  /// Canonical posture at the local origin (feet on the stand footprint).
  const Frame & posture_frame(Posture p) const;
  Joints posture_q(Posture p) const {return posture_frame(p).q;}
  double rest_height() const {return rest_body_.z;}

  /// Canonical postures must themselves be reachable and safe. Call once at
  /// start-up; a bad config should stop the node, not the robot mid-motion.
  bool self_check(std::string & error) const;

  static const std::vector<std::string> & behaviors();

  /// `neck_now` (rad) is where the neck is; NaN = unknown, start at the
  /// posture's own angle.
  PlanResult plan(const Request & req, Posture from, const Joints & q_now,
    double neck_now = std::numeric_limits<double>::quiet_NaN()) const;

  /// The neck angle (deg) a posture holds.
  double neck_deg(Posture p) const;

  /// For an active walk/turn (planned from `req`/`from`/`q_start`), how many
  /// cycles to re-plan with so it stops as soon as possible while every frame
  /// up to `now_index` + one cycle stays identical. Returns 0 if it cannot be
  /// shortened (already stopping, or not a gait).
  int shortened_cycles(const Trajectory & active, std::size_t now_index) const;

  /// Joint targets for an idle posture at time t (subtle breathing).
  Joints idle(Posture p, double t) const;

private:
  friend class Builder;

  /// Sideways body offset held while each side's legs are stepping.
  struct Sway
  {
    double left_steps{0.0};    // (negative) lean right while the left legs step
    double right_steps{0.0};   // (positive) lean left while the right legs step
  };

  Frame make_stand() const;
  Frame make_rest() const;
  Frame sit_state(double s, const Pose & base) const;
  /// Stand footprint seen from a level body at `height` (default: stand height).
  std::array<Vec3, kNumLegs> footprint_rel(double height = -1.0) const;
  Sway fit_sway(double stride, double turn, double cycle, double speed, double height) const;

  MotionConfig cfg_;
  RobotModel model_;
  BodyPose stand_body_{};
  BodyPose rest_body_{};
  Frame stand_{};
  Frame rest_{};
  Frame sit_{};
  Frame unknown_{};
};

}  // namespace pkun_motion

#endif  // PKUN_MOTION__PLANNER_HPP_
