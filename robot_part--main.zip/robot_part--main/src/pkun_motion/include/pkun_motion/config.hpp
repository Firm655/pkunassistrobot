#ifndef PKUN_MOTION__CONFIG_HPP_
#define PKUN_MOTION__CONFIG_HPP_

#include <array>
#include <vector>

#include "pkun_motion/robot_model.hpp"
#include "pkun_motion/types.hpp"

namespace pkun_motion
{

/// Everything the planner needs. Defaults are the tuned values; motion.yaml
/// overrides them. Distances in mm, angles in degrees unless the name says rad,
/// times in seconds at speed 1.0.
struct PostureConfig
{
  double stand_height{102.0};    // body origin above the ground. The FR knee
                                 // (115 deg of fold) sets the floor at 92.
  // Feet out sideways. Wider is steadier (standing margin 41 -> 46 mm) and
  // takes a little off the knees, but the abduction servos pay for it: they
  // hold the body up at an angle, and the taller the stance the wider the
  // splay puts the feet. At 102 mm, 13 deg peaks at 1.03 kg.cm while turning,
  // still inside the 1.2 budget.
  double splay_deg{10.0};
  // Feet 10 mm ahead of the hips: the knees point forward, so this brings each
  // shank closer to vertical and cuts the knee's lever arm, at the price of a
  // little hip load.
  // Feet 12 mm ahead of the hips. The head puts the centre of mass 25 mm
  // forward, and moving the feet with it shares the load between the front
  // knees and hips instead of piling it on one of them.
  double stand_x{12.0};
  // Lying height. Raised twice by 1 cm from the lowest the joints allow (~74,
  // FR knee at its limit) because the real legs bound lower down. Raised
  // automatically too if the underbody or the joint limits need more.
  double rest_height{94.0};
  // Lying down, body offset back over its feet. 0 keeps the hips' swing inside
  // the rear hip-pitch servo window (-80 deg) and lets it lie at ~65 mm.
  double rest_body_back{0.0};
  // Sit: the rear legs fold under, the rear shank resting on the table so it
  // carries the haunches rather than the knee servos.
  double sit_rear_hip_deg{-65.0};
  double sit_rear_knee_deg{115.0};
  double sit_pitch_deg{18.0};    // chest up; tilts the screen toward the resident
  int knee{+1};                  // IK branch: +1 = knees point forward, the way
                                 // the real knee folds
};

struct TimingConfig
{
  double stand_to_rest{2.2};
  double rest_to_stand{1.8};
  double stand_to_sit{2.4};
  double sit_to_stand{2.0};
  double recover_rate_dps{60.0};  // joint-space recovery out of Unknown
  double settle_rate_dps{90.0};   // tiny blends back onto a canonical pose
};

struct GaitConfig
{
  double body_height{124.0};        // walks taller than it idles: a straighter
                                    // knee is what keeps an ES08MA II out of
                                    // stall. With the 100 g head, 116 put the
                                    // fr_knee at 1.22 kg.cm; 124 -> 1.01 (the
                                    // planner slows the walk to 0.8x).
  double rise_time{0.6};            // idle height <-> walking height
  double cycle_time{2.6};
  // Fraction of the cycle each foot is planted. Above 0.75 there are never
  // fewer than three feet down; the rest of the cycle is the four-feet gap the
  // body has to shift its weight across, and that gap is what decides how
  // violently it rocks. 0.86 gives it 0.6 s instead of 0.4 s, which cuts the
  // sideways acceleration from 2.3 to 0.8 m/s^2 at the same walking speed.
  double duty{0.88};
  double stride{50.0};              // body travel per cycle -> 28 mm/s
  double step_height{8.0};         // a shorter swing window needs a lower lift
  double turn_deg_per_cycle{14.0};
  // Before each foot lifts the body leans just far enough that the CoG sits
  // this deep inside the other three feet -- the smallest lean that is safe,
  // which on a long narrow body is a gentle side-to-side, not a lurch.
  double sway_margin_mm{13.0};
  double sway_gain{1.0};
  double pre_time{0.9};             // sway in before the first foot lifts
  double post_time{0.7};            // sway back out after the last foot lands
  // Footfall order is the lateral-sequence walk real dogs use at low speed:
  // left-hind, left-fore, right-hind, right-fore. Each side's two steps run
  // back to back, so the only four-feet-down moments come in two longer gaps
  // per cycle -- exactly when the body shifts its weight to the other side.
  // Phases are derived from `duty` (see lateral_sequence_offsets()).
  int default_cycles{4};
  int max_cycles{30};
};

/// Lift phase of each leg (FL, FR, RL, RR) for the paired lateral sequence.
inline std::array<double, 4> lateral_sequence_offsets(double duty)
{
  const double s = 1.0 - duty;
  return {s, 0.5 + s, 0.0, 0.5};
}

struct GestureConfig
{
  // beckon — one fore paw waves toward the body, the other three hold the ground
  double beckon_height{116.0};     // rises first: paw room, and less load on
                                   // the knee holding the extra weight
  double beckon_margin_mm{15.0};   // CoG this deep inside the three planted feet
  double beckon_lift{22.0};
  double beckon_out_x{-2.0};       // paw forward end, relative to where it stood
  double beckon_in_x{-26.0};       // paw pulled in toward the chest
  double beckon_in_z{6.0};
  double beckon_shift_s{1.0};
  double beckon_lift_s{0.6};
  double beckon_beat_s{0.7};
  int beckon_default{3};

  // alert — perk up and bounce twice, then sit facing the resident
  double alert_rise{10.0};
  double alert_pitch_deg{6.0};
  double alert_bounce{6.0};
  double alert_perk_s{0.5};
  double alert_bounce_s{0.3};

  // play bow — chest down, rear up, the canine "come and play"
  double bow_pitch_deg{-4.0};
  double bow_drop{0.0};          // any deeper and the FR knee runs out of fold
  double bow_back{0.0};
  double bow_move_s{0.8};
  double bow_hold_s{1.2};

  // happy — body wiggle about a pivot near the shoulders, so the rear swings
  double happy_yaw_deg{7.0};
  double happy_roll_deg{2.0};
  double happy_hz{1.3};
  double happy_pivot_x{40.0};
  int happy_default{3};

  // nod
  double nod_down_deg{4.0};
  double nod_up_deg{2.0};
  double nod_beat_s{0.7};
  int nod_default{2};

  // wake up -- get up unhurried, stretch like a dog that just woke, then two
  // growing bounces and a nod. Gentle first, insistent only if ignored.
  double wake_rise_scale{1.3};      // >1 = slower than a normal stand
  double wake_pitch_deg{-4.0};      // chest down, rear up: the waking stretch
  double wake_stretch_s{1.1};
  double wake_hold_s{0.8};
  double wake_bounce{5.0};
  double wake_bounce_s{0.35};
  int wake_default{2};              // bounces

  // medicine -- the serious one: no wiggle, slow and deliberate, ends sitting
  // with the screen up so the reminder can be read.
  double med_rise{8.0};
  double med_pitch_deg{5.0};
  double med_nod_deg{9.0};
  double med_beat_s{1.0};
  double med_hold_s{1.0};
  int med_default{2};               // nods

  // let's go -- play bow, a wiggle and a beckon: come with me
  double go_bow_pitch_deg{-4.0};
  double go_bow_s{0.8};
  double go_hold_s{0.6};
  int go_default{2};                // beckon waves

  // eat -- nose down and nibble, then a happy wiggle
  double eat_pitch_deg{-3.0};
  double eat_dip_deg{1.5};
  double eat_down_s{0.7};
  double eat_beat_s{0.45};
  int eat_default{3};               // bites

  // idle breathing layered on rest and stand
  double breathe_amp{1.5};
  double breathe_period{4.0};
};

/// The neck servo (head_pitch). Degrees, + = look up, 0 = looking straight
/// ahead. It rides on its own timeline beside the body: the leg maths, the
/// balance and the torque checks never see it move (the head's mass is in
/// `payload`, fixed where it sits at 0 deg). Every angle is clamped to min..max,
/// which the node narrows further to the servo's calibrated range.
struct NeckConfig
{
  double min_deg{-30.0};
  double max_deg{25.0};
  double settle_s{0.5};             // to the posture's angle when a plan starts elsewhere
  double max_rate_dps{120.0};       // peak neck speed; a move that would be faster is stretched

  double rest_deg{-12.0};           // lying: chin down, relaxed
  double stand_deg{0.0};
  double sit_deg{12.0};             // sitting: looking up at the resident
  double walk_deg{-5.0};            // eyes on the way ahead

  double alert_deg{22.0};           // head snaps up
  double bow_deg{20.0};             // chest down, head up: the play invitation
  double beckon_deg{10.0};          // looking at the person it calls
  double beckon_beat_deg{6.0};      // small "come on" with each wave
  double happy_bob_deg{6.0};        // bobs twice per wag
  double nod_down_deg{18.0};        // on top of the body's own nod
  double nod_up_deg{6.0};
  double wake_stretch_deg{18.0};    // chest down, rear up, head up: a real stretch
  double med_look_deg{15.0};        // screen up and looking at the resident
  double med_nod_deg{16.0};
  double eat_down_deg{-25.0};       // nose to the bowl
  double eat_dip_deg{10.0};         // each nibble
};

struct SafetyConfig
{
  // Planned joint speed ceiling. ES08MA II at 5 V turns ~500 deg/s unloaded and
  // maybe two thirds of that carrying the body -- a plan faster than the servo
  // turns into lag, and then the leg is not where the balance check assumed.
  double rate_cap_dps{300.0};
  double min_margin_mm{8.0};       // static stability wherever it is required
  double min_clearance_mm{5.0};    // underbody hardware above the ground
  double limit_tol_deg{0.5};
  double ground_tol_mm{5.0};       // a leg point this close counts as touching
  // Static joint torque ceiling, kg.cm; 0 = not checked. EMAX ES08MA II stalls
  // at ~1.67 on the 5 V supply; 1.2 keeps ~30% for dynamics and a warm servo.
  // Standing and lying hold under 1.0.
  double max_torque_kgcm{1.2};
};

/// Lowest hardware under the body. Default: a Raspberry Pi 4 board (85 x 56 mm)
/// hanging ~30 mm under the belly, its underside 55 mm below the body origin,
/// plus the corners of the belly plate. Modelling the board as a box, not a point, matters: with
/// the chest up in a sit, its rear edge is what reaches the ground first.
inline std::vector<Vec3> default_underbody()
{
  return {
    Vec3(-52.5, 28.0, -55.0), Vec3(-52.5, -28.0, -55.0),
    Vec3(32.5, 28.0, -55.0), Vec3(32.5, -28.0, -55.0),
    Vec3(77.27, 29.0, -14.0), Vec3(77.27, -29.0, -14.0),
    Vec3(-77.27, 29.0, -14.0), Vec3(-77.27, -29.0, -14.0),
  };
}

struct MotionConfig
{
  Geometry geometry{};
  JointLimits limits{};
  MassModel mass{};
  std::vector<Vec3> underbody{default_underbody()};
  PostureConfig posture{};
  TimingConfig timing{};
  GaitConfig gait{};
  GestureConfig gesture{};
  NeckConfig neck{};
  SafetyConfig safety{};
  double rate_hz{50.0};

  RobotModel model() const {return RobotModel(geometry, limits, mass, underbody);}
};

}  // namespace pkun_motion

#endif  // PKUN_MOTION__CONFIG_HPP_
