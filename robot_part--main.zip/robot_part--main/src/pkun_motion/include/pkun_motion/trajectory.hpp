#ifndef PKUN_MOTION__TRAJECTORY_HPP_
#define PKUN_MOTION__TRAJECTORY_HPP_

#include <array>
#include <limits>
#include <string>
#include <vector>

#include "pkun_motion/config.hpp"
#include "pkun_motion/robot_model.hpp"
#include "pkun_motion/types.hpp"

namespace pkun_motion
{

/// One control tick.
struct Frame
{
  Joints q{Joints::Zero()};
  BodyPose body{};                          // body over the ground
  std::array<bool, kNumLegs> contact{{true, true, true, true}};
  bool body_known{true};    // false only for joint-space recovery out of Unknown
  bool static_check{true};  // enforce the static stability margin on this tick
  double neck{0.0};         // head_pitch, rad, + = look up; not part of the leg maths
};

/// Bookkeeping that lets a walk be cut short later without a jump.
struct GaitInfo
{
  bool valid{false};
  std::size_t first_frame{0};   // index of the walk's first frame in the trajectory
  double pre_time{0.0};
  double cycle_time{0.0};
  int cycles{0};
  double stride{0.0};
  double turn_rad_per_cycle{0.0};
};

/// A fully planned, fully checked motion. Nothing reaches the servos unless it
/// came out of one of these and passed check().
struct Trajectory
{
  std::string name;
  double dt{0.02};
  std::vector<Frame> frames;
  Posture end_posture{Posture::Unknown};
  GaitInfo gait{};

  double duration() const {return frames.empty() ? 0.0 : dt * (frames.size() - 1);}
};

struct Stats
{
  double duration_s{0.0};
  double peak_rate_dps{0.0};
  double min_margin_mm{std::numeric_limits<double>::infinity()};
  double min_clearance_mm{std::numeric_limits<double>::infinity()};
  double lowest_leg_mm{std::numeric_limits<double>::infinity()};
  Vec3 peak_torque_kgcm{Vec3::Zero()};   // abduction, hip pitch, knee
  double mass_g{0.0};
};

struct Verdict
{
  bool ok{true};
  std::string error;         // first problem found
  bool too_fast{false};      // some tick broke the joint-speed cap
  bool unsafe{false};        // anything else (limits, ground, balance, NaN)
  Stats stats;
};

/// Frame-by-frame safety gate: finite, inside joint limits, under the rate cap,
/// underbody clear of the ground, legs not through the ground, and statically
/// stable wherever the frame asks for it. Torque is optional (report only).
Verdict check(const Trajectory & traj, const RobotModel & model,
  const SafetyConfig & safety, bool with_torque = false);

// --- support-polygon helpers (exposed for tests) ----------------------------

std::vector<Vec2> convex_hull(std::vector<Vec2> pts);

/// Signed distance from `com` to the nearest edge of the support hull, mm.
/// Negative = outside (falls over); -inf when the points do not span an area.
double support_margin(const Vec2 & com, const std::vector<Vec2> & pts);

/// World-frame points of the legs that are in contact and within `tol` of the ground.
std::vector<Vec3> contact_points(const Frame & f, const RobotModel & model, double tol);

}  // namespace pkun_motion

#endif  // PKUN_MOTION__TRAJECTORY_HPP_
