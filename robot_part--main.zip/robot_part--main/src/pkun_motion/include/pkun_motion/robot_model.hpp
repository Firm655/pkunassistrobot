#ifndef PKUN_MOTION__ROBOT_MODEL_HPP_
#define PKUN_MOTION__ROBOT_MODEL_HPP_

#include <array>
#include <string>
#include <vector>

#include "pkun_motion/types.hpp"

namespace pkun_motion
{

/// Link dimensions in mm. Standard DH per leg (Spong):
///   row 1  theta1  d=0        a=h   alpha=-90deg   abduction
///   row 2  theta2  d=+-D1     a=L1  alpha=0        hip pitch
///   row 3  theta3  d=-+D2     a=L2  alpha=0        knee
/// with a fixed body->frame0 of Trans(+-a, +-b, -c) * RotY(90deg).
/// These are measured off the real robot and were checked against it joint by
/// joint, so they are geometry, not tuning.
struct Geometry
{
  double a{77.27};    // half hip spacing, front-back
  double b{29.0};     // half hip spacing, left-right
  double c{0.0};      // body origin down to the abduction axis
  double h{23.38};    // abduction axis down to the hip pitch axis
  double d1{12.75};   // lateral offset to the hip pitch servo
  double d2{12.75};   // knee offset back toward the body
  double l1{56.39};   // thigh
  double l2{56.58};   // shank

  double max_reach() const {return c + h + l1 + l2;}
};

/// Per joint, radians, in the Joints order (FL, FR, RL, RR x abduction, hip
/// pitch, knee). Two things bound a joint: the mechanism (the knee folds one way
/// only) and the servo -- a horn fitted with the straight leg near mid-travel
/// leaves only ~90 deg of pulse window on one side. The node intersects the two
/// using the servo calibration, so nothing is ever planned that the driver
/// would have to clip.
struct JointLimits
{
  static JointLimits uniform(const Vec3 & lo, const Vec3 & hi)
  {
    JointLimits l;
    for (Leg leg : kLegs) {
      set_leg_q(l.lo, leg, lo);
      set_leg_q(l.hi, leg, hi);
    }
    return l;
  }
  // Default: the mechanism alone -- abduction +-55, hip pitch +-90, knee 0..150.
  // The knee folds one way: forward (the knee points at the head), which is a
  // positive knee angle here. 0 is a straight leg.
  Joints lo{mechanical_lo()};
  Joints hi{mechanical_hi()};

private:
  static Joints mechanical_lo()
  {
    Joints q;
    for (int i = 0; i < kNumLegs; ++i) {q.segment<3>(3 * i) = Vec3(-55.0 * kDeg, -90.0 * kDeg, 0.0);}
    return q;
  }
  static Joints mechanical_hi()
  {
    Joints q;
    for (int i = 0; i < kNumLegs; ++i) {q.segment<3>(3 * i) = Vec3(55.0 * kDeg, 90.0 * kDeg, 150.0 * kDeg);}
    return q;
  }
};

struct PointMass
{
  double mass_g{0.0};
  Vec3 pos{Vec3::Zero()};   // body frame, mm
};

/// What the body carries. The defaults are the stripped-down build: 7" LCD on
/// the back, Raspberry Pi hanging under the belly, the head, no UPS, no batteries.
struct MassModel
{
  std::vector<PointMass> body{
    {180.0, Vec3(0.0, 0.0, 0.0)},       // frame / base plate
    {300.0, Vec3(0.0, 0.0, 26.0)},      // 7" LCD + bezel, centre of the back
    {46.0, Vec3(-10.0, 0.0, -47.0)},    // Raspberry Pi 4, ~30 mm under the belly
    {60.0, Vec3(0.0, 0.0, -6.0)},       // wiring + PCA9685
    {48.0, Vec3(0.0, 0.0, -5.0)},       // four abduction servos, fixed to the body
    // Head, measured on the robot 2026-09-25: 100-130 g, 150 mm ahead of the
    // centre of the top plate and 50 mm above it. The heavy end is used on
    // purpose -- it is the one that decides whether it tips forward.
    {130.0, Vec3(150.0, 0.0, 50.0)},
  };
  double hip_servo_g{12.0};   // rides on the thigh
  double knee_servo_g{12.0};  // rides at the knee
  double shank_g{6.0};        // shank + foot pad
};

/// Leg polyline indices returned by RobotModel::leg_points().
enum LegPoint : int { kHipAbduction = 0, kHipPitch = 1, kThighKink = 2, kKnee = 3,
  kShankKink = 4, kFoot = 5, kNumLegPoints = 6 };

/// Pure kinematics and statics of the robot. No ROS, no state, no allocation in
/// the hot paths, so it is safe to call from the control loop and from tests.
class RobotModel
{
public:
  RobotModel() = default;
  RobotModel(Geometry geometry, JointLimits limits, MassModel mass,
    std::vector<Vec3> underbody);

  const Geometry & geometry() const {return geometry_;}
  const JointLimits & limits() const {return limits_;}
  const MassModel & mass() const {return mass_;}
  /// Lowest hardware under the body (body frame). Must stay above the ground.
  const std::vector<Vec3> & underbody() const {return underbody_;}

  /// Origin of frame 0 (abduction axis) in the body frame.
  Vec3 hip(Leg leg) const;

  /// Every joint origin plus the two offset "kinks", body frame.
  std::array<Vec3, kNumLegPoints> leg_points(Leg leg, const Vec3 & q) const;
  Vec3 foot(Leg leg, const Vec3 & q) const {return leg_points(leg, q)[kFoot];}

  /// Analytic IK. `knee` picks the elbow branch (+1 folds the knee the way the
  /// real joint can). Returns false, leaving q untouched, if unreachable.
  bool ik(Leg leg, const Vec3 & foot_body, int knee, Vec3 & q) const;

  /// d(point)/d(q_leg), body frame, by central differences.
  Eigen::Matrix3d point_jacobian(Leg leg, const Vec3 & q, int point) const;

  /// True when every joint is inside its limit (with tolerance, radians).
  bool within_limits(const Joints & q, double tol, std::string * why = nullptr) const;

  /// Whole-robot centre of mass in the body frame, and total mass in grams.
  Vec3 com(const Joints & q, double * total_g = nullptr) const;
  double total_mass_g() const;

private:
  Geometry geometry_{};
  JointLimits limits_{};
  MassModel mass_{};
  std::vector<Vec3> underbody_{};
};

/// Leg sign pattern (a, b, D1, D2) — mirrored left/right, front/back.
std::array<double, 4> leg_signs(Leg leg);

}  // namespace pkun_motion

#endif  // PKUN_MOTION__ROBOT_MODEL_HPP_
