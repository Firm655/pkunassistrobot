#ifndef PKUN_MOTION__TYPES_HPP_
#define PKUN_MOTION__TYPES_HPP_

#include <array>
#include <cmath>
#include <string>

#include <Eigen/Dense>
#include <Eigen/Geometry>

namespace pkun_motion
{

using Vec2 = Eigen::Vector2d;
using Vec3 = Eigen::Vector3d;
using Joints = Eigen::Matrix<double, 12, 1>;
using Pose = Eigen::Isometry3d;

constexpr int kNumLegs = 4;
constexpr int kJointsPerLeg = 3;
constexpr int kNumJoints = 12;
constexpr double kDeg = M_PI / 180.0;

/// Every 12-vector in this package is ordered FL, FR, RL, RR and, inside each
/// leg, (abduction, hip pitch, knee). The servo driver addresses joints by name,
/// so this order never leaks past the JointCommand message.
enum class Leg : int { FL = 0, FR = 1, RL = 2, RR = 3 };
constexpr std::array<Leg, kNumLegs> kLegs{Leg::FL, Leg::FR, Leg::RL, Leg::RR};

inline int index_of(Leg leg) {return static_cast<int>(leg);}
inline bool is_front(Leg leg) {return leg == Leg::FL || leg == Leg::FR;}
inline bool is_left(Leg leg) {return leg == Leg::FL || leg == Leg::RL;}

inline Vec3 leg_q(const Joints & q, Leg leg) {return q.segment<3>(3 * index_of(leg));}
inline void set_leg_q(Joints & q, Leg leg, const Vec3 & v) {q.segment<3>(3 * index_of(leg)) = v;}

/// Names shared with pkun_servo_driver/config/servos.yaml.
const std::array<std::string, kNumJoints> & joint_names();

/// Resting postures the robot can be left in. Every behaviour starts from one
/// and ends in one; Unknown only happens at boot or after torque was cut.
enum class Posture { Unknown, Rest, Stand, Sit };
const char * to_string(Posture posture);

/// Body pose over the ground, mm and radians.
/// +pitch = nose up, +roll = left side up, +yaw = turn left.
struct BodyPose
{
  double x{0.0};
  double y{0.0};
  double z{0.0};
  double roll{0.0};
  double pitch{0.0};
  double yaw{0.0};
};

Pose to_isometry(const BodyPose & pose);
BodyPose lerp(const BodyPose & from, const BodyPose & to, double s);

/// Minimum-jerk time scaling: zero velocity and acceleration at both ends,
/// which is what keeps position-only hobby servos from clacking at keyframes.
inline double min_jerk(double s)
{
  s = s < 0.0 ? 0.0 : (s > 1.0 ? 1.0 : s);
  return s * s * s * (10.0 + s * (-15.0 + 6.0 * s));
}

/// Peak of d(min_jerk)/ds, used to size a move so it never exceeds a rate cap.
constexpr double kMinJerkPeakRate = 1.875;

}  // namespace pkun_motion

#endif  // PKUN_MOTION__TYPES_HPP_
