#include <gtest/gtest.h>

#include <cmath>
#include <random>
#include <string>

#include "pkun_motion/config.hpp"
#include "pkun_motion/planner.hpp"
#include "pkun_motion/robot_model.hpp"
#include "pkun_motion/servo_window.hpp"
#include "pkun_motion/trajectory.hpp"

using namespace pkun_motion;

namespace
{
RobotModel model() {return MotionConfig{}.model();}
}

TEST(RobotModel, ZeroPoseFootMatchesHandFormula)
{
  // Legs straight down: foot = (+-a, +-b + D1 - D2, -(c + h + L1 + L2)).
  const auto m = model();
  const auto & g = m.geometry();
  for (Leg leg : kLegs) {
    const auto s = leg_signs(leg);
    const Vec3 foot = m.foot(leg, Vec3::Zero());
    EXPECT_NEAR(foot.x(), s[0] * g.a, 1e-9);
    EXPECT_NEAR(foot.y(), s[1] * g.b + s[2] * g.d1 - s[3] * g.d2, 1e-9);
    EXPECT_NEAR(foot.z(), -(g.c + g.h + g.l1 + g.l2), 1e-9);
  }
}

TEST(RobotModel, IkInvertsFkAcrossTheJointRange)
{
  const auto m = model();
  std::mt19937 rng(7);
  std::uniform_real_distribution<double> abd(-50 * kDeg, 50 * kDeg);
  std::uniform_real_distribution<double> hip(-85 * kDeg, 85 * kDeg);
  std::uniform_real_distribution<double> knee(5 * kDeg, 145 * kDeg);
  double worst = 0.0;
  for (Leg leg : kLegs) {
    for (int i = 0; i < 500; ++i) {
      const Vec3 q(abd(rng), hip(rng), knee(rng));
      const Vec3 foot = m.foot(leg, q);
      Vec3 back;
      ASSERT_TRUE(m.ik(leg, foot, +1, back));
      worst = std::max(worst, (m.foot(leg, back) - foot).norm());
    }
  }
  EXPECT_LT(worst, 1e-6);
}

TEST(RobotModel, IkRefusesUnreachableTargets)
{
  const auto m = model();
  Vec3 q = Vec3::Constant(42.0);
  EXPECT_FALSE(m.ik(Leg::FL, Vec3(77.27, 29.0, -400.0), +1, q));
  EXPECT_DOUBLE_EQ(q(0), 42.0);   // untouched on failure
}

TEST(RobotModel, JacobianMatchesFiniteMotion)
{
  const auto m = model();
  const Vec3 q(0.1, -0.7, 1.4);
  const Eigen::Matrix3d J = m.point_jacobian(Leg::RR, q, kFoot);
  const Vec3 dq(1e-4, -2e-4, 1.5e-4);
  const Vec3 predicted = J * dq;
  const Vec3 actual = m.foot(Leg::RR, q + dq) - m.foot(Leg::RR, q);
  // Linearisation error is second order: |dq|^2 * leg length ~ 1e-5 mm here.
  EXPECT_LT((predicted - actual).norm(), 2e-5);
  EXPECT_GT(actual.norm(), 1e-2);   // and the motion itself is not negligible
}

TEST(RobotModel, LimitsNameTheOffendingJoint)
{
  const auto m = model();
  Joints q = Joints::Zero();
  q(3 * index_of(Leg::RL) + 2) = -10.0 * kDeg;   // knee folds forward only (positive)
  std::string why;
  EXPECT_FALSE(m.within_limits(q, 0.5 * kDeg, &why));
  EXPECT_NE(why.find("rl_knee"), std::string::npos);
}

TEST(RobotModel, LimitsArePerJoint)
{
  MotionConfig cfg;
  cfg.limits.hi(3 * index_of(Leg::RR) + 2) = 70.0 * kDeg;   // only rr_knee narrowed
  const RobotModel m = cfg.model();
  Joints q = Joints::Zero();
  q(3 * index_of(Leg::FL) + 2) = 100.0 * kDeg;
  EXPECT_TRUE(m.within_limits(q, 0.0));
  q(3 * index_of(Leg::RR) + 2) = 100.0 * kDeg;
  std::string why;
  EXPECT_FALSE(m.within_limits(q, 0.0, &why));
  EXPECT_NE(why.find("rr_knee"), std::string::npos);
}

TEST(ServoWindow, MatchesTheDriverPulseFormula)
{
  // fl_knee as calibrated 2026-09-21: 1540 us, not inverted.
  ServoCalibration cal{1540.0, 11.111, false, 0.0};
  AngleRange r = servo_window(cal, 500.0, 2500.0);
  EXPECT_NEAR(r.hi / kDeg, (2500.0 - 1540.0) / 11.111, 1e-9);
  EXPECT_NEAR(r.lo / kDeg, (500.0 - 1540.0) / 11.111, 1e-9);
  // Inverted: bending the other way runs into the low end.
  cal = {1350.0, 11.111, true, 0.0};
  r = servo_window(cal, 500.0, 2500.0);
  EXPECT_NEAR(r.hi / kDeg, (1350.0 - 500.0) / 11.111, 1e-9);
  // Trim shifts the window the opposite way.
  cal = {1500.0, 11.111, false, 5.0};
  r = servo_window(cal, 500.0, 2500.0);
  EXPECT_NEAR(r.hi / kDeg, 1000.0 / 11.111 - 5.0, 1e-9);
}

TEST(ServoWindow, AKneeThatCannotFoldIsCaughtAtStartUp)
{
  // A knee held to 76 deg cannot reach the 90 mm stand: the planner must say
  // so, naming the joint, instead of letting the driver clip it on the robot.
  MotionConfig cfg;
  cfg.limits.hi(3 * index_of(Leg::RR) + 2) = 76.0 * kDeg;
  std::string error;
  EXPECT_FALSE(Planner(cfg).self_check(error));
  EXPECT_NE(error.find("_knee"), std::string::npos) << error;
}

TEST(RobotModel, MassMatchesPayload)
{
  // 7" LCD + Pi 4 + frame + wiring + 12 servos + shanks + the 130 g head.
  EXPECT_NEAR(model().total_mass_g(), 884.0, 1e-9);
}

TEST(Support, MarginOfSquareCentreIsHalfTheSide)
{
  const std::vector<Vec2> sq{{50, 50}, {50, -50}, {-50, -50}, {-50, 50}};
  EXPECT_NEAR(support_margin(Vec2::Zero(), sq), 50.0, 1e-9);
  EXPECT_LT(support_margin(Vec2(80, 0), sq), 0.0);
}

TEST(Support, CollinearContactsCannotHoldTheRobot)
{
  const std::vector<Vec2> line{{-50, 0}, {0, 0}, {50, 0}};
  EXPECT_TRUE(std::isinf(support_margin(Vec2::Zero(), line)));
  EXPECT_LT(support_margin(Vec2::Zero(), line), 0.0);
}

int main(int argc, char ** argv)
{
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
