#include <gtest/gtest.h>

#include <cmath>
#include <string>

#include "pkun_motion/planner.hpp"

using namespace pkun_motion;

namespace
{

const Planner & planner()
{
  static const Planner p{MotionConfig{}};
  return p;
}

Posture expected_end(const std::string & name)
{
  if (name == "rest") {return Posture::Rest;}
  if (name == "sit" || name == "alert" || name == "medicine") {return Posture::Sit;}
  return Posture::Stand;
}

}  // namespace

TEST(Planner, OverloadedServosAreRefused)
{
  // A head fitted without updating the payload must not be walked into stall.
  MotionConfig heavy;
  heavy.mass.body.push_back({250.0, Vec3(90.0, 0.0, 40.0)});
  Request req;
  req.name = "walk";
  const Planner p{heavy};
  const PlanResult r = p.plan(req, Posture::Stand, p.posture_q(Posture::Stand));
  EXPECT_FALSE(r.ok);
  EXPECT_NE(r.error.find("torque"), std::string::npos) << r.error;
}

TEST(Planner, CanonicalPosturesAreSafe)
{
  std::string err;
  EXPECT_TRUE(planner().self_check(err)) << err;
}

TEST(Planner, RestNeverDropsBelowTheUnderbody)
{
  // Asking to lie at 40 mm must be overruled by the Pi hanging 55 mm down.
  EXPECT_GE(planner().rest_height(), 55.0 + planner().config().safety.min_clearance_mm - 1e-9);

  MotionConfig flat;   // Pi moved up onto the back: only the belly plate remains
  flat.posture.rest_height = 40.0;
  flat.underbody = {Vec3(77, 29, -14), Vec3(77, -29, -14), Vec3(-77, 29, -14), Vec3(-77, -29, -14)};
  const Planner deep{flat};
  EXPECT_LT(deep.rest_height(), planner().rest_height());
  std::string err;
  EXPECT_TRUE(deep.self_check(err)) << err;
}

/// Every behaviour, from every posture, at slow / nominal / fast: planned,
/// fully checked, starting exactly at the current joints, ending exactly on
/// the canonical pose of the posture it claims.
TEST(Planner, EveryBehaviourFromEveryPostureAtEverySpeed)
{
  const auto & p = planner();
  for (Posture from : {Posture::Rest, Posture::Stand, Posture::Sit}) {
    for (const auto & name : Planner::behaviors()) {
      for (double speed : {0.5, 1.0, 1.5}) {
        Request req;
        req.name = name;
        req.speed = speed;
        const Joints q0 = p.posture_q(from);
        const PlanResult r = p.plan(req, from, q0);
        const std::string ctx = name + " from " + to_string(from) + " at " + std::to_string(speed);
        ASSERT_TRUE(r.ok) << ctx << ": " << r.error;
        ASSERT_FALSE(r.traj.frames.empty()) << ctx;
        EXPECT_EQ(r.traj.frames.front().q, q0) << ctx;
        EXPECT_EQ(r.traj.end_posture, expected_end(name)) << ctx;
        const double end_err =
          (r.traj.frames.back().q - p.posture_q(r.traj.end_posture)).cwiseAbs().maxCoeff();
        EXPECT_LT(end_err, 1e-6) << ctx;
      }
    }
  }
}

TEST(Planner, BothPawsAndBothDirections)
{
  const auto & p = planner();
  for (const auto & [name, option] : std::vector<std::pair<std::string, std::string>>{
      {"beckon", "left"}, {"beckon", "right"}, {"walk", "forward"}, {"walk", "backward"}})
  {
    Request req;
    req.name = name;
    req.option = option;
    const auto r = p.plan(req, Posture::Stand, p.posture_q(Posture::Stand));
    EXPECT_TRUE(r.ok) << name << " " << option << ": " << r.error;
  }
}

TEST(Planner, PlantedFeetNeverSlideDuringTheWalk)
{
  const auto & p = planner();
  Request req;
  req.name = "walk";
  const auto r = p.plan(req, Posture::Stand, p.posture_q(Posture::Stand));
  ASSERT_TRUE(r.ok) << r.error;
  const auto & F = r.traj.frames;
  double worst = 0.0;
  for (std::size_t k = r.traj.gait.first_frame + 1; k < F.size(); ++k) {
    const Pose Ta = to_isometry(F[k - 1].body), Tb = to_isometry(F[k].body);
    for (Leg leg : kLegs) {
      const int j = index_of(leg);
      if (F[k - 1].contact[j] && F[k].contact[j]) {
        const Vec3 a = Ta * p.model().foot(leg, leg_q(F[k - 1].q, leg));
        const Vec3 b = Tb * p.model().foot(leg, leg_q(F[k].q, leg));
        worst = std::max(worst, (a - b).norm());
      }
    }
  }
  EXPECT_LT(worst, 1e-6);
}

TEST(Planner, WalkCanBeCutShortWithoutAJump)
{
  const auto & p = planner();
  Request req;
  req.name = "walk";
  req.count = 12;
  const Joints q0 = p.posture_q(Posture::Rest);
  const auto full = p.plan(req, Posture::Rest, q0);
  ASSERT_TRUE(full.ok) << full.error;

  // Pretend the cancel arrives a third of the way through.
  const std::size_t now = full.traj.frames.size() / 3;
  const int n = p.shortened_cycles(full.traj, now);
  ASSERT_GT(n, 0);
  ASSERT_LT(n, 12);

  req.count = n;
  req.speed = full.effective_speed;
  const auto cut = p.plan(req, Posture::Rest, q0);
  ASSERT_TRUE(cut.ok) << cut.error;
  EXPECT_LT(cut.traj.frames.size(), full.traj.frames.size());

  // Identical for a full second past the switch point: no visible jump.
  const std::size_t horizon = now + static_cast<std::size_t>(1.0 / full.traj.dt);
  for (std::size_t k = 0; k <= horizon; ++k) {
    ASSERT_LT((cut.traj.frames[k].q - full.traj.frames[k].q).cwiseAbs().maxCoeff(), 1e-9)
      << "frames diverge at " << k;
  }
  EXPECT_EQ(cut.traj.end_posture, Posture::Stand);
}

TEST(Planner, RecoversFromAnUnknownPose)
{
  const auto & p = planner();
  Joints q = p.posture_q(Posture::Stand);
  q(1) += 0.5;   // something bumped a leg while torque was off
  q(8) -= 0.4;
  for (const std::string name : {"rest", "stand", "walk"}) {
    Request req;
    req.name = name;
    const auto r = p.plan(req, Posture::Unknown, q);
    EXPECT_TRUE(r.ok) << name << ": " << r.error;
    if (r.ok) {EXPECT_EQ(r.traj.frames.front().q, q);}
  }
}

TEST(Planner, RejectsNonsense)
{
  const auto & p = planner();
  Request req;
  req.name = "fly";
  EXPECT_FALSE(p.plan(req, Posture::Stand, p.posture_q(Posture::Stand)).ok);

  req.name = "stand";
  Joints bad = p.posture_q(Posture::Stand);
  bad(4) = std::nan("");
  EXPECT_FALSE(p.plan(req, Posture::Stand, bad).ok);
}

TEST(Planner, IdleBreathingStaysSafe)
{
  const auto & p = planner();
  for (Posture posture : {Posture::Rest, Posture::Stand, Posture::Sit}) {
    Trajectory t;
    t.name = std::string("idle ") + to_string(posture);
    t.dt = p.dt();
    for (double s = 0.0; s <= 2.0 * p.config().gesture.breathe_period; s += t.dt) {
      Frame f = p.posture_frame(posture);
      f.q = p.idle(posture, s);
      // breathing only lifts: height never below the canonical pose
      t.frames.push_back(f);
    }
    // Body is re-derived only approximately here, so check limits and speed.
    SafetyConfig relaxed = p.config().safety;
    relaxed.min_margin_mm = -1e9;
    relaxed.min_clearance_mm = -1e9;
    relaxed.ground_tol_mm = 1e9;
    const Verdict v = check(t, p.model(), relaxed);
    EXPECT_TRUE(v.ok) << v.error;
    EXPECT_LT(v.stats.peak_rate_dps, 10.0);
  }
}

int main(int argc, char ** argv)
{
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

TEST(Planner, NeckStartsWhereItIsStaysInRangeAndNeverJumps)
{
  const auto & nc = planner().config().neck;
  // The neck's own cap (+ rounding), well under the driver's 180 deg/s.
  const double max_step = (nc.max_rate_dps + 1.0) * kDeg * planner().dt();
  for (const auto & name : Planner::behaviors()) {
    for (Posture from : {Posture::Rest, Posture::Stand, Posture::Sit}) {
      for (double neck_now : {-20.0, 0.0, 20.0}) {
        Request req;
        req.name = name;
        const PlanResult r = planner().plan(req, from, planner().posture_q(from), neck_now * kDeg);
        ASSERT_TRUE(r.ok) << name << " from " << to_string(from) << ": " << r.error;
        const auto & f = r.traj.frames;
        EXPECT_NEAR(f.front().neck, neck_now * kDeg, 1e-9) << name;
        for (std::size_t k = 0; k < f.size(); ++k) {
          ASSERT_TRUE(std::isfinite(f[k].neck)) << name;
          EXPECT_GE(f[k].neck, nc.min_deg * kDeg - 1e-9) << name << " frame " << k;
          EXPECT_LE(f[k].neck, nc.max_deg * kDeg + 1e-9) << name << " frame " << k;
          if (k > 0) {
            EXPECT_LE(std::abs(f[k].neck - f[k - 1].neck), max_step)
              << name << " from " << to_string(from) << " jumps at frame " << k;
          }
        }
        EXPECT_NEAR(f.back().neck, planner().neck_deg(r.traj.end_posture) * kDeg, 0.5 * kDeg)
          << name << " from " << to_string(from) << " does not settle the neck";
      }
    }
  }
}

TEST(Planner, NeckActuallyMovesInGestures)
{
  // Each of these should visibly use the head, not just hold it.
  for (const std::string name : {"nod", "eat", "alert", "play_bow", "happy", "medicine"}) {
    Request req;
    req.name = name;
    const PlanResult r = planner().plan(req, Posture::Stand, planner().posture_q(Posture::Stand), 0.0);
    ASSERT_TRUE(r.ok) << r.error;
    double lo = 1e9, hi = -1e9;
    for (const Frame & f : r.traj.frames) {lo = std::min(lo, f.neck); hi = std::max(hi, f.neck);}
    EXPECT_GT(hi - lo, 5.0 * kDeg) << name;
  }
}
