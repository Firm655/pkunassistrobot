#!/usr/bin/env python3
"""Turn ~/servo_calib.json (written by servo_calib.py) into servos.yaml for
pkun_servo_driver -- so the calibration has one source of truth.

    python3 calib_to_servos_yaml.py [servo_calib.json] [servos.yaml]

Touches no hardware. Also prints the range each joint really gets inside the
servo pulse window, which is what pkun_motion plans within.

Conventions (verified on the robot, see kinematic_apply.py):
  * hardware leg -> model leg:  leg4 = FL, leg3 = FR, leg1 = RL, leg2 = RR
    (the "position" labels inside servo_calib.json are stale -- ignored)
  * hip -> abduction, thigh -> hip_pitch, knee -> knee
  * sign and zero: calib_deg = SIGN * (model_deg - INITIAL_MODEL[joint]), where
    INITIAL_MODEL is the model pose the calibration's own initial pose holds.
    Since 2026-09-23 that initial pose is: legs straight down, but each KNEE
    already folded 90 deg with the knee pointing forward -- so the knee's model
    zero (a straight leg) is 90 deg away from its neutral_us, and the servo can
    both straighten the leg and fold it further from there.
  * the driver's center_us is the pulse at model angle 0, which is why this
    script shifts it by the initial-pose offset instead of copying neutral_us.
  * the head (servo_calib.json "head" section, from servo_calib.py --head) is
    optional. Its angles are the calibration's own: 0 = the initial pose, + as
    servo_calib.py defines it (neck + = look up). Only the neck is wired into
    motion so far, as head_pitch; ear and mouth are left out until they are.
    Its min_us/max_us become min_deg/max_deg, so nothing is ever driven into
    the jaw or neck stops.
  * an optional "trim_deg" per joint in servo_calib.json corrects a horn whose
    real zero sits a few degrees off the calibrated one -- it shifts that
    joint's model zero and nothing else. + tilts the joint the way a + model
    angle does.
"""
import json
import sys
from pathlib import Path

LEG_TO_MODEL = {"leg4": "fl", "leg3": "fr", "leg1": "rl", "leg2": "rr"}
JOINT_TO_MODEL = {"hip": "abduction", "thigh": "hip_pitch", "knee": "knee"}
SIGN = {"abduction": -1, "hip_pitch": +1, "knee": +1}   # hip_pitch checked on the robot 2026-09-23
INITIAL_MODEL = {"abduction": 0.0, "hip_pitch": 0.0, "knee": 90.0}   # model angle at neutral_us
MECH = {"abduction": (-55.0, 55.0), "hip_pitch": (-90.0, 90.0), "knee": (0.0, 150.0)}
# NOT applied (2026-09-25): a "mirror" was tried on 2026-09-24 because the robot
# walked AND turned backwards (only a mirror image does both): hip_pitch/knee
# SIGN -1, knee INITIAL_MODEL -90, MECH (-150, 0). Done here alone it limits
# the knees to 0..38 deg and the motion node refuses to start. If walking is
# still backwards, the fix has to change the planner's knee direction too.
ORDER = ["fl", "fr", "rl", "rr"]
MAX_RATE_DPS = 400.0    # above the planner's 300 deg/s cap: the driver never truncates a plan
SAFE_INSET_US = 100.0   # kept clear at each end of the pulse window
HEAD_TO_MODEL = {"neck": "head_pitch"}          # ear / mouth: not driven yet
HEAD_MECH = (-45.0, 45.0)                       # until the range step has been done
HEAD_RATE_DPS = 180.0                           # a head, not a leg: never snappy


def main():
    src = Path(sys.argv[1] if len(sys.argv) > 1 else Path.home() / "servo_calib.json")
    dst = Path(sys.argv[2]) if len(sys.argv) > 2 else (
        Path(__file__).resolve().parents[2] / "pkun_servo_driver" / "config" / "servos.yaml")
    cal = json.loads(src.read_text(encoding="utf-8"))
    lo_us, hi_us = cal.get("pulse_limits_us", [500, 2500])
    # Stay off the electrical ends. 500-2500 us is the widest a hobby servo
    # accepts, but the horn usually hits its own mechanical stop before that:
    # the servo then sits there stalled, buzzing, until the pose ends, and
    # that is what strips its gears. Both front thigh servos died this way on
    # 2026-09-25, driven to within 0.3 deg of the limit by the `eat` pose.
    # SAFE_INSET_US is about 9 deg of travel given up at each end.
    lo_us, hi_us = lo_us + SAFE_INSET_US, hi_us - SAFE_INSET_US
    nominal = cal.get("nominal_us_per_deg", 11.111)
    addr = int(str(cal.get("pca9685", {}).get("addr", "0x40")), 0)
    bus = cal.get("pca9685", {}).get("bus", 1)
    osc = float(cal.get("pca9685", {}).get("osc_hz", 25_000_000))

    rows = {}
    for hw_leg, legd in cal["legs"].items():
        leg = LEG_TO_MODEL[hw_leg]
        for hw_joint, e in legd["joints"].items():
            joint = JOINT_TO_MODEL[hw_joint]
            upd = e.get("us_per_deg") or nominal
            sign = SIGN[joint]
            invert = e["direction"] * sign == -1
            # Pulse at model angle 0, i.e. neutral_us shifted by the initial pose.
            c = float(e["neutral_us"]) - e["direction"] * upd * sign * INITIAL_MODEL[joint]
            s = -1.0 if invert else 1.0
            a, b = (lo_us - c) / (s * upd), (hi_us - c) / (s * upd)
            mlo, mhi = MECH[joint]
            trim = float(e.get("trim_deg", 0.0))
            rows[f"{leg}_{joint}"] = dict(channel=int(e["channel"]), center=c, upd=upd,
                                          invert=invert, lo=max(mlo, min(a, b)) - trim,
                                          hi=min(mhi, max(a, b)) - trim, mech=(mlo, mhi),
                                          trim=trim)

    names = [f"{leg}_{j}" for leg in ORDER for j in ("abduction", "hip_pitch", "knee")]
    missing = [n for n in names if n not in rows]
    if missing:
        sys.exit(f"calibration is missing: {', '.join(missing)}")

    for hw_joint, e in cal.get("head", {}).get("joints", {}).items():
        joint = HEAD_TO_MODEL.get(hw_joint)
        if joint is None:
            continue
        upd = e.get("us_per_deg") or nominal
        invert = e["direction"] == -1
        c = float(e["neutral_us"])
        s = -1.0 if invert else 1.0
        mlo, mhi = HEAD_MECH
        if e.get("min_us") and e.get("max_us"):
            # A range end left at the pulse floor/ceiling is "not found", not a
            # stop 140 deg away: it still gets the default mechanical bound.
            a, b = (e["min_us"] - c) / (s * upd), (e["max_us"] - c) / (s * upd)
            mlo, mhi = max(-90.0, round(min(a, b), 1)), min(90.0, round(max(a, b), 1))
        a, b = (lo_us - c) / (s * upd), (hi_us - c) / (s * upd)
        rows[joint] = dict(channel=int(e["channel"]), center=c, upd=upd, invert=invert,
                           lo=max(mlo, min(a, b)), hi=min(mhi, max(a, b)), mech=(mlo, mhi),
                           trim=0.0, rate=HEAD_RATE_DPS)
        names.append(joint)

    chans = [rows[n]["channel"] for n in names]
    if len(set(chans)) != len(chans):
        sys.exit("two joints share a PCA9685 channel")

    out = [
        "# GENERATED by pkun_bringup/scripts/calib_to_servos_yaml.py from",
        f"# {src} -- re-run it after recalibrating instead of editing by hand.",
        "#",
        "# pulse = center_us + s * (angle_deg + trim_deg) * us_per_deg,  s = invert ? -1 : +1",
        "# angle_deg is the model angle; 0 = the calibration's initial pose (legs straight).",
        "# min_deg/max_deg are the mechanism; the driver and pkun_motion both narrow",
        "# them further to what pulse_min_us..pulse_max_us allows.",
        "",
        "/**:",
        "  ros__parameters:",
        f"    i2c_bus: /dev/i2c-{bus}",
        f"    board_addresses: [0x{addr:02x}]",
        "    update_rate_hz: 50.0      # analog servos: 50 Hz",
        f"    osc_hz: {osc:.1f}      # PCA9685 oscillator, same value servo_calib.py used",
        "    state_rate_hz: 10.0",
        "    enable_stagger_s: 0.08    # servos switch on one at a time",
        "    command_timeout_s: 0.5    # warn (and hold) if joint_command stops",
        f"    pulse_min_us: {float(lo_us):.1f}    # {SAFE_INSET_US:.0f} us inside the servo's end of travel",
        f"    pulse_max_us: {float(hi_us):.1f}",
        "",
        "    joints:",
    ]
    out += [f"      - {n}" for n in names]
    out += ["", "    servos:"]
    for n in names:
        r = rows[n]
        out.append(
            f"      {n + ':':<14}{{board: 0, channel: {r['channel']:>2}, center_us: {r['center']:.1f}, "
            f"us_per_deg: {r['upd']:.3f}, min_deg: {r['mech'][0]:.1f}, max_deg: {r['mech'][1]:.1f}, "
            f"invert: {'true' if r['invert'] else 'false'}, trim_deg: {r['trim']:.2f}, "
            f"max_rate_dps: {r.get('rate', MAX_RATE_DPS):.1f}}}")
    dst.write_text("\n".join(out) + "\n", encoding="utf-8")
    print(f"wrote {dst}\n")

    print(f"{'joint':<14}{'ch':>3}{'center':>8}  usable range (deg)")
    for n in names:
        r = rows[n]
        flag = ""
        if n.endswith("knee") and r["hi"] < 140:
            flag = f"  <- knee folds only {r['hi']:.0f} of 150 deg"
        trim = f"  trim {r['trim']:+.1f}" if r["trim"] else ""
        print(f"{n:<14}{r['channel']:>3}{r['center']:>8.0f}  {r['lo']:7.1f} .. {r['hi']:6.1f}{trim}{flag}")


if __name__ == "__main__":
    main()
