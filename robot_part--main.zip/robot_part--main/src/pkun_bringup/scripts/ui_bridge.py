#!/usr/bin/env python3
"""Turn the device app's UI events into P-kun behaviours.

The patient-facing app (Firm655/pkunassistrobot, clientdevice/pkun/robot.py)
publishes JSON on /pkun/ui_event as std_msgs/String:

    {"event": "notify",   "kind": "MEDICINE"}
    {"event": "response", "kind": "MEDICINE", "answer": "NO"}
    {"event": "request",  "code": "HELP"}
    {"event": "game",     "game": "color_box", "state": "correct"}

This node maps each one to a Behavior goal on ~/behavior of the motion node.
The mapping lives in parameters (config/ui_bridge.yaml), so which gesture goes
with which event can change without touching code:

    notify.MEDICINE: "medicine"        # behaviour name
    game.finished:   "happy:3"         # behaviour:count
    response.DISPLAYED: ""             # ignore this one

Rules that matter on a real robot:

* One behaviour at a time. A notification or a call for help interrupts
  whatever is running (the walk stops at a safe footfall first); game events
  never interrupt -- the robot is only reacting to a game, and a half-finished
  gesture looks worse than a missed one.
* Repeats of the same event inside `min_interval_s` are dropped, so a game
  that fires "correct" three times in a second does not make the robot thrash.
* Nothing here ever blocks: the app's events keep arriving while a behaviour
  runs, and the newest pending one wins.
"""
import json

import rclpy
from rclpy.action import ActionClient
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node
from std_msgs.msg import String

from pkun_msgs.action import Behavior

DEFAULT_MAP = {
    # what the app shows -> what the body does
    "notify.MEDICINE": "medicine",
    "notify.MEAL": "eat",
    "notify.DAILY_CHECK_IN": "alert",
    "notify.TASK": "nod",
    "notify.MESSAGE": "beckon",
    "notify.default": "alert",
    # the patient answered
    "response.YES": "happy:1",
    "response.NO": "nod:1",
    "response.DISPLAYED": "",
    "response.default": "happy:1",
    # the patient asked for something
    "request.HELP": "alert",
    "request.HUNGRY": "eat",
    "request.NOT_RIGHT": "alert",
    "request.default": "alert",
    # games
    "game.start": "play_bow",
    "game.correct": "happy:1",
    "game.wrong": "nod:1",
    "game.finished": "happy:3",
    "game.default": "",
}

# Events allowed to cut a running behaviour short.
INTERRUPTING = ("notify", "request")


class UiBridge(Node):
    def __init__(self):
        super().__init__("ui_bridge")
        topic = self.declare_parameter("ui_event_topic", "ui_event").value
        action = self.declare_parameter("behavior_action", "motion/behavior").value
        self.min_interval = float(self.declare_parameter("min_interval_s", 1.0).value)
        self.interrupt = bool(self.declare_parameter("interrupt_for_notifications", True).value)

        self.mapping = {}
        for key, default in DEFAULT_MAP.items():
            self.mapping[key] = str(self.declare_parameter(key, default).value)

        self.client = ActionClient(self, Behavior, action)
        self.create_subscription(String, topic, self.on_event, 10)

        self.active = None        # goal handle of the behaviour running now
        self.pending = None       # (name, count) waiting for it to end
        self.cancelling = False
        self.last = {}            # key -> time of the last goal from it

        self.get_logger().info(
            f"listening on {topic}, sending to {action}; "
            f"{sum(1 for v in self.mapping.values() if v)} events mapped")

    # -- incoming ------------------------------------------------------------

    def on_event(self, msg):
        try:
            data = json.loads(msg.data)
        except (ValueError, TypeError):
            self.get_logger().warning(f"ui_event is not JSON: {msg.data[:80]!r}")
            return
        if not isinstance(data, dict):
            self.get_logger().warning("ui_event is not a JSON object")
            return

        event = str(data.get("event", ""))
        if event == "notify":
            key = f"notify.{data.get('kind')}"
        elif event == "response":
            # The check-in answers are configured per patient, so fall back on
            # the default rather than needing every possible answer listed.
            key = f"response.{data.get('answer')}"
        elif event == "request":
            key = f"request.{data.get('code')}"
        elif event == "game":
            key = f"game.{data.get('state')}"
        else:
            self.get_logger().debug(f"ignoring event '{event}'")
            return

        target = self.mapping.get(key)
        if target is None:
            target = self.mapping.get(f"{event}.default", "")
        if not target:
            self.get_logger().debug(f"{key}: nothing mapped")
            return

        name, _, count_text = target.partition(":")
        try:
            count = int(count_text) if count_text else 0
        except ValueError:
            self.get_logger().warning(f"{key}: '{target}' is not behaviour[:count]")
            return

        now = self.get_clock().now().nanoseconds * 1e-9
        if now - self.last.get(key, -1e9) < self.min_interval:
            self.get_logger().debug(f"{key}: too soon after the last one")
            return
        self.last[key] = now

        self.get_logger().info(f"{key} -> {name}" + (f" x{count}" if count else ""))
        self.request(name, count, interrupting=event in INTERRUPTING)

    # -- talking to the motion node -----------------------------------------

    def request(self, name, count, interrupting):
        if not self.client.server_is_ready():
            self.get_logger().warning(f"motion action server is not up; dropping '{name}'")
            return
        if self.active is None:
            self.send(name, count)
            return
        if not (interrupting and self.interrupt):
            self.get_logger().info(f"busy; dropping '{name}'")
            return
        # Newest wins: whatever was waiting is replaced.
        self.pending = (name, count)
        if not self.cancelling:
            self.cancelling = True
            self.get_logger().info(f"cancelling the running behaviour for '{name}'")
            self.active.cancel_goal_async()

    def send(self, name, count):
        goal = Behavior.Goal()
        goal.name = name
        goal.count = count
        future = self.client.send_goal_async(goal)
        future.add_done_callback(lambda f: self.on_accepted(f, name))

    def on_accepted(self, future, name):
        handle = future.result()
        if handle is None or not handle.accepted:
            self.get_logger().warning(f"'{name}' was rejected by the motion node")
            self.active = None
            self.start_pending()
            return
        self.active = handle
        handle.get_result_async().add_done_callback(lambda f: self.on_finished(f, name))

    def on_finished(self, future, name):
        result = future.result()
        if result is not None and not result.result.success:
            self.get_logger().warning(f"'{name}' ended: {result.result.message}")
        self.active = None
        self.cancelling = False
        self.start_pending()

    def start_pending(self):
        if self.pending is None:
            return
        name, count = self.pending
        self.pending = None
        self.send(name, count)


def main():
    rclpy.init()
    node = UiBridge()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
