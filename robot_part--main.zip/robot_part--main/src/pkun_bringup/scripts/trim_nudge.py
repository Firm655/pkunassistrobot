#!/usr/bin/env python3
"""Nudge one joint's zero while the robot holds its pose, and save the result
into ~/servo_calib.json.

    ros2 run pkun_bringup trim_nudge.py rr_hip_pitch
    trim_nudge.py rr_hip_pitch --step 0.6      # degrees per keypress

Keys:  - / +   tilt the joint (- is the direction a negative model angle takes)
       s       save the current value into servo_calib.json as trim_deg
       r       back to zero
       q       quit without saving

One node stays up for the whole session, so a keypress moves the servo at once.
(The first version shelled out to `ros2 service call` per keypress: two seconds
each, and it ate the keys pressed while it was starting.)
"""
import argparse
import json
import math
import pathlib
import select
import sys
import termios
import tty

def _ensure_ros_env():
    """Re-exec ourselves with ROS sourced, so the script works when run by path.

    Running it as ~/pkun-system/scripts/numpad_control.py from a fresh shell
    would otherwise fail on `import pkun_msgs`, which tells the user nothing
    about the actual problem: this file is fine, the shell just has no ROS in
    it. One re-exec, guarded so it cannot loop.
    """
    import os
    import sys
    if os.environ.get("PKUN_RESOURCED") == "1":
        return
    setup = os.environ.get("ROS_DISTRO_SETUP", "/opt/ros/jazzy/setup.bash")
    workspace = os.environ.get("PKUN_WORKSPACE", os.path.expanduser("~/pkun/controller"))
    overlay = os.path.join(workspace, "install", "setup.bash")
    if not (os.path.exists(setup) and os.path.exists(overlay)):
        return
    args = " ".join(f"'{a}'" for a in [sys.executable, os.path.abspath(__file__)] + sys.argv[1:])
    os.environ["PKUN_RESOURCED"] = "1"
    os.execvp("bash", ["bash", "-c", f"source '{setup}' && source '{overlay}' && exec {args}"])


try:
    # pkun_msgs, not rclpy: rclpy happens to be importable on this Pi even
    # without sourcing, while the workspace's own messages never are.
    import pkun_msgs  # noqa: F401
except ModuleNotFoundError:
    _ensure_ros_env()

import rclpy
from rclpy.node import Node

from pkun_msgs.srv import SetTrim

# model joint name -> where it lives in servo_calib.json
LEG = {"fl": "leg4", "fr": "leg3", "rl": "leg1", "rr": "leg2"}
JOINT = {"abduction": "hip", "hip_pitch": "thigh", "knee": "knee"}


def save(calib_path, joint, trim_deg):
    leg, _, rest = joint.partition("_")
    path = pathlib.Path(calib_path).expanduser()
    data = json.loads(path.read_text(encoding="utf-8"))
    entry = data["legs"][LEG[leg]]["joints"][JOINT[rest]]
    entry["trim_deg"] = round(trim_deg, 2)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("joint", help="e.g. rr_hip_pitch")
    ap.add_argument("--step", type=float, default=1.1, help="degrees per keypress")
    ap.add_argument("--namespace", default="/pkun")
    ap.add_argument("--calib", default="~/servo_calib.json")
    args = ap.parse_args()

    leg, _, rest = args.joint.partition("_")
    if leg not in LEG or rest not in JOINT:
        sys.exit(f"unknown joint '{args.joint}' (fl|fr|rl|rr _ abduction|hip_pitch|knee)")

    rclpy.init()
    node = Node("trim_nudge")
    client = node.create_client(SetTrim, f"{args.namespace}/servo_driver/set_trim")
    if not client.wait_for_service(timeout_sec=5.0):
        node.destroy_node(); rclpy.shutdown()
        sys.exit(f"{args.namespace}/servo_driver/set_trim not there -- is the launch running?")

    trim = 0.0

    def apply():
        req = SetTrim.Request()
        req.name = args.joint
        req.trim = math.radians(trim)
        req.persist = False
        future = client.call_async(req)
        rclpy.spin_until_future_complete(node, future, timeout_sec=2.0)
        result = future.result()
        if result is None:
            return "no reply from the driver"
        return None if result.success else result.message

    if not sys.stdin.isatty():
        node.destroy_node(); rclpy.shutdown()
        sys.exit("run this from a terminal: it reads single keypresses")

    print(f"{args.joint}: - / + to tilt ({args.step:.1f} deg), s = save, r = reset, q = quit")
    fd = sys.stdin.fileno()
    saved = termios.tcgetattr(fd)
    try:
        tty.setcbreak(fd)
        while True:
            problem = apply()
            status = f"  <- {problem}" if problem else ""
            print(f"\rtrim {trim:+6.1f} deg{status}        ", end="", flush=True)
            if problem:
                print()
                return
            while not select.select([sys.stdin], [], [], 0.1)[0]:
                pass
            key = sys.stdin.read(1)
            if key in "+=k":
                trim += args.step
            elif key in "-_j":
                trim -= args.step
            elif key == "r":
                trim = 0.0
            elif key == "s":
                path = save(args.calib, args.joint, trim)
                print(f"\nsaved trim_deg {trim:+.1f} for {args.joint} into {path}")
                print("relaunch to pick it up (no rebuild needed)")
                return
            elif key == "q":
                print(f"\nnot saved. Final value was trim_deg {trim:+.1f}")
                return
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, saved)
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
