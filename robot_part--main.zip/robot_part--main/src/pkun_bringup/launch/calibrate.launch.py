"""Servo calibration bringup: driver only, no motion, no gait.

Nothing publishes joint commands here, and the driver pulses a channel only
after it has been sent a target -- so only the joints you command are powered.
That is exactly what you want while fitting horns.

  ros2 launch pkun_bringup calibrate.launch.py

Then, in another terminal:

  # release every servo so you can move the joints by hand
  ros2 service call /pkun/servo_driver/set_torque pkun_msgs/srv/SetTorque \\
      "{enable: false, name: []}"

  # re-enable and command one joint to zero
  ros2 service call /pkun/servo_driver/set_torque pkun_msgs/srv/SetTorque \\
      "{enable: true, name: []}"
  ros2 topic pub --once /pkun/joint_command pkun_msgs/msg/JointCommand \\
      "{name: ['fl_knee'], position: [0.0], duration: 1.0}"

  # nudge the zero until the link is truly straight, then read it back
  ros2 service call /pkun/servo_driver/set_trim pkun_msgs/srv/SetTrim \\
      "{name: 'fl_knee', trim: 0.035, persist: true}"
  ros2 param get /pkun/servo_driver servos.fl_knee.trim_deg

Recalibrating center_us is done with ~/servo_calib.py (Python, NOT at the same
time as this launch); then regenerate servos.yaml from it:

  python3 src/pkun_bringup/scripts/calib_to_servos_yaml.py
"""

import os
import sys


from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, EmitEvent, LogInfo, RegisterEventHandler
from launch.events import matches_action
from launch.substitutions import LaunchConfiguration

from launch_ros.actions import LifecycleNode
from launch_ros.event_handlers import OnStateTransition
from launch_ros.events.lifecycle import ChangeState

import lifecycle_msgs.msg


def generate_launch_description():
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from _calib import servos_yaml as servos_yaml_from_calib

    servos_yaml = servos_yaml_from_calib(
        os.environ.get('PKUN_CALIB', '~/servo_calib.json'), True)
    namespace = LaunchConfiguration('namespace')

    servo_driver = LifecycleNode(
        package='pkun_servo_driver',
        executable='servo_driver_node',
        name='servo_driver',
        namespace=namespace,
        parameters=[servos_yaml],
        output='screen',
    )

    return LaunchDescription([
        DeclareLaunchArgument('namespace', default_value='pkun'),
        servo_driver,
        EmitEvent(
            event=ChangeState(
                lifecycle_node_matcher=matches_action(servo_driver),
                transition_id=lifecycle_msgs.msg.Transition.TRANSITION_CONFIGURE,
            )
        ),
        RegisterEventHandler(
            OnStateTransition(
                target_lifecycle_node=servo_driver,
                goal_state='inactive',
                entities=[
                    LogInfo(msg='servo driver ready for calibration'),
                    EmitEvent(
                        event=ChangeState(
                            lifecycle_node_matcher=matches_action(servo_driver),
                            transition_id=lifecycle_msgs.msg.Transition.TRANSITION_ACTIVATE,
                        )
                    ),
                ],
            )
        ),
    ])
