"""Bring up P-kun: the servo driver and the motion executive, nothing else.

  ros2 launch pkun_bringup pkun.launch.py
  ros2 launch pkun_bringup pkun.launch.py startup_posture:=stand

BEFORE LAUNCHING, put the robot down in `startup_posture` (default: lying
down). Hobby servos cannot report where they are, so the first command each
one receives is that pose -- the driver switches the twelve servos on one at a
time, 80 ms apart, and each moves straight to it.

Order: the servo driver is configured (opens I2C, probes the PCA9685) and only
activated once that succeeds. Activation writes nothing; a channel starts
pulsing only when the motion node has sent it a target. The motion node plans
and checks every behaviour at start-up and exits if the config is unsafe.

Then:
  ros2 action send_goal /pkun/motion/behavior pkun_msgs/action/Behavior "{name: stand}"
  ros2 topic echo /pkun/motion/status
"""

import os
import sys

from ament_index_python.packages import get_package_share_directory

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, EmitEvent, LogInfo, RegisterEventHandler
from launch.conditions import IfCondition
from launch.events import matches_action
from launch.substitutions import LaunchConfiguration

from launch_ros.actions import LifecycleNode, Node
from launch_ros.event_handlers import OnStateTransition
from launch_ros.events.lifecycle import ChangeState

import lifecycle_msgs.msg


def generate_launch_description():
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from _calib import servos_yaml as servos_yaml_from_calib

    motion_yaml = os.path.join(
        get_package_share_directory('pkun_motion'), 'config', 'motion.yaml')
    # Channels, neutral pulses and directions come from the calibration file
    # every time this launches -- editing it is enough, no rebuild.
    servos_yaml = servos_yaml_from_calib(
        os.environ.get('PKUN_CALIB', '~/servo_calib.json'), True)

    namespace = LaunchConfiguration('namespace')
    startup_posture = LaunchConfiguration('startup_posture')

    args = [
        DeclareLaunchArgument('namespace', default_value='pkun'),
        DeclareLaunchArgument(
            'startup_posture', default_value='rest',
            description='rest | stand | sit -- the pose the robot is physically in at launch.'),
        DeclareLaunchArgument(
            'ui_bridge', default_value='true',
            description="Start the bridge from the device app's /pkun/ui_event topic."),
    ]

    servo_driver = LifecycleNode(
        package='pkun_servo_driver',
        executable='servo_driver_node',
        name='servo_driver',
        namespace=namespace,
        parameters=[servos_yaml],
        output='screen',
    )

    configure_servos = EmitEvent(
        event=ChangeState(
            lifecycle_node_matcher=matches_action(servo_driver),
            transition_id=lifecycle_msgs.msg.Transition.TRANSITION_CONFIGURE,
        )
    )

    activate_servos = RegisterEventHandler(
        OnStateTransition(
            target_lifecycle_node=servo_driver,
            goal_state='inactive',
            entities=[
                LogInfo(msg='servo driver configured, activating'),
                EmitEvent(
                    event=ChangeState(
                        lifecycle_node_matcher=matches_action(servo_driver),
                        transition_id=lifecycle_msgs.msg.Transition.TRANSITION_ACTIVATE,
                    )
                ),
            ],
        )
    )

    # servos.yaml is loaded here too: the planner takes each joint's usable
    # range from the same calibration the driver uses.
    motion = Node(
        package='pkun_motion',
        executable='motion_node',
        name='motion',
        namespace=namespace,
        parameters=[motion_yaml, servos_yaml, {'startup_posture': startup_posture}],
        output='screen',
    )

    # Bridges the device app's UI events (Firm655/pkunassistrobot) to
    # behaviours. Harmless with no app running: it just waits for events.
    ui_bridge = Node(
        package='pkun_bringup',
        executable='ui_bridge.py',
        name='ui_bridge',
        namespace=namespace,
        parameters=[os.path.join(
            get_package_share_directory('pkun_bringup'), 'config', 'ui_bridge.yaml')],
        condition=IfCondition(LaunchConfiguration('ui_bridge')),
        output='screen',
    )

    return LaunchDescription(
        args + [servo_driver, configure_servos, activate_servos, motion, ui_bridge])
