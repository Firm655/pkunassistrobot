"""Regenerate servos.yaml from ~/servo_calib.json at launch time.

The calibration file is the single source of truth: edit it (or re-run
servo_calib.py) and the next launch picks the new values up, with no rebuild.
Falls back to the servos.yaml installed with pkun_servo_driver if the
calibration is missing or the converter fails -- a launch should not die
because a JSON file moved.
"""

import os
import subprocess

from ament_index_python.packages import get_package_prefix, get_package_share_directory

from launch.logging import get_logger


def servos_yaml(calib_path: str, regenerate: bool) -> str:
    installed = os.path.join(
        get_package_share_directory('pkun_servo_driver'), 'config', 'servos.yaml')
    log = get_logger('pkun_bringup')
    if not regenerate:
        return installed

    calib_path = os.path.expanduser(calib_path)
    if not os.path.exists(calib_path):
        log.warning(f'{calib_path} not found -- using {installed}')
        return installed

    script = os.path.join(
        get_package_prefix('pkun_bringup'), 'lib', 'pkun_bringup', 'calib_to_servos_yaml.py')
    out_dir = os.path.join(os.path.expanduser('~'), '.cache', 'pkun')
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, 'servos.yaml')
    try:
        result = subprocess.run(
            ['/usr/bin/python3', script, calib_path, out],
            check=True, capture_output=True, text=True, timeout=30)
    except (subprocess.SubprocessError, OSError) as exc:
        detail = getattr(exc, 'stderr', '') or str(exc)
        log.error(f'could not convert {calib_path}: {detail.strip()} -- using {installed}')
        return installed

    log.info(f'servo map from {calib_path}:\n{result.stdout.strip()}')
    return out
