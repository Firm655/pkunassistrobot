#ifndef PKUN_SERVO_DRIVER__PCA9685_HPP_
#define PKUN_SERVO_DRIVER__PCA9685_HPP_

#include <array>
#include <cstdint>
#include <string>

namespace pkun_servo_driver
{

/// Minimal PCA9685 16-channel PWM driver over Linux i2c-dev.
///
/// Deliberately uses plain read()/write() after an I2C_SLAVE ioctl rather than
/// the SMBus helpers, so the package needs no libi2c-dev dependency.
///
/// Not thread safe: one instance is owned by one node and touched only from
/// the control timer.
class Pca9685
{
public:
  /// PCA9685 oscillator, used for the prescale calculation.
  static constexpr double kOscHz = 25'000'000.0;
  static constexpr uint16_t kTicks = 4096;
  static constexpr uint8_t kNumChannels = 16;

  /// Ticks a new pulse must move away from what is on the chip before it is
  /// written. Without this, a target sitting on a rounding boundary flips
  /// between two tick values and the servo buzzes; 0.75 tick is 3.7 us, below
  /// any hobby servo's deadband.
  static constexpr double kHysteresisTicks = 0.75;

  /// `osc_hz` is the chip's real oscillator. Nominally 25 MHz, but individual
  /// chips run a few percent off, which scales every pulse by the same factor.
  Pca9685(std::string bus, uint8_t address, double osc_hz = kOscHz);
  ~Pca9685();

  Pca9685(const Pca9685 &) = delete;
  Pca9685 & operator=(const Pca9685 &) = delete;

  /// Open the bus and put the chip into a known state (auto-increment on, all
  /// outputs off). Also takes an exclusive lock (lock_path()) so a second
  /// program -- servo_calib.py while the robot runs, say -- cannot reprogram
  /// the same chip underneath us. Returns false and fills `error` on failure.
  bool open(std::string & error);
  void close();
  bool is_open() const {return fd_ >= 0;}

  /// Set the shared PWM frequency for all 16 channels. Analog servos want 50 Hz.
  /// The chip must be put to sleep to change the prescaler, so this drops the
  /// outputs briefly -- only call it while deactivated.
  bool set_frequency(double hz, std::string & error);

  /// Raw 12-bit on/off tick setting for one channel.
  bool set_pwm(uint8_t channel, uint16_t on, uint16_t off, std::string & error);

  /// Drive one channel with a pulse of `microseconds`, using the frequency last
  /// passed to set_frequency(). A width of 0 releases the channel (no pulse).
  /// Writes that would not change the registers are skipped.
  bool set_pulse_us(uint8_t channel, double microseconds, std::string & error);

  /// ON/OFF tick pair for a pulse. Each channel's rising edge is staggered by
  /// 256 ticks (~1.2 ms) so twelve servos never all start drawing stall current
  /// in the same instant -- the supply sees a spread load instead of a spike
  /// every 20 ms. The chip handles OFF < ON by wrapping.
  struct Ticks {uint16_t on; uint16_t off;};
  static Ticks pulse_ticks(uint8_t channel, double microseconds, double frequency_hz);

  /// Release every channel on this board.
  bool all_off(std::string & error);

  /// True if the chip still holds the configuration we gave it. A PCA9685
  /// whose supply dipped comes back asleep at its 200 Hz default: every output
  /// stops, and the write cache would hide it forever.
  bool verify(std::string & error);
  /// Reprogram mode and frequency after verify() failed, then rewrite every
  /// channel from the cache.
  bool recover(std::string & error);
  /// Rewrite the registers we believe are on the chip, byte for byte. Heals a
  /// register corrupted by bus noise without the rounding a fresh write could
  /// change.
  bool refresh(std::string & error);

  /// Lock file shared with the Python tools (same name for the same bus+address).
  static std::string lock_path(const std::string & bus, uint8_t address);

  const std::string & bus() const {return bus_;}
  uint8_t address() const {return address_;}
  double frequency() const {return frequency_hz_;}

private:
  bool write_register(uint8_t reg, uint8_t value, std::string & error);
  bool read_register(uint8_t reg, uint8_t & value, std::string & error);
  bool write_mode(std::string & error);

  std::string bus_;
  uint8_t address_;
  int fd_{-1};
  int lock_fd_{-1};
  double osc_hz_{kOscHz};
  double frequency_hz_{50.0};
  int prescale_{-1};

  // Last registers written per channel; -1 = unknown, always write.
  std::array<int32_t, kNumChannels> last_on_{};
  std::array<int32_t, kNumChannels> last_off_{};
  void forget_cache();
};

}  // namespace pkun_servo_driver

#endif  // PKUN_SERVO_DRIVER__PCA9685_HPP_
