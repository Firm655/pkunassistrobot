#include "pkun_servo_driver/servo_driver_node.hpp"

#include <algorithm>
#include <chrono>
#include <limits>
#include <cmath>
#include <functional>
#include <utility>

namespace pkun_servo_driver
{
namespace
{

constexpr double kDegToRad = M_PI / 180.0;
constexpr double kRadToDeg = 180.0 / M_PI;

}  // namespace

ServoDriverNode::ServoDriverNode(const rclcpp::NodeOptions & options)
: rclcpp_lifecycle::LifecycleNode("servo_driver", options)
{
  declare_parameter<std::string>("i2c_bus", "/dev/i2c-1");
  declare_parameter<std::vector<int64_t>>("board_addresses", {0x40, 0x41});
  declare_parameter<double>("update_rate_hz", 50.0);
  declare_parameter<double>("osc_hz", Pca9685::kOscHz);
  declare_parameter<double>("health_check_s", 1.0);
  declare_parameter<double>("state_rate_hz", 10.0);
  declare_parameter<std::vector<std::string>>("joints", std::vector<std::string>{});
  declare_parameter<double>("enable_stagger_s", 0.08);
  declare_parameter<double>("pulse_min_us", 500.0);
  declare_parameter<double>("pulse_max_us", 2500.0);
  declare_parameter<double>("command_timeout_s", 0.5);
  declare_parameter<double>("shutdown_grace_s", 6.0);
}

// ---------------------------------------------------------------------------
// configuration
// ---------------------------------------------------------------------------

bool ServoDriverNode::load_servo_config(std::string & error)
{
  const auto names = get_parameter("joints").as_string_array();
  if (names.empty()) {
    error = "parameter 'joints' is empty -- nothing to drive";
    return false;
  }

  servos_.clear();
  index_by_name_.clear();
  servos_.reserve(names.size());

  for (const auto & name : names) {
    const std::string prefix = "servos." + name + ".";

    // Declared on the first configure only: after a cleanup the parameters
    // (and any trim persisted into them) are still there.
    auto num = [this, &prefix](const std::string & key, double fallback) {
        const std::string full = prefix + key;
        return has_parameter(full) ? get_parameter(full).as_double() :
               declare_parameter<double>(full, fallback);
      };
    auto integer = [this, &prefix](const std::string & key, int64_t fallback) {
        const std::string full = prefix + key;
        return has_parameter(full) ? get_parameter(full).as_int() :
               declare_parameter<int64_t>(full, fallback);
      };
    const std::string invert_key = prefix + "invert";

    ServoChannel servo;
    servo.name = name;
    servo.board = static_cast<std::size_t>(integer("board", 0));
    servo.channel = static_cast<uint8_t>(integer("channel", 0));
    servo.center_us = num("center_us", 1500.0);
    servo.us_per_rad = num("us_per_deg", 11.111) * kRadToDeg;
    servo.min_rad = num("min_deg", -90.0) * kDegToRad;
    servo.max_rad = num("max_deg", 90.0) * kDegToRad;
    servo.invert = has_parameter(invert_key) ? get_parameter(invert_key).as_bool() :
      declare_parameter<bool>(invert_key, false);
    servo.trim_rad = num("trim_deg", 0.0) * kDegToRad;
    servo.max_rate_rad_s = num("max_rate_dps", 300.0) * kDegToRad;

    if (servo.board >= board_addresses_.size()) {
      error = "joint '" + name + "' references board index " +
        std::to_string(servo.board) + " but only " +
        std::to_string(board_addresses_.size()) + " boards are configured";
      return false;
    }
    if (servo.channel >= Pca9685::kNumChannels) {
      error = "joint '" + name + "' has channel " + std::to_string(servo.channel) +
        ", must be 0..15";
      return false;
    }
    // Narrow the joint range to what the pulse window allows, so the angle
    // clamp and the pulse clamp can never disagree.
    {
      const double s = servo.invert ? -1.0 : 1.0;
      const double a = (pulse_min_us_ - servo.center_us) / (s * servo.us_per_rad) - servo.trim_rad;
      const double b = (pulse_max_us_ - servo.center_us) / (s * servo.us_per_rad) - servo.trim_rad;
      servo.min_rad = std::max(servo.min_rad, std::min(a, b));
      servo.max_rad = std::min(servo.max_rad, std::max(a, b));
    }
    if (servo.min_rad >= servo.max_rad) {
      error = "joint '" + name + "' has no range left inside min_deg..max_deg and the pulse window";
      return false;
    }

    // Catch two joints wired to the same pin now, rather than as a mystery
    // twitch once the robot is standing on it.
    for (const auto & other : servos_) {
      if (other.board == servo.board && other.channel == servo.channel) {
        error = "joints '" + other.name + "' and '" + name +
          "' are both mapped to board " + std::to_string(servo.board) +
          " channel " + std::to_string(servo.channel);
        return false;
      }
    }

    servo.current_rad = std::clamp(0.0, servo.min_rad, servo.max_rad);
    servo.target_rad = servo.current_rad;
    index_by_name_.emplace(name, servos_.size());
    servos_.push_back(servo);
  }

  return true;
}

ServoDriverNode::CallbackReturn ServoDriverNode::on_configure(
  const rclcpp_lifecycle::State &)
{
  i2c_bus_ = get_parameter("i2c_bus").as_string();
  board_addresses_ = get_parameter("board_addresses").as_integer_array();
  update_rate_hz_ = get_parameter("update_rate_hz").as_double();
  osc_hz_ = get_parameter("osc_hz").as_double();
  if (!(osc_hz_ > 20e6 && osc_hz_ < 30e6)) {
    RCLCPP_ERROR(get_logger(), "osc_hz %.0f is not a plausible PCA9685 oscillator", osc_hz_);
    return CallbackReturn::FAILURE;
  }
  enable_stagger_s_ = std::max(0.0, get_parameter("enable_stagger_s").as_double());
  command_timeout_s_ = get_parameter("command_timeout_s").as_double();
  shutdown_grace_s_ = std::max(0.0, get_parameter("shutdown_grace_s").as_double());
  pulse_min_us_ = get_parameter("pulse_min_us").as_double();
  pulse_max_us_ = get_parameter("pulse_max_us").as_double();
  if (!(pulse_min_us_ > 0.0 && pulse_min_us_ < pulse_max_us_)) {
    RCLCPP_ERROR(get_logger(), "pulse_min_us / pulse_max_us are not a valid window");
    return CallbackReturn::FAILURE;
  }

  if (board_addresses_.empty()) {
    RCLCPP_ERROR(get_logger(), "no board_addresses configured");
    return CallbackReturn::FAILURE;
  }
  if (update_rate_hz_ <= 0.0) {
    RCLCPP_ERROR(get_logger(), "update_rate_hz must be positive");
    return CallbackReturn::FAILURE;
  }

  std::string error;
  if (!load_servo_config(error)) {
    RCLCPP_ERROR(get_logger(), "servo config rejected: %s", error.c_str());
    return CallbackReturn::FAILURE;
  }

  // This is the "initial connection to the device" step -- it lives here, in
  // the driver that owns the hardware, not in a separate node.
  boards_.clear();
  for (const auto address : board_addresses_) {
    auto board = std::make_unique<Pca9685>(i2c_bus_, static_cast<uint8_t>(address), osc_hz_);
    if (!board->open(error)) {
      RCLCPP_ERROR(
        get_logger(), "PCA9685 at 0x%02x on %s did not respond: %s",
        static_cast<unsigned>(address), i2c_bus_.c_str(), error.c_str());
      boards_.clear();
      return CallbackReturn::FAILURE;
    }
    if (!board->set_frequency(update_rate_hz_, error)) {
      RCLCPP_ERROR(get_logger(), "could not set PWM frequency: %s", error.c_str());
      boards_.clear();
      return CallbackReturn::FAILURE;
    }
    RCLCPP_INFO(
      get_logger(), "PCA9685 0x%02x ready, PWM %.2f Hz (osc %.3f MHz)",
      static_cast<unsigned>(address), board->frequency(), osc_hz_ / 1e6);
    boards_.push_back(std::move(board));
  }

  state_pub_ = create_publisher<pkun_msgs::msg::ServoState>("~/servo_state", 10);

  // Subscribed while inactive too: commands arriving early are absorbed into
  // the target and simply not written out until activation.
  command_sub_ = create_subscription<pkun_msgs::msg::JointCommand>(
    "joint_command", rclcpp::QoS(10),
    std::bind(&ServoDriverNode::on_joint_command, this, std::placeholders::_1));

  set_trim_srv_ = create_service<pkun_msgs::srv::SetTrim>(
    "~/set_trim",
    std::bind(
      &ServoDriverNode::handle_set_trim, this,
      std::placeholders::_1, std::placeholders::_2));
  set_torque_srv_ = create_service<pkun_msgs::srv::SetTorque>(
    "~/set_torque",
    std::bind(
      &ServoDriverNode::handle_set_torque, this,
      std::placeholders::_1, std::placeholders::_2));

  for (const auto & servo : servos_) {
    RCLCPP_INFO(get_logger(), "  %-14s board %zu ch %2u  %6.1f .. %6.1f deg", servo.name.c_str(),
      servo.board, static_cast<unsigned>(servo.channel), servo.min_rad * kRadToDeg,
      servo.max_rad * kRadToDeg);
  }
  RCLCPP_INFO(
    get_logger(), "configured %zu servos across %zu board(s)",
    servos_.size(), boards_.size());
  return CallbackReturn::SUCCESS;
}

ServoDriverNode::CallbackReturn ServoDriverNode::on_activate(
  const rclcpp_lifecycle::State & state)
{
  LifecycleNode::on_activate(state);

  torque_enabled_ = true;

  // Nothing is written here. Driving "0 rad" blindly on activation would slam
  // every leg straight from wherever it happens to lie; instead each channel
  // stays limp until the first joint_command names a target for it.
  for (auto & servo : servos_) {
    servo.target_rad = servo.current_rad;
    servo.step_rad = servo.max_rate_rad_s / update_rate_hz_;
    servo.commanded = false;
    servo.live = false;
    servo.enabled = true;
  }
  warned_stale_ = false;

  const auto period = std::chrono::duration<double>(1.0 / update_rate_hz_);
  control_timer_ = create_wall_timer(
    std::chrono::duration_cast<std::chrono::nanoseconds>(period),
    std::bind(&ServoDriverNode::on_control_tick, this));

  const double state_hz = std::max(1.0, get_parameter("state_rate_hz").as_double());
  state_timer_ = create_wall_timer(
    std::chrono::duration_cast<std::chrono::nanoseconds>(
      std::chrono::duration<double>(1.0 / state_hz)),
    [this]() {
      pkun_msgs::msg::ServoState msg;
      msg.header.stamp = now();
      msg.name.reserve(servos_.size());
      msg.position.reserve(servos_.size());
      msg.pulse_us.reserve(servos_.size());
      for (const auto & servo : servos_) {
        msg.name.push_back(servo.name);
        msg.position.push_back(servo.current_rad);
        msg.pulse_us.push_back(servo.last_pulse_us);
      }
      msg.torque_enabled = torque_enabled_;
      msg.boards_online = static_cast<uint8_t>(boards_.size());
      state_pub_->publish(msg);
    });

  // Checks the chips are still configured and rewrites the cached registers.
  const double health_s = get_parameter("health_check_s").as_double();
  if (health_s > 0.0) {
    health_timer_ = create_wall_timer(
      std::chrono::duration_cast<std::chrono::nanoseconds>(
        std::chrono::duration<double>(health_s)),
      std::bind(&ServoDriverNode::on_health_check, this));
  }

  RCLCPP_INFO(get_logger(), "active -- driving %zu servos", servos_.size());
  return CallbackReturn::SUCCESS;
}

ServoDriverNode::CallbackReturn ServoDriverNode::on_deactivate(
  const rclcpp_lifecycle::State & state)
{
  control_timer_.reset();
  state_timer_.reset();
  health_timer_.reset();
  release_all();
  LifecycleNode::on_deactivate(state);
  RCLCPP_INFO(get_logger(), "inactive -- servos released");
  return CallbackReturn::SUCCESS;
}

ServoDriverNode::CallbackReturn ServoDriverNode::on_cleanup(
  const rclcpp_lifecycle::State &)
{
  control_timer_.reset();
  state_timer_.reset();
  health_timer_.reset();
  command_sub_.reset();
  set_trim_srv_.reset();
  set_torque_srv_.reset();
  state_pub_.reset();
  boards_.clear();      // destructor releases every channel and closes the bus
  servos_.clear();
  index_by_name_.clear();
  return CallbackReturn::SUCCESS;
}

ServoDriverNode::CallbackReturn ServoDriverNode::on_shutdown(
  const rclcpp_lifecycle::State &)
{
  control_timer_.reset();
  state_timer_.reset();
  health_timer_.reset();
  release_all();
  boards_.clear();
  return CallbackReturn::SUCCESS;
}

// ---------------------------------------------------------------------------
// command handling
// ---------------------------------------------------------------------------

void ServoDriverNode::on_joint_command(
  const pkun_msgs::msg::JointCommand::SharedPtr msg)
{
  if (msg->name.size() != msg->position.size()) {
    RCLCPP_WARN_THROTTLE(
      get_logger(), *get_clock(), 2000,
      "joint_command has %zu names but %zu positions -- ignoring",
      msg->name.size(), msg->position.size());
    return;
  }

  for (const double p : msg->position) {
    if (!std::isfinite(p)) {
      RCLCPP_ERROR_THROTTLE(
        get_logger(), *get_clock(), 2000, "joint_command contains NaN/inf -- ignoring");
      return;
    }
  }

  last_command_ = now();
  warned_stale_ = false;
  const rclcpp::Time t = last_command_;
  // pkun_motion streams one command per tick with duration = one tick. Stepping
  // those here, as they arrive, keeps the output on the planner's clock. Left
  // to our own timer, two unsynchronised 50 Hz clocks beat: some ticks see no
  // new command (the leg pauses) and the next sees two (it jumps) -- jitter
  // that comes and goes as the phases drift.
  const bool streaming = msg->duration > 0.0 && msg->duration <= 1.5 / update_rate_hz_;
  std::vector<std::size_t> first_time;

  for (std::size_t i = 0; i < msg->name.size(); ++i) {
    const auto it = index_by_name_.find(msg->name[i]);
    if (it == index_by_name_.end()) {
      RCLCPP_WARN_THROTTLE(
        get_logger(), *get_clock(), 5000,
        "unknown joint '%s' in joint_command", msg->name[i].c_str());
      continue;
    }

    auto & servo = servos_[it->second];
    const double requested = msg->position[i];
    const double clamped = std::clamp(requested, servo.min_rad, servo.max_rad);
    if (std::abs(clamped - requested) > 1e-6) {
      RCLCPP_WARN_THROTTLE(
        get_logger(), *get_clock(), 2000,
        "joint '%s' commanded to %.1f deg, clamped to %.1f deg",
        servo.name.c_str(), requested * kRadToDeg, clamped * kRadToDeg);
    }
    servo.target_rad = clamped;

    if (!servo.commanded) {
      // First target ever: that is where the servo starts, with no
      // interpolation from a position we never knew.
      servo.commanded = true;
      servo.current_rad = clamped;
      servo.step_rad = servo.max_rate_rad_s / update_rate_hz_;
      first_time.push_back(it->second);
      continue;
    }

    // A duration turns into a per-tick step. It can only ever slow the servo
    // down: max_rate_dps is a torque/heat limit and is never exceeded.
    double rate = servo.max_rate_rad_s;
    if (msg->duration > 1e-3) {
      const double needed = std::abs(clamped - servo.current_rad) / msg->duration;
      rate = std::min(rate, needed);
    }
    servo.step_rad = std::max(rate, 1e-6) / update_rate_hz_;
    if (streaming && torque_enabled_ && servo.enabled && servo.live) {
      step_servo(servo, t);
    }
  }

  if (torque_enabled_ && !first_time.empty()) {
    schedule_enable(first_time);
  }
}

double ServoDriverNode::seconds_since_command() const
{
  if (last_command_.nanoseconds() == 0) {
    return std::numeric_limits<double>::infinity();
  }
  return (now() - last_command_).seconds();
}

void ServoDriverNode::schedule_enable(const std::vector<std::size_t> & indices)
{
  // Continue after the last channel already waiting, so two commands arriving
  // back to back still produce one evenly spaced sequence.
  rclcpp::Time t = now();
  for (const auto & servo : servos_) {
    if (servo.commanded && !servo.live && servo.live_at > t) {t = servo.live_at;}
  }
  for (const auto index : indices) {
    auto & servo = servos_[index];
    if (!servo.enabled || servo.live) {continue;}
    servo.live_at = t;
    t = t + rclcpp::Duration::from_seconds(enable_stagger_s_);
  }
}

void ServoDriverNode::on_control_tick()
{
  if (!torque_enabled_) {
    return;
  }

  const rclcpp::Time t = now();
  bool any_live = false;
  for (auto & servo : servos_) {
    if (!servo.enabled || !servo.commanded) {
      continue;
    }
    if (!servo.live) {
      if (t < servo.live_at) {
        continue;
      }
      servo.live = true;
      RCLCPP_DEBUG(get_logger(), "'%s' live", servo.name.c_str());
    }
    any_live = true;
    // Already stepped by a streamed command this tick: stepping again would
    // double the rate, and rewriting the same pulse is a no-op anyway.
    if ((t - servo.last_step_at).seconds() < 0.9 / update_rate_hz_) {
      continue;
    }
    step_servo(servo, t);
  }

  // Watchdog. Deliberately does NOT release: a robot that goes limp when its
  // planner hiccups falls on its face. It holds the last pose and says so.
  if (any_live && command_timeout_s_ > 0.0 && !warned_stale_ &&
    (t - last_command_).seconds() > command_timeout_s_)
  {
    warned_stale_ = true;
    RCLCPP_WARN(
      get_logger(), "no joint_command for %.1f s -- holding the last pose",
      (t - last_command_).seconds());
  }
}

void ServoDriverNode::step_servo(ServoChannel & servo, const rclcpp::Time & t)
{
  const double error = servo.target_rad - servo.current_rad;
  const double step = std::clamp(error, -servo.step_rad, servo.step_rad);
  if (step != 0.0) {servo.last_step_at = t;}
  write_servo(servo, servo.current_rad + step);
}

void ServoDriverNode::on_health_check()
{
  for (std::size_t i = 0; i < boards_.size(); ++i) {
    auto & board = *boards_[i];
    std::string error;
    if (!board.verify(error)) {
      // Almost always the logic supply sagging when the servos pull hard:
      // give the servos their own supply and a big capacitor at the board.
      RCLCPP_ERROR(
        get_logger(), "PCA9685 0x%02x: %s -- reprogramming (brown-out?)",
        static_cast<unsigned>(board.address()), error.c_str());
      if (!board.recover(error)) {
        RCLCPP_ERROR_THROTTLE(
          get_logger(), *get_clock(), 2000, "PCA9685 0x%02x recovery failed: %s",
          static_cast<unsigned>(board.address()), error.c_str());
      }
      continue;
    }
    if (!board.refresh(error)) {
      RCLCPP_WARN_THROTTLE(
        get_logger(), *get_clock(), 5000, "PCA9685 0x%02x refresh failed: %s",
        static_cast<unsigned>(board.address()), error.c_str());
    }
  }
}

double ServoDriverNode::pulse_for(const ServoChannel & servo, double angle_rad) const
{
  const double sign = servo.invert ? -1.0 : 1.0;
  const double pulse = servo.center_us + sign * (angle_rad + servo.trim_rad) * servo.us_per_rad;
  return std::clamp(pulse, pulse_min_us_, pulse_max_us_);
}

void ServoDriverNode::write_servo(ServoChannel & servo, double angle_rad)
{
  const double clamped = std::clamp(angle_rad, servo.min_rad, servo.max_rad);
  const double pulse = pulse_for(servo, clamped);

  std::string error;
  if (!boards_[servo.board]->set_pulse_us(servo.channel, pulse, error)) {
    RCLCPP_ERROR_THROTTLE(
      get_logger(), *get_clock(), 1000,
      "write failed for '%s': %s", servo.name.c_str(), error.c_str());
    return;
  }
  servo.current_rad = clamped;
  servo.last_pulse_us = pulse;
}

void ServoDriverNode::release_all()
{
  std::string error;
  for (auto & board : boards_) {
    if (!board->all_off(error)) {
      RCLCPP_WARN(get_logger(), "failed to release a board: %s", error.c_str());
    }
  }
  for (auto & servo : servos_) {
    servo.last_pulse_us = 0.0;
    servo.live = false;
  }
}

// ---------------------------------------------------------------------------
// services
// ---------------------------------------------------------------------------

void ServoDriverNode::handle_set_trim(
  const std::shared_ptr<pkun_msgs::srv::SetTrim::Request> request,
  std::shared_ptr<pkun_msgs::srv::SetTrim::Response> response)
{
  std::vector<std::size_t> targets;
  if (request->name.empty()) {
    targets.resize(servos_.size());
    for (std::size_t i = 0; i < servos_.size(); ++i) {targets[i] = i;}
  } else {
    const auto it = index_by_name_.find(request->name);
    if (it == index_by_name_.end()) {
      response->success = false;
      response->message = "unknown joint '" + request->name + "'";
      return;
    }
    targets.push_back(it->second);
  }

  for (const auto index : targets) {
    servos_[index].trim_rad = request->trim;
    if (request->persist) {
      set_parameter(
        rclcpp::Parameter(
          "servos." + servos_[index].name + ".trim_deg", request->trim * kRadToDeg));
    }
  }

  response->success = true;
  response->message = "trim set to " + std::to_string(request->trim * kRadToDeg) +
    " deg on " + std::to_string(targets.size()) + " joint(s)";
  RCLCPP_INFO(get_logger(), "%s", response->message.c_str());
}

void ServoDriverNode::handle_set_torque(
  const std::shared_ptr<pkun_msgs::srv::SetTorque::Request> request,
  std::shared_ptr<pkun_msgs::srv::SetTorque::Response> response)
{
  if (request->name.empty()) {
    torque_enabled_ = request->enable;
    for (auto & servo : servos_) {servo.enabled = request->enable;}
    if (!request->enable) {
      release_all();
    } else {
      // Resume from the last written pose, one channel at a time. Whoever
      // commands next (pkun_motion) plans onward from that same pose.
      std::vector<std::size_t> indices;
      for (std::size_t i = 0; i < servos_.size(); ++i) {
        auto & servo = servos_[i];
        servo.target_rad = servo.current_rad;
        servo.live = false;
        if (servo.commanded) {indices.push_back(i);}
      }
      schedule_enable(indices);
    }
    response->success = true;
    response->message = request->enable ? "all servos enabled" : "all servos released";
    RCLCPP_INFO(get_logger(), "%s", response->message.c_str());
    return;
  }

  for (const auto & name : request->name) {
    const auto it = index_by_name_.find(name);
    if (it == index_by_name_.end()) {
      response->success = false;
      response->message = "unknown joint '" + name + "'";
      return;
    }
    auto & servo = servos_[it->second];
    servo.enabled = request->enable;
    if (request->enable) {
      servo.target_rad = servo.current_rad;
      if (servo.commanded && !servo.live) {schedule_enable({it->second});}
    } else {
      std::string error;
      boards_[servo.board]->set_pulse_us(servo.channel, 0.0, error);
      servo.last_pulse_us = 0.0;
      servo.live = false;
    }
  }

  response->success = true;
  response->message = std::to_string(request->name.size()) +
    (request->enable ? " joint(s) enabled" : " joint(s) released");
  return;
}

}  // namespace pkun_servo_driver

#include "rclcpp_components/register_node_macro.hpp"
RCLCPP_COMPONENTS_REGISTER_NODE(pkun_servo_driver::ServoDriverNode)
