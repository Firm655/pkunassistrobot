#include <atomic>
#include <chrono>
#include <csignal>
#include <memory>

#include "pkun_servo_driver/servo_driver_node.hpp"
#include "rclcpp/rclcpp.hpp"

namespace
{
std::atomic_bool g_stop{false};

extern "C" void on_signal(int) {g_stop = true;}
}  // namespace

int main(int argc, char ** argv)
{
  // Signals are ours, not rclcpp's: on Ctrl-C the motion node lowers the robot
  // into its parking posture, and that only works if this driver keeps writing
  // pulses while it does. We stop when the commands stop, or when the grace
  // period runs out -- whichever comes first.
  rclcpp::init(argc, argv, rclcpp::InitOptions(), rclcpp::SignalHandlerOptions::None);
  std::signal(SIGINT, on_signal);
  std::signal(SIGTERM, on_signal);

  // Single-threaded on purpose: every callback here ends up writing to the same
  // I2C file descriptor, so there is nothing to gain from parallelism and a real
  // risk of interleaving two register writes.
  rclcpp::executors::SingleThreadedExecutor executor;
  auto node = std::make_shared<pkun_servo_driver::ServoDriverNode>(rclcpp::NodeOptions());
  executor.add_node(node->get_node_base_interface());

  while (rclcpp::ok() && !g_stop) {
    executor.spin_once(std::chrono::milliseconds(50));
  }

  const auto deadline = std::chrono::steady_clock::now() +
    std::chrono::duration_cast<std::chrono::steady_clock::duration>(
    std::chrono::duration<double>(node->shutdown_grace_s()));
  RCLCPP_INFO(
    node->get_logger(), "stopping: holding the servos for up to %.1f s while the robot parks",
    node->shutdown_grace_s());
  while (rclcpp::ok() && std::chrono::steady_clock::now() < deadline) {
    executor.spin_once(std::chrono::milliseconds(20));
    if (node->seconds_since_command() > 0.75) {
      break;   // nothing is commanding us any more
    }
  }

  // Destroying the node closes the boards, which releases every channel.
  executor.remove_node(node->get_node_base_interface());
  node.reset();
  rclcpp::shutdown();
  return 0;
}
