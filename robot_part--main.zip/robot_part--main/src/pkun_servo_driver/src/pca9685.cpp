#include "pkun_servo_driver/pca9685.hpp"

#include <fcntl.h>
#include <linux/i2c-dev.h>
#include <sys/file.h>
#include <sys/ioctl.h>
#include <unistd.h>

#include <cerrno>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <thread>
#include <utility>

namespace pkun_servo_driver
{
namespace
{

constexpr uint8_t kRegMode1 = 0x00;
constexpr uint8_t kRegMode2 = 0x01;
constexpr uint8_t kRegLed0OnL = 0x06;
constexpr uint8_t kRegPrescale = 0xFE;

constexpr uint8_t kMode1Restart = 0x80;
constexpr uint8_t kMode1AutoInc = 0x20;
constexpr uint8_t kMode1Sleep = 0x10;
constexpr uint8_t kMode1AllCall = 0x01;

constexpr uint8_t kMode2OutDrive = 0x04;  // totem pole output

std::string errno_text(const std::string & what)
{
  return what + ": " + std::strerror(errno);
}

}  // namespace

Pca9685::Pca9685(std::string bus, uint8_t address, double osc_hz)
: bus_(std::move(bus)), address_(address), osc_hz_(osc_hz > 0.0 ? osc_hz : kOscHz)
{
  forget_cache();
}

void Pca9685::forget_cache()
{
  last_on_.fill(-1);
  last_off_.fill(-1);
}

Pca9685::~Pca9685()
{
  close();
}

std::string Pca9685::lock_path(const std::string & bus, uint8_t address)
{
  // "/dev/i2c-1" -> "i2c-1"; the Python tools build the same name from bus 1.
  const auto slash = bus.find_last_of('/');
  const std::string dev = slash == std::string::npos ? bus : bus.substr(slash + 1);
  char addr[8];
  std::snprintf(addr, sizeof(addr), "0x%02x", static_cast<unsigned>(address));
  return "/run/lock/pkun-pca9685-" + dev + "-" + addr + ".lock";
}

bool Pca9685::open(std::string & error)
{
  close();
  forget_cache();

  // Two programs driving one PCA9685 is the classic "sometimes it goes wild":
  // each re-inits the chip (sleep, prescale, all off) and they overwrite each
  // other's pulses. The lock is released by the kernel even if we crash.
  const std::string lock = lock_path(bus_, address_);
  lock_fd_ = ::open(lock.c_str(), O_RDWR | O_CREAT | O_CLOEXEC, 0666);
  if (lock_fd_ < 0) {
    error = errno_text("open " + lock);
    return false;
  }
  if (::flock(lock_fd_, LOCK_EX | LOCK_NB) < 0) {
    error = "another program is already driving this PCA9685 (" + lock +
      ") -- close servo_calib.py / servo_home.py / other servo tools first";
    ::close(lock_fd_);
    lock_fd_ = -1;
    return false;
  }

  fd_ = ::open(bus_.c_str(), O_RDWR);
  if (fd_ < 0) {
    error = errno_text("open " + bus_);
    return false;
  }
  if (::ioctl(fd_, I2C_SLAVE, static_cast<int>(address_)) < 0) {
    error = errno_text("select i2c address");
    close();
    return false;
  }

  // A read is the cheapest way to prove something is actually acking at this
  // address -- open() alone succeeds even with nothing plugged in.
  uint8_t mode1 = 0;
  if (!read_register(kRegMode1, mode1, error)) {
    close();
    return false;
  }

  if (!write_mode(error)) {
    close();
    return false;
  }

  std::string ignored;
  all_off(ignored);
  return true;
}

bool Pca9685::write_mode(std::string & error)
{
  return write_register(kRegMode1, kMode1AutoInc | kMode1AllCall, error) &&
         write_register(kRegMode2, kMode2OutDrive, error);
}

void Pca9685::close()
{
  if (fd_ >= 0) {
    std::string ignored;
    all_off(ignored);
    ::close(fd_);
    fd_ = -1;
  }
  if (lock_fd_ >= 0) {
    ::close(lock_fd_);   // drops the flock
    lock_fd_ = -1;
  }
}

bool Pca9685::write_register(uint8_t reg, uint8_t value, std::string & error)
{
  if (fd_ < 0) {
    error = "i2c device not open";
    return false;
  }
  uint8_t buffer[2] = {reg, value};
  if (::write(fd_, buffer, sizeof(buffer)) != static_cast<ssize_t>(sizeof(buffer))) {
    error = errno_text("i2c write");
    return false;
  }
  return true;
}

bool Pca9685::read_register(uint8_t reg, uint8_t & value, std::string & error)
{
  if (fd_ < 0) {
    error = "i2c device not open";
    return false;
  }
  if (::write(fd_, &reg, 1) != 1) {
    error = errno_text("i2c set read pointer");
    return false;
  }
  if (::read(fd_, &value, 1) != 1) {
    error = errno_text("i2c read");
    return false;
  }
  return true;
}

bool Pca9685::set_frequency(double hz, std::string & error)
{
  if (hz < 24.0 || hz > 1526.0) {
    error = "pwm frequency out of range for PCA9685 (24..1526 Hz)";
    return false;
  }

  const double raw = osc_hz_ / (static_cast<double>(kTicks) * hz);
  int prescale = static_cast<int>(std::lround(raw)) - 1;
  if (prescale < 3) {prescale = 3;}
  if (prescale > 255) {prescale = 255;}

  uint8_t mode1 = 0;
  if (!read_register(kRegMode1, mode1, error)) {return false;}

  // The prescaler is only writable while the oscillator is asleep.
  const uint8_t sleeping = static_cast<uint8_t>((mode1 & ~kMode1Restart) | kMode1Sleep);
  if (!write_register(kRegMode1, sleeping, error) ||
    !write_register(kRegPrescale, static_cast<uint8_t>(prescale), error) ||
    !write_register(kRegMode1, mode1, error))
  {
    return false;
  }

  // Datasheet: allow >=500 us for the oscillator to stabilise before RESTART.
  std::this_thread::sleep_for(std::chrono::milliseconds(1));
  if (!write_register(
      kRegMode1, static_cast<uint8_t>(mode1 | kMode1Restart | kMode1AutoInc), error))
  {
    return false;
  }

  // Store the frequency the chip actually produces, not the one asked for --
  // the prescaler is an integer, so 50 Hz is really 49.7 Hz. Pulse widths are
  // computed from this, and being wrong here skews every servo angle.
  frequency_hz_ = osc_hz_ / (static_cast<double>(kTicks) * (prescale + 1));
  prescale_ = prescale;
  return true;
}

bool Pca9685::set_pwm(uint8_t channel, uint16_t on, uint16_t off, std::string & error)
{
  if (channel >= kNumChannels) {
    error = "pca9685 channel out of range";
    return false;
  }
  if (fd_ < 0) {
    error = "i2c device not open";
    return false;
  }

  uint8_t buffer[5];
  buffer[0] = static_cast<uint8_t>(kRegLed0OnL + 4 * channel);
  buffer[1] = static_cast<uint8_t>(on & 0xFF);
  buffer[2] = static_cast<uint8_t>(on >> 8);
  buffer[3] = static_cast<uint8_t>(off & 0xFF);
  buffer[4] = static_cast<uint8_t>(off >> 8);

  if (::write(fd_, buffer, sizeof(buffer)) != static_cast<ssize_t>(sizeof(buffer))) {
    last_on_[channel] = -1;   // state on the chip is now unknown
    last_off_[channel] = -1;
    error = errno_text("i2c write pwm");
    return false;
  }
  last_on_[channel] = on;
  last_off_[channel] = off;
  return true;
}

Pca9685::Ticks Pca9685::pulse_ticks(uint8_t channel, double microseconds, double frequency_hz)
{
  const double period_us = 1'000'000.0 / frequency_hz;
  double ticks = microseconds / period_us * static_cast<double>(kTicks);
  if (ticks < 1.0) {ticks = 1.0;}
  if (ticks > kTicks - 1) {ticks = kTicks - 1;}
  const uint16_t on = static_cast<uint16_t>((channel * 256u) % kTicks);
  const uint16_t off = static_cast<uint16_t>((on + std::lround(ticks)) % kTicks);
  return {on, off};
}

bool Pca9685::set_pulse_us(uint8_t channel, double microseconds, std::string & error)
{
  if (microseconds <= 0.0) {
    // Bit 12 of the OFF register is the "full off" flag: a true release, not a
    // zero-width pulse.
    return set_pwm(channel, 0, kTicks, error);
  }

  if (channel >= kNumChannels) {
    error = "pca9685 channel out of range";
    return false;
  }
  const Ticks t = pulse_ticks(channel, microseconds, frequency_hz_);
  if (fd_ >= 0 && last_on_[channel] == t.on && last_off_[channel] >= 0 &&
    last_off_[channel] < kTicks)
  {
    const double exact = microseconds * frequency_hz_ * kTicks / 1'000'000.0;
    const int on_chip = (last_off_[channel] - last_on_[channel] + kTicks) % kTicks;
    if (std::abs(exact - on_chip) < kHysteresisTicks) {
      return true;   // already on the chip, or too close to be worth a twitch
    }
  }
  return set_pwm(channel, t.on, t.off, error);
}

bool Pca9685::verify(std::string & error)
{
  if (prescale_ < 0) {return true;}   // frequency never set: nothing to compare
  uint8_t mode1 = 0;
  uint8_t prescale = 0;
  if (!read_register(kRegMode1, mode1, error) ||
    !read_register(kRegPrescale, prescale, error))
  {
    return false;
  }
  if ((mode1 & kMode1Sleep) || !(mode1 & kMode1AutoInc) || prescale != prescale_) {
    char text[96];
    std::snprintf(
      text, sizeof(text), "chip lost its setup (MODE1=0x%02x PRESCALE=%u, expected %d)",
      mode1, prescale, prescale_);
    error = text;
    return false;
  }
  return true;
}

bool Pca9685::recover(std::string & error)
{
  // frequency_hz_ is exactly what the stored prescale produces, so this
  // reproduces the same register value.
  if (!write_mode(error) || !set_frequency(frequency_hz_, error)) {return false;}
  return refresh(error);
}

bool Pca9685::refresh(std::string & error)
{
  bool ok = true;
  for (uint8_t ch = 0; ch < kNumChannels; ++ch) {
    if (last_on_[ch] < 0 || last_off_[ch] < 0) {continue;}
    ok = set_pwm(
      ch, static_cast<uint16_t>(last_on_[ch]), static_cast<uint16_t>(last_off_[ch]), error) && ok;
  }
  return ok;
}

bool Pca9685::all_off(std::string & error)
{
  bool ok = true;
  for (uint8_t ch = 0; ch < kNumChannels; ++ch) {
    ok = set_pwm(ch, 0, kTicks, error) && ok;
  }
  return ok;
}

}  // namespace pkun_servo_driver
