#include <gtest/gtest.h>

#include <string>

#include "pkun_servo_driver/pca9685.hpp"

using pkun_servo_driver::Pca9685;

// These tests cover the parts that do not need hardware: argument validation and
// the prescale maths. Anything that actually talks to the bus is exercised on
// the robot, not here.

TEST(Pca9685, RejectsWritesWhenClosed)
{
  Pca9685 board("/dev/i2c-1", 0x40);
  EXPECT_FALSE(board.is_open());

  std::string error;
  EXPECT_FALSE(board.set_pwm(0, 0, 2048, error));
  EXPECT_FALSE(error.empty());
}

TEST(Pca9685, RejectsOutOfRangeChannel)
{
  Pca9685 board("/dev/i2c-1", 0x40);
  std::string error;
  EXPECT_FALSE(board.set_pwm(Pca9685::kNumChannels, 0, 100, error));
  EXPECT_NE(error.find("channel"), std::string::npos);
}

TEST(Pca9685, RejectsFrequencyOutsideChipRange)
{
  Pca9685 board("/dev/i2c-1", 0x40);
  std::string error;
  EXPECT_FALSE(board.set_frequency(5.0, error));
  EXPECT_FALSE(board.set_frequency(5000.0, error));
}

TEST(Pca9685, DefaultFrequencyMatchesAnalogServos)
{
  Pca9685 board("/dev/i2c-1", 0x40);
  EXPECT_DOUBLE_EQ(board.frequency(), 50.0);
}

TEST(Pca9685, PulseWidthSurvivesThePhaseStagger)
{
  // At exactly 50 Hz one tick is 4.8828 us, so 1500 us is 307.2 -> 307 ticks.
  for (uint8_t ch = 0; ch < Pca9685::kNumChannels; ++ch) {
    const auto t = Pca9685::pulse_ticks(ch, 1500.0, 50.0);
    EXPECT_EQ(t.on, (ch * 256) % 4096);
    const int width = (static_cast<int>(t.off) - static_cast<int>(t.on) + 4096) % 4096;
    EXPECT_EQ(width, 307) << "channel " << int(ch);
  }
}

TEST(Pca9685, RisingEdgesAreSpreadAcrossTheFrame)
{
  EXPECT_NE(Pca9685::pulse_ticks(0, 1500, 50).on, Pca9685::pulse_ticks(1, 1500, 50).on);
  // Channel 15 starts at tick 3840 and its pulse wraps past the frame end.
  const auto t = Pca9685::pulse_ticks(15, 2500, 50);
  EXPECT_EQ(t.on, 3840);
  EXPECT_LT(t.off, t.on);
}

TEST(Pca9685, LockFileMatchesThePythonTools)
{
  // servo_calib.py & co. build this same name from bus=1, addr=0x40.
  EXPECT_EQ(Pca9685::lock_path("/dev/i2c-1", 0x40), "/run/lock/pkun-pca9685-i2c-1-0x40.lock");
}

TEST(Pca9685, VerifyWithoutFrequencyIsTrivial)
{
  Pca9685 board("/dev/i2c-1", 0x40);
  std::string error;
  EXPECT_TRUE(board.verify(error));
}

int main(int argc, char ** argv)
{
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
