# P-kun controller workspace (ROS 2 Jazzy, C++)

P-kun is a stationary elder-care robot dog: it waits beside the resident's
resting area and, when the local app decides it is time, gets up and does
something to get their attention. This workspace is the movement half: 12 leg
servos on one PCA9685 (0x40), driven from a Raspberry Pi 4. The app talks to it
through a single ROS 2 action.

| Package | Owns | Touches hardware |
|---|---|---|
| `pkun_msgs` | `Behavior` action, `MotionStatus`, `JointCommand`, `ServoState`, `SetTorque`, `SetTrim` | no |
| `pkun_motion` | robot model, safety-checked planner, the action server | no |
| `pkun_servo_driver` | PCA9685 over I²C, the only writer to the servos | **yes** |
| `pkun_bringup` | launch files, `calib_to_servos_yaml.py` | no |

```
app ──action /pkun/motion/behavior──▶ motion ──/pkun/joint_command (50 Hz)──▶ servo_driver ──I²C──▶ PCA9685
    ◀──topic /pkun/motion/status────        ◀──/pkun/servo_driver/servo_state──
```

## Behaviours

| name | option | count | ends in |
|---|---|---|---|
| `rest` | | | lying down |
| `stand` | | | standing |
| `sit` | | | sitting, chest up (screen tilted toward the resident) |
| `walk` | `forward` / `backward` | gait cycles (default 4) | standing |
| `turn_left`, `turn_right` | | gait cycles | standing |
| `beckon` | `left` / `right` (the robot's own paw) | waves (default 3) | standing |
| `alert` | | | sitting (perks up, bounces, sits facing you) |
| `play_bow` | | | standing |
| `happy` | | wiggles | standing |
| `nod` | | nods | standing |
| `wake_up` | | bounces (default 2) | standing |
| `medicine` | | nods (default 2) | sitting |
| `lets_go` | | waves (default 2) | standing |
| `eat` | | bites (default 3) | standing |

The last four are the care reminders the app triggers on a schedule:
`wake_up` gets up unhurried, stretches like a dog that just woke, then bounces
a little deeper each time; `medicine` is deliberate and does not wiggle, and
ends sitting so the screen faces the resident; `lets_go` bows, wiggles and
beckons; `eat` noses down and nibbles.

`speed` (0.5–1.5; 0 = 1.0) scales every behaviour. Postures chain on their
own, so `walk` while lying down stands up first.

How it stays safe:

- **Planned before it moves.** A behaviour is fully planned from the pose the
  servos hold at that moment, then checked frame by frame: joint limits, a
  300 °/s speed cap, the underbody (the Pi) clear of the table, feet not
  through the floor, and the centre of mass at least 8 mm inside the feet on
  the ground. If any check fails, the goal is aborted with the reason and
  nothing moves.
- **Joint limits come from the servo calibration.** Every joint is held to
  the part of the 500–2500 µs pulse window its horn allows. The driver never
  has to clip a command, and a clipped command is exactly what makes a real leg
  disagree with the plan.
- **One behaviour at a time.** A second goal is rejected. If you cancel a walk,
  it is re-planned to stop at the next safe footfall. The new plan matches the
  old one frame for frame up to that point, so nothing jumps. A cancelled
  gesture finishes first.
- **Torque or driver lost** → the goal is aborted and the posture becomes
  `unknown`. The next goal recovers slowly in joint space.
- **Start-up.** The node refuses to start if a canonical posture is
  unreachable, and it dry-runs every behaviour from every posture. The driver
  writes nothing until the first command arrives, then switches the servos on
  one at a time, 80 ms apart. The PWM edges are staggered, so the servos never
  all draw current at once. If commands stop, it holds the pose and warns; it
  never goes limp by itself.

## Calibration: `~/servo_calib.json` is the reference

Every channel, neutral pulse and direction comes from `servo_calib.json`;
`servos.yaml` is generated from it and never edited by hand.

**The calibration's initial pose is not the model's zero.** Since 2026-09-23
the initial pose (every servo at its `neutral_us`) is: legs straight down, but
each knee already folded 90° with the knee pointing forward. The model's zero
is a straight leg, so the converter shifts each knee by 90°:

    calib_deg = SIGN * (model_deg - INITIAL_MODEL)
    SIGN: abduction -1, hip pitch +1, knee +1
    INITIAL_MODEL: abduction 0, hip pitch 0, knee 90

and `servos.yaml` stores `center_us` as the pulse at model angle 0. Putting the
knee's neutral in the middle of its fold is what gives it room both ways: it
can straighten the leg and fold further.

Usable fold per knee, inside 500–2500 µs: FL 144°, **FR 115°**, RL 142°,
RR 150°. FR is the weakest link and sets several limits: standing at 92 mm
(not lower), lying at 84 mm, and a shallow play bow.

Conventions, all confirmed on the robot:

| joint | model angle | robot |
|---|---|---|
| abduction | + | every leg swings toward the robot's left (left legs spread, right legs tuck) |
| hip pitch | − | thigh swings forward, toward the head (calib swings it back) |
| knee | + | knee folds, knee pointing forward; 0 = straight leg |

Note: `kinematic_apply.py` and `pkun_web.py` still assume the old initial pose
(straight knees) and would clip or mis-place the knees. Do not use them for
poses any more.

### Recalibrating

`pkun.launch.py` and `calibrate.launch.py` regenerate the servo map from
`~/servo_calib.json` (override with `PKUN_CALIB=...`) on every launch, into
`~/.cache/pkun/servos.yaml`, and print each joint's usable range. So a
recalibration only needs a relaunch -- no rebuild, no editing YAML. If the
calibration file is missing or unreadable, the launch falls back to the
`servos.yaml` built into `pkun_servo_driver` and says so.

What does NOT come from the calibration file: the link lengths (measured off
the robot, in `motion.yaml`), the sign/zero conventions in the table above
(in `calib_to_servos_yaml.py`), and the posture heights (in `motion.yaml`,
though lying is raised automatically when the joints cannot reach, and the
node refuses to start if a posture is impossible).

To regenerate the checked-in copy by hand:

```bash
python3 src/pkun_bringup/scripts/calib_to_servos_yaml.py
```

## Build

colcon is not installed yet:

```bash
sudo apt install python3-colcon-common-extensions
cd ~/pkun/controller
colcon build --cmake-args -DCMAKE_BUILD_TYPE=Release
source install/setup.bash
colcon test --packages-select pkun_motion pkun_servo_driver && colcon test-result --verbose
```

If a Python venv is active, deactivate it first (`deactivate`). The message
generators need the system Python (`em`, `lark`).

## Check without hardware

```bash
ros2 run pkun_motion motion_report                 # every behaviour: time, speed, balance, torque
ros2 run pkun_motion motion_report rest install/pkun_servo_driver/share/pkun_servo_driver/config/servos.yaml
```

The second form applies the real per-joint limits, the same way the node
does.

## The device app

The patient-facing app (`clientdevice/` in Firm655/pkunassistrobot) publishes
its UI events as JSON on `/pkun/ui_event` (std_msgs/String). `ui_bridge.py`,
started by `pkun.launch.py`, turns those into behaviours:

| app event | default behaviour |
|---|---|
| `notify` MEDICINE / MEAL / DAILY_CHECK_IN / TASK / MESSAGE | `medicine` / `eat` / `alert` / `nod` / `beckon` |
| `response` answer YES / NO / DISPLAYED | `happy` / `nod` / nothing |
| `request` HELP / HUNGRY / NOT_RIGHT | `alert` / `eat` / `alert` |
| `game` start / correct / wrong / finished | `play_bow` / `happy` / `nod` / `happy` x3 |

The mapping is in `config/ui_bridge.yaml`: values are `behaviour` or
`behaviour:count`, and an empty value ignores that event. Two rules are built
in: `notify` and `request` interrupt whatever is running (a walk stops at the
next safe footfall, a gesture settles back to its posture in about a second),
while game events never interrupt; and a repeat of the same event within
`min_interval_s` is dropped, so a game firing "correct" three times a second
cannot thrash the servos.

Test it without the app:

```bash
ros2 topic pub --once /pkun/ui_event std_msgs/msg/String \
  '{data: "{\"event\":\"request\",\"code\":\"HELP\"}"}'
```

Start without it: `ros2 launch pkun_bringup pkun.launch.py ui_bridge:=false`.

## Run on the robot

Nothing else may be driving the PCA9685: stop `pkun_web.py` and the other
Python tools first. Put the robot down lying (or pass `startup_posture:=stand`
if it is standing), then:

```bash
ros2 launch pkun_bringup pkun.launch.py

ros2 action send_goal /pkun/motion/behavior pkun_msgs/action/Behavior "{name: stand}"
ros2 action send_goal -f /pkun/motion/behavior pkun_msgs/action/Behavior "{name: walk, option: forward, count: 4}"
ros2 action send_goal /pkun/motion/behavior pkun_msgs/action/Behavior "{name: beckon, option: left}"
ros2 action send_goal /pkun/motion/behavior pkun_msgs/action/Behavior "{name: alert}"
ros2 topic echo /pkun/motion/status
```

Ctrl-C in the send_goal terminal cancels the goal. The walk stops at the next
safe footfall.

Emergency limp (every servo released):

```bash
ros2 service call /pkun/servo_driver/set_torque pkun_msgs/srv/SetTorque "{enable: false, name: []}"
```

`{enable: true}` switches them back on one at a time at the last pose. Send
`stand` or `rest` afterwards; the robot recovers slowly from `unknown`.

## Tuning

`pkun_motion/config/motion.yaml` holds every height, timing, gait and gesture
value, the payload masses and the underbody points. **If the Pi or the LCD
moves, or the head is fitted, update `underbody` and `payload` there.** A
payload the servos cannot carry is refused, not attempted: see the torque
budget below.

Lying down is set to 84 mm (`posture.rest_height`), where the FR knee is at
113° of its 115°. The Pi (about 30 mm under the belly, underside at
z = -55 mm) has 29 mm of clearance there.

### Servo load (EMAX ES08MA II on 5 V)

At 5 V the ES08MA II stalls at about 1.67 kg·cm and turns about 460 °/s with
no load. Every plan is checked against two limits:

- `safety.max_torque_kgcm` = 1.2 kg·cm (static), about 72% of stall
- `safety.rate_cap_dps` = 300 °/s; a plan faster than the servo turns becomes
  lag, and then a leg is not where the balance check assumed

Planned peaks at 884 g, **including the 130 g head 150 mm ahead of the top
plate**:

| | knee | hip | abduction |
|---|---|---|---|
| standing / lying (held continuously) | 0.85 / 0.94 | 0.31 | 0.36 |
| walk / turn (3 legs down, brief) | 1.02 / 0.96 | 0.83 | 1.01 |
| beckon (one fore paw up) | 0.85 | 1.01 | 0.85 |
| sit ↔ stand | 0.85 | 0.69 | 0.36 |

The head is the heaviest thing about the current tuning. It puts the centre of
mass 25 mm ahead of the hips, so the feet stand 12 mm ahead of them too: that
shares the extra load between the front knees and hips instead of piling it on
one of them. Beckoning is now the tightest case, because lifting a fore paw
puts the head's weight on the remaining three.

The robot stands at 102 mm and walks at 116 mm, because a straighter knee is
what keeps the load down. The walk covers about 15 mm/s, slowed automatically
to stay under the speed cap. On a 6 V supply the same plans use about 60% of
stall.

Servo channels and calibration live in `pkun_servo_driver/config/servos.yaml`.
That file is generated from `~/servo_calib.json`, so do not edit it by hand.
# robot_part-
